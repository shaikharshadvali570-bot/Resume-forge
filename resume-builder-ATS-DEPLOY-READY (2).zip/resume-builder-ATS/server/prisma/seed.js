/**
 * ResumeForge — database seed.
 * Creates an idempotent demo account with one fully populated resume.
 *
 *   npx prisma db seed        (or: npm run db:seed)
 *
 * Demo credentials (safe to publish — this account carries no real data):
 *   email:    demo@resumeforge.dev
 *   password: Demo123!
 */
import bcrypt from 'bcryptjs';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

const DEMO_EMAIL = 'demo@resumeforge.dev';
const DEMO_PASSWORD = 'Demo123!';

const demoResume = {
  title: 'Software Engineer Resume',
  template: 'professional',
  theme: 'blue',
  fullName: 'Alex Morgan',
  email: 'alex.morgan@example.com',
  phone: '(555) 010-2030',
  location: 'San Francisco, CA',
  linkedin: 'https://linkedin.com/in/alexmorgan',
  github: 'https://github.com/alexmorgan',
  website: 'https://alexmorgan.dev',
  summary:
    'Results-driven software engineer with 5+ years of experience building scalable web applications. Led cross-functional teams to ship products used by millions, improved performance by 40%, and championed clean architecture and automated testing across the organization.',
  sectionOrder: [
    'summary', 'experience', 'projects', 'education',
    'skills', 'certifications', 'achievements', 'languages', 'hobbies',
  ],
  hobbies: ['Open source', 'Trail running', 'Photography'],
  education: [
    {
      degree: 'B.S. Computer Science',
      university: 'University of California, Berkeley',
      location: 'Berkeley, CA',
      startYear: '2015',
      endYear: '2019',
      description: 'Focus on distributed systems and human-computer interaction. GPA: 3.8/4.0.',
      order: 0,
    },
  ],
  experience: [
    {
      jobTitle: 'Senior Software Engineer',
      company: 'Nova Labs',
      location: 'San Francisco, CA',
      startDate: '2022-03',
      endDate: '',
      currentlyWorking: true,
      description:
        'Led a team of 6 engineers rebuilding the core platform, reducing page load time by 40%\nDesigned and implemented a REST API serving 2M+ requests per day\nIntroduced CI/CD pipelines that cut release cycles from weekly to daily',
      order: 0,
    },
    {
      jobTitle: 'Software Engineer',
      company: 'Brightside Inc.',
      location: 'Remote',
      startDate: '2019-07',
      endDate: '2022-02',
      currentlyWorking: false,
      description:
        'Built React-based dashboards used by 30k+ customers\nReduced API error rates by 60% through structured logging and alerting\nMentored 4 junior developers through onboarding and code reviews',
      order: 1,
    },
  ],
  projects: [
    {
      title: 'OpenHire',
      organization: 'Personal Project',
      technologies: 'React, Node.js, PostgreSQL',
      startDate: '2023-01',
      endDate: '2023-06',
      description:
        'Developed an open-source job board with resume parsing and ATS-friendly exports\nGained 1.2k GitHub stars and 40+ community contributions',
      projectUrl: 'https://github.com/alexmorgan/openhire',
      order: 0,
    },
  ],
  skills: [
    { name: 'JavaScript', category: 'Languages', level: 'Expert', order: 0 },
    { name: 'TypeScript', category: 'Languages', level: 'Advanced', order: 1 },
    { name: 'React', category: 'Frontend', level: 'Expert', order: 2 },
    { name: 'Node.js', category: 'Backend', level: 'Expert', order: 3 },
    { name: 'PostgreSQL', category: 'Databases', level: 'Advanced', order: 4 },
    { name: 'Docker', category: 'DevOps', level: 'Intermediate', order: 5 },
    { name: 'AWS', category: 'Cloud', level: 'Intermediate', order: 6 },
    { name: 'CI/CD', category: 'DevOps', level: 'Advanced', order: 7 },
    { name: 'Agile', category: 'Process', level: 'Advanced', order: 8 },
    { name: 'Technical Leadership', category: 'Soft Skills', level: 'Advanced', order: 9 },
  ],
  certifications: [
    {
      name: 'AWS Certified Solutions Architect – Associate',
      issuingOrganization: 'Amazon Web Services',
      issueDate: '2024',
      credentialUrl: 'https://aws.amazon.com/certification/',
      order: 0,
    },
  ],
  achievements: [
    {
      title: 'Employee of the Year',
      description: 'Recognized for leading the platform rebuild that cut latency by 40%.',
      date: '2023',
      order: 0,
    },
    {
      title: 'Hackathon Winner',
      description: 'First place at NovaLabs Open Innovation Hackathon.',
      date: '2021',
      order: 1,
    },
  ],
  languages: [
    { name: 'English', proficiency: 'Native', order: 0 },
    { name: 'Spanish', proficiency: 'Professional working', order: 1 },
  ],
};

async function main() {
  const passwordHash = await bcrypt.hash(DEMO_PASSWORD, 10);
  const user = await prisma.user.upsert({
    where: { email: DEMO_EMAIL },
    update: { name: 'Demo User', passwordHash },
    create: { name: 'Demo User', email: DEMO_EMAIL, passwordHash },
  });

  // Keep the seed idempotent: refresh the demo resume on every run.
  await prisma.resume.deleteMany({ where: { userId: user.id } });

  const { education, experience, projects, skills, certifications, achievements, languages, ...core } =
    demoResume;
  await prisma.resume.create({
    data: {
      ...core,
      userId: user.id,
      education: { create: education },
      experience: { create: experience },
      projects: { create: projects },
      skills: { create: skills },
      certifications: { create: certifications },
      achievements: { create: achievements },
      languages: { create: languages },
    },
  });

  const resumeCount = await prisma.resume.count({ where: { userId: user.id } });
  console.log(`✓ Seeded demo user ${DEMO_EMAIL} with ${resumeCount} resume(s).`);
  console.log(`  Password: ${DEMO_PASSWORD}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
