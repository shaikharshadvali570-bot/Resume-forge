/**
 * Local PostgreSQL manager for machines without a system PostgreSQL/Docker.
 * Uses the PostgreSQL binaries bundled with the `embedded-postgres` dev
 * dependency (initdb / pg_ctl), so `npm run db:up` works with no admin
 * rights and no installers.
 *
 *   npm run db:up       start the dev database (port 5433, data in .pgdata)
 *   npm run db:down     stop it
 *   npm run db:status   show status
 *   npm run db:reset    stop + wipe data + start fresh
 *
 * Production uses a normal managed PostgreSQL (set DATABASE_URL) — this
 * script is a local development convenience only.
 */
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const serverRoot = path.resolve(__dirname, '..');
// Default to the OS temp dir: the repo may live inside a cloud-synced folder
// (OneDrive/Dropbox) whose file locks break initdb/pg_ctl. Override with
// PGDATA_DIR if you prefer the data directory elsewhere.
const dataDir =
  process.env.PGDATA_DIR || path.join(os.tmpdir(), 'resume-forge-pgdata');
const port = Number(process.env.PG_PORT || 5433);
const dbName = process.env.PG_DATABASE || 'resumeforge';
const dbUser = 'postgres';
const dbPassword = 'postgres';
const logFile = path.join(dataDir, 'server.log');

/** Locate the platform-specific PostgreSQL binaries. */
function binDir() {
  const { platform, arch } = process;
  let pkg;
  if (platform === 'win32') pkg = '@embedded-postgres/windows-x64';
  else if (platform === 'darwin') pkg = arch === 'arm64' ? '@embedded-postgres/darwin-arm64' : '@embedded-postgres/darwin-x64';
  else if (platform === 'linux') pkg = arch === 'arm64' ? '@embedded-postgres/linux-arm64' : '@embedded-postgres/linux-x64';
  else throw new Error(`Unsupported platform: ${platform}`);

  // npm workspaces may hoist to the repo root — walk up from server/.
  let dir = serverRoot;
  for (let i = 0; i < 4; i++) {
    const candidate = path.join(dir, 'node_modules', pkg, 'native', 'bin');
    if (fs.existsSync(candidate)) return candidate;
    dir = path.dirname(dir);
  }
  throw new Error(
    `PostgreSQL binaries not found (${pkg}). Run "npm install" from the repository root first.`,
  );
}

const EXE = process.platform === 'win32' ? (b) => `${b}.exe` : (b) => b;

function run(bin, args, opts = {}) {
  const result = spawnSync(path.join(binDir(), EXE(bin)), args, {
    cwd: serverRoot,
    encoding: 'utf8',
    stdio: opts.quiet ? 'pipe' : 'inherit',
    ...opts,
  });
  if (result.error) throw result.error;
  if (result.status !== 0 && !opts.allowFail) {
    const out = `${result.stdout || ''}\n${result.stderr || ''}`.trim();
    throw new Error(`${bin} exited with code ${result.status}${out ? `:\n${out}` : ''}`);
  }
  return result;
}

const isUp = () =>
  run('pg_ctl', ['-D', dataDir, 'status'], { allowFail: true, quiet: true }).status === 0;

async function waitForReady() {
  const { default: pg } = await import('pg');
  for (let i = 0; i < 40; i++) {
    try {
      const client = new pg.Client({
        host: '127.0.0.1', port, user: dbUser, password: dbPassword, database: 'postgres',
      });
      await client.connect();
      await client.end();
      return;
    } catch {
      await new Promise((r) => setTimeout(r, 500));
    }
  }
  throw new Error(`PostgreSQL did not become ready on port ${port}. See ${logFile}`);
}

async function ensureDatabase() {
  const { default: pg } = await import('pg');
  const client = new pg.Client({
    host: '127.0.0.1', port, user: dbUser, password: dbPassword, database: 'postgres',
  });
  await client.connect();
  const found = await client.query('SELECT 1 FROM pg_database WHERE datname = $1', [dbName]);
  if (found.rowCount === 0) {
    await client.query(`CREATE DATABASE "${dbName}"`);
    console.log(`Created database "${dbName}".`);
  }
  await client.end();
}

async function up() {
  if (isUp()) {
    console.log(`PostgreSQL already running on port ${port}.`);
    await ensureDatabase();
    return;
  }

  if (!fs.existsSync(path.join(dataDir, 'PG_VERSION'))) {
    // initdb requires an empty target directory — keep the temporary
    // password file OUTSIDE the data dir.
    fs.mkdirSync(dataDir, { recursive: true });
    const pwFile = `${dataDir}.pw`;
    fs.writeFileSync(pwFile, `${dbPassword}\n`);
    console.log('Initializing database cluster (first run only)…');
    run('initdb', [
      '-D', dataDir, '-U', dbUser, '-A', 'scram-sha-256', '--pwfile', pwFile,
      '-E', 'UTF8', '--locale=C',
    ]);
    fs.rmSync(pwFile, { force: true });
  }

  console.log(`Starting PostgreSQL on port ${port}…`);
  run('pg_ctl', [
    '-D', dataDir,
    '-o', `-p ${port} -c listen_addresses=127.0.0.1`,
    '-l', logFile,
    '-w', '-t', '60',
    'start',
  ]);
  await waitForReady();
  await ensureDatabase();
  console.log(`✓ PostgreSQL ready — postgresql://${dbUser}:${dbPassword}@127.0.0.1:${port}/${dbName}`);
}

function down() {
  if (!fs.existsSync(path.join(dataDir, 'PG_VERSION'))) {
    console.log('No local database to stop.');
    return;
  }
  run('pg_ctl', ['-D', dataDir, '-m', 'fast', '-w', '-t', '60', 'stop'], { allowFail: true });
  console.log('✓ PostgreSQL stopped.');
}

async function reset() {
  if (isUp()) down();
  fs.rmSync(dataDir, { recursive: true, force: true });
  console.log('Data directory wiped.');
  await up();
}

function status() {
  console.log(isUp() ? `PostgreSQL running on port ${port}.` : 'PostgreSQL is not running.');
}

const cmd = process.argv[2] || 'up';
const commands = { up, down, stop: down, status, reset };
const fn = commands[cmd];
if (!fn) {
  console.error(`Unknown command "${cmd}". Use: up | down | status | reset`);
  process.exit(1);
}
Promise.resolve(fn()).catch((err) => {
  console.error(err.message || err);
  process.exit(1);
});
