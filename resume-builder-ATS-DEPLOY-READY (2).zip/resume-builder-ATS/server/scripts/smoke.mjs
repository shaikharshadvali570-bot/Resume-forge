/**
 * ResumeForge — end-to-end API smoke test.
 *
 * Exercises the running REST API against a real PostgreSQL database: health,
 * auth, resume CRUD, nested sections, duplicate, ATS and cross-user
 * isolation. Creates and removes only its own test data.
 *
 *   node scripts/smoke.mjs                                  (local server)
 *   API_URL=https://api.example.com/api node scripts/smoke.mjs
 */
const BASE = (process.env.API_URL || 'http://localhost:5000/api').replace(/\/$/, '');

let passed = 0;
const failures = [];

function check(name, condition, detail = '') {
  if (condition) {
    passed += 1;
    console.log(`  ok   ${name}`);
  } else {
    failures.push(`${name}${detail ? ` — ${detail}` : ''}`);
    console.log(`  FAIL ${name}${detail ? ` — ${detail}` : ''}`);
  }
}

async function call(method, path, { token, body } = {}) {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  let json = null;
  try { json = await res.json(); } catch { /* empty body */ }
  return { status: res.status, body: json };
}

const stamp = Date.now();
const userA = { name: 'Smoke A', email: `smoke-a-${stamp}@example.com`, password: 'SmokeTest1' };
const userB = { name: 'Smoke B', email: `smoke-b-${stamp}@example.com`, password: 'SmokeTest1' };

const fullResume = {
  title: 'Smoke Test Resume',
  template: 'modern',
  theme: 'green',
  fullName: 'Smoke Tester',
  email: 'smoke@example.com',
  phone: '555-0100',
  location: 'Remote',
  linkedin: '',
  github: '',
  website: '',
  summary: 'Engineer who led delivery of internal tooling and improved reliability across services.',
  sectionOrder: ['summary', 'experience', 'education', 'skills'],
  hobbies: ['Chess'],
  education: [{ degree: 'B.S. CS', university: 'State University', startYear: '2018', endYear: '2022' }],
  experience: [{
    jobTitle: 'Engineer',
    company: 'Acme',
    currentlyWorking: true,
    description: 'Built the billing pipeline\nReduced errors by 40%',
  }],
  projects: [{ title: 'CLI', organization: 'Open source', description: 'Created a widely used CLI' }],
  skills: [{ name: 'JavaScript' }, { name: 'SQL' }],
  certifications: [{ name: 'AWS SAA' }],
  achievements: [{ title: 'Hackathon winner' }],
  languages: [{ name: 'English', proficiency: 'Native' }],
};

async function main() {
  console.log(`ResumeForge API smoke test → ${BASE}\n`);

  console.log('health');
  const health = await call('GET', '/health');
  check('GET /api/health → 200 ok', health.status === 200 && health.body?.status === 'ok', `status ${health.status}`);
  check('database reachable', health.body?.db === 'up', `db=${health.body?.db}`);

  console.log('\nauth');
  const regA = await call('POST', '/auth/register', { body: userA });
  check('register → 201 + token', regA.status === 201 && Boolean(regA.body?.data?.token), `status ${regA.status}`);
  check('password hash not leaked', !JSON.stringify(regA.body).includes('passwordHash'));
  const tokenA = regA.body?.data?.token;

  const regB = await call('POST', '/auth/register', { body: userB });
  const tokenB = regB.body?.data?.token;
  check('second user registered', regB.status === 201 && Boolean(tokenB));

  check('duplicate email → 409', (await call('POST', '/auth/register', { body: userA })).status === 409);
  check('weak password → 422', (await call('POST', '/auth/register', {
    body: { name: 'Weak', email: `weak-${stamp}@example.com`, password: 'abc' },
  })).status === 422);
  check('wrong password → 401', (await call('POST', '/auth/login', {
    body: { email: userA.email, password: 'Nope12345' },
  })).status === 401);

  const login = await call('POST', '/auth/login', { body: { email: userA.email, password: userA.password } });
  check('login → 200 + token', login.status === 200 && Boolean(login.body?.data?.token), `status ${login.status}`);

  const me = await call('GET', '/auth/me', { token: tokenA });
  check('GET /auth/me → user', me.status === 200 && me.body?.data?.user?.email === userA.email);
  check('no token → 401', (await call('GET', '/auth/me')).status === 401);

  console.log('\nresume CRUD');
  const created = await call('POST', '/resumes', { token: tokenA, body: { title: 'Smoke Resume' } });
  check('create resume → 201', created.status === 201, `status ${created.status}`);
  const resumeId = created.body?.data?.id;

  const updated = await call('PUT', `/resumes/${resumeId}`, { token: tokenA, body: fullResume });
  check('PUT full resume → 200', updated.status === 200, `status ${updated.status}`);
  check('nested sections persisted',
    updated.body?.data?.experience?.length === 1 && updated.body?.data?.skills?.length === 2);

  const fetched = await call('GET', `/resumes/${resumeId}`, { token: tokenA });
  check('GET resume → saved title', fetched.body?.data?.title === 'Smoke Test Resume');

  const list = await call('GET', '/resumes', { token: tokenA });
  check('GET /resumes → includes atsScore', typeof list.body?.data?.[0]?.atsScore === 'number');

  const ats = await call('GET', `/resumes/${resumeId}/ats`, { token: tokenA });
  check('GET /resumes/:id/ats → score + disclaimer',
    ats.status === 200 && typeof ats.body?.data?.score === 'number' && Boolean(ats.body?.data?.disclaimer));

  const scored = await call('POST', '/ats/score', { token: tokenA, body: fullResume });
  check('POST /ats/score → 200, 9 categories',
    scored.status === 200 && scored.body?.data?.categories?.length === 9);

  const copy = await call('POST', `/resumes/${resumeId}/duplicate`, { token: tokenA });
  check('duplicate → copy with sections',
    copy.status === 201 && copy.body?.data?.id !== resumeId && copy.body?.data?.skills?.length === 2);

  console.log('\nsection endpoints');
  const section = await call('POST', `/resumes/${resumeId}/education`, {
    token: tokenA,
    body: { degree: 'M.S. CS', university: 'Tech' },
  });
  check('create nested education → 201', section.status === 201, `status ${section.status}`);
  const sectionId = section.body?.data?.id;
  check('update nested education → 200',
    (await call('PUT', `/education/${sectionId}`, { token: tokenA, body: { degree: 'M.S. AI' } }))
      .body?.data?.degree === 'M.S. AI');

  console.log('\nauthorization (cross-user)');
  check('foreign resume read → 404', (await call('GET', `/resumes/${resumeId}`, { token: tokenB })).status === 404);
  check('foreign resume write → 404',
    (await call('PUT', `/resumes/${resumeId}`, { token: tokenB, body: fullResume })).status === 404);
  check('foreign resume delete → 404', (await call('DELETE', `/resumes/${resumeId}`, { token: tokenB })).status === 404);
  check('foreign section update → 404',
    (await call('PUT', `/education/${sectionId}`, { token: tokenB, body: { degree: 'Stolen' } })).status === 404);

  console.log('\nerror handling');
  const missing = await call('GET', '/resumes/does-not-exist', { token: tokenA });
  check('unknown resume → 404 with message', missing.status === 404 && Boolean(missing.body?.message));
  check('unknown route → 404', (await call('GET', '/nope')).status === 404);
  const badBody = await call('PUT', `/resumes/${resumeId}`, { token: tokenA, body: { title: '' } });
  check('invalid body → 422 with details', badBody.status === 422 && Array.isArray(badBody.body?.details));

  console.log('\ncleanup');
  check('delete resume → 200', (await call('DELETE', `/resumes/${resumeId}`, { token: tokenA })).status === 200);
  await call('DELETE', `/resumes/${copy.body?.data?.id}`, { token: tokenA });
  check('deleted resume unreadable', (await call('GET', `/resumes/${resumeId}`, { token: tokenA })).status === 404);
  check('logout → 200', (await call('POST', '/auth/logout', { token: tokenA })).status === 200);

  console.log(`\n${'-'.repeat(54)}`);
  console.log(`Passed: ${passed}   Failed: ${failures.length}`);
  if (failures.length) {
    console.log('\nFailures:');
    failures.forEach((f) => console.log(`  - ${f}`));
    process.exit(1);
  }
  console.log('\nAll smoke checks passed.');
}

main().catch((err) => {
  console.error('\nSmoke test aborted:', err.message);
  console.error('Is the API running? Start it with: npm run server');
  process.exit(1);
});

