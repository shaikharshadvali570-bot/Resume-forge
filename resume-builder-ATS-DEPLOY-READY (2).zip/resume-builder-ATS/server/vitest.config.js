import { defineConfig } from 'vitest/config';
import { TEST_DATABASE_URL } from './tests/db-config.js';

export default defineConfig({
  test: {
    environment: 'node',
    globalSetup: './tests/global-setup.js',
    setupFiles: ['./tests/setup.js'],
    // Static env for every worker — overrides anything in .env (dotenv does
    // not replace already-set variables, so the test DB always wins).
    env: {
      NODE_ENV: 'test',
      DATABASE_URL: TEST_DATABASE_URL,
      JWT_SECRET: 'test-secret-not-for-production',
      RATE_LIMIT_DISABLED: 'true',
    },
    // One shared test database → run files sequentially.
    fileParallelism: false,
    testTimeout: 30000,
    hookTimeout: 120000,
  },
});
