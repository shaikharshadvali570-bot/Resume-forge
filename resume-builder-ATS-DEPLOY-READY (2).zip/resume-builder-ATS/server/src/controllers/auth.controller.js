import bcrypt from 'bcryptjs';
import { prisma } from '../lib/prisma.js';
import { ApiError } from '../utils/ApiError.js';
import { signToken } from '../utils/token.js';

const SALT_ROUNDS = 10;

/** Public shape of a user — passwordHash never leaves the server. */
export function publicUser(user) {
  if (!user) return null;
  const { passwordHash, ...rest } = user;
  return rest;
}

/** POST /api/auth/register */
export async function register(req, res, next) {
  try {
    const { name, email, password } = req.valid.body;

    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing) {
      throw ApiError.conflict('An account with this email already exists. Try signing in instead.');
    }

    const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);
    const user = await prisma.user.create({ data: { name, email, passwordHash } });

    res.status(201).json({
      success: true,
      data: { user: publicUser(user), token: signToken(user.id) },
    });
  } catch (err) {
    next(err);
  }
}

/** POST /api/auth/login */
export async function login(req, res, next) {
  try {
    const { email, password } = req.valid.body;

    const user = await prisma.user.findUnique({ where: { email } });
    const ok = user && (await bcrypt.compare(password, user.passwordHash));
    if (!ok) {
      throw ApiError.unauthorized('Incorrect email or password. Please try again.');
    }

    res.json({ success: true, data: { user: publicUser(user), token: signToken(user.id) } });
  } catch (err) {
    next(err);
  }
}

/** GET /api/auth/me */
export async function me(req, res) {
  res.json({ success: true, data: { user: req.user } });
}

/**
 * POST /api/auth/logout
 * JWTs are stateless — the client discards its token. The endpoint exists
 * so the frontend has an explicit, symmetric sign-out flow.
 */
export async function logout(_req, res) {
  res.json({ success: true, message: 'Signed out.' });
}
