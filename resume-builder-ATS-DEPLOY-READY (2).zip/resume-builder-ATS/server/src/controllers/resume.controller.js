import { prisma } from '../lib/prisma.js';
import { ApiError } from '../utils/ApiError.js';
import { scoreResume } from '../services/ats.service.js';
import {
  getOwnedResumeFull,
  createResume,
  replaceResume,
  duplicateResume,
  deleteResume,
  resumeInclude,
} from '../services/resume.service.js';

/** GET /api/resumes — list the user's resumes (with ATS score per card). */
export async function listResumes(req, res, next) {
  try {
    const { search, template, sort = '-updatedAt', minAts } = req.valid.query;
    const userId = req.user.id;

    let resumes = await prisma.resume.findMany({
      where: { userId },
      include: resumeInclude,
      orderBy: sort.startsWith('title')
        ? { title: sort.startsWith('-') ? 'desc' : 'asc' }
        : { updatedAt: sort.startsWith('-') ? 'desc' : 'asc' },
    });

    resumes = resumes.map(({ user, ...r }) => ({ ...r, atsScore: scoreResume(r).score }));

    if (template) resumes = resumes.filter((r) => r.template === template);
    if (minAts !== undefined) resumes = resumes.filter((r) => r.atsScore >= minAts);
    if (search) {
      const q = search.toLowerCase();
      resumes = resumes.filter(
        (r) =>
          r.title.toLowerCase().includes(q) ||
          (r.fullName || '').toLowerCase().includes(q),
      );
    }

    res.json({ success: true, data: resumes });
  } catch (err) {
    next(err);
  }
}

/** GET /api/resumes/:id */
export async function getResume(req, res, next) {
  try {
    const resume = await getOwnedResumeFull(req.params.id, req.user.id);
    res.json({ success: true, data: resume });
  } catch (err) {
    next(err);
  }
}

/** POST /api/resumes */
export async function createResumeHandler(req, res, next) {
  try {
    const resume = await createResume(req.user.id, req.valid.body);
    res.status(201).json({ success: true, data: resume });
  } catch (err) {
    next(err);
  }
}

/** PUT /api/resumes/:id — full nested replace (auto-save). */
export async function updateResume(req, res, next) {
  try {
    const resume = await replaceResume(req.params.id, req.user.id, req.valid.body);
    res.json({ success: true, data: resume });
  } catch (err) {
    next(err);
  }
}

/** DELETE /api/resumes/:id */
export async function deleteResumeHandler(req, res, next) {
  try {
    await deleteResume(req.params.id, req.user.id);
    res.json({ success: true, message: 'Resume deleted.' });
  } catch (err) {
    next(err);
  }
}

/** POST /api/resumes/:id/duplicate */
export async function duplicateResumeHandler(req, res, next) {
  try {
    const copy = await duplicateResume(req.params.id, req.user.id);
    res.status(201).json({ success: true, data: copy });
  } catch (err) {
    next(err);
  }
}

/** GET /api/resumes/:id/ats — score the stored resume. */
export async function getResumeAts(req, res, next) {
  try {
    const resume = await getOwnedResumeFull(req.params.id, req.user.id);
    res.json({ success: true, data: scoreResume(resume) });
  } catch (err) {
    next(err);
  }
}
