/**
 * Generic controller factory for resume section entities
 * (education, experience, projects, skills, certifications,
 * achievements, languages).
 *
 * Ownership rule: creating checks the parent resume; updating/deleting
 * checks the child's parent resume. Anything the user does not own
 * returns 404 — never 403 — so foreign IDs cannot be probed.
 */
import { prisma } from '../lib/prisma.js';
import { ApiError } from '../utils/ApiError.js';
import { getOwnedResume } from '../services/resume.service.js';

export function makeSectionHandlers(model) {
  return {
    /** POST /api/resumes/:resumeId/<section> */
    async create(req, res, next) {
      try {
        const { resumeId } = req.params;
        await getOwnedResume(resumeId, req.user.id);

        const count = await prisma[model].count({ where: { resumeId } });
        const row = await prisma[model].create({
          data: { ...req.valid.body, resumeId, order: count },
        });
        res.status(201).json({ success: true, data: row });
      } catch (err) {
        next(err);
      }
    },

    /** PUT /api/<section>/:id */
    async update(req, res, next) {
      try {
        const row = await prisma[model].findUnique({
          where: { id: req.params.id },
          include: { resume: { select: { userId: true } } },
        });
        if (!row || row.resume.userId !== req.user.id) {
          throw ApiError.notFound('Not found.');
        }
        // req.valid.body is a stripped Zod payload — relation/id fields
        // cannot be injected to move the row to another resume.
        const updated = await prisma[model].update({
          where: { id: row.id },
          data: { ...req.valid.body },
        });
        res.json({ success: true, data: updated });
      } catch (err) {
        next(err);
      }
    },

    /** DELETE /api/<section>/:id */
    async remove(req, res, next) {
      try {
        const row = await prisma[model].findUnique({
          where: { id: req.params.id },
          include: { resume: { select: { userId: true } } },
        });
        if (!row || row.resume.userId !== req.user.id) {
          throw ApiError.notFound('Not found.');
        }
        await prisma[model].delete({ where: { id: row.id } });
        res.json({ success: true, message: 'Deleted.' });
      } catch (err) {
        next(err);
      }
    },
  };
}
