import bcrypt from 'bcryptjs';
import { prisma } from '../lib/prisma.js';
import { ApiError } from '../utils/ApiError.js';
import { publicUser } from './auth.controller.js';

const SALT_ROUNDS = 10;

/** PATCH /api/users/me — update name / email / profile image. */
export async function updateProfile(req, res, next) {
  try {
    const updates = req.valid.body;
    if (updates.email && updates.email !== req.user.email) {
      const taken = await prisma.user.findUnique({ where: { email: updates.email } });
      if (taken) throw ApiError.conflict('That email is already in use by another account.');
    }
    const user = await prisma.user.update({ where: { id: req.user.id }, data: updates });
    res.json({ success: true, data: { user: publicUser(user) } });
  } catch (err) {
    next(err);
  }
}

/** PATCH /api/users/me/password — change password (requires current one). */
export async function changePassword(req, res, next) {
  try {
    const { currentPassword, newPassword } = req.valid.body;

    const user = await prisma.user.findUnique({ where: { id: req.user.id } });
    if (!user) throw ApiError.unauthorized('Authentication required. Please sign in.');

    const ok = await bcrypt.compare(currentPassword, user.passwordHash);
    if (!ok) {
      throw ApiError.unprocessable('Your current password is incorrect.', [
        { field: 'currentPassword', message: 'Your current password is incorrect.' },
      ]);
    }
    if (await bcrypt.compare(newPassword, user.passwordHash)) {
      throw ApiError.unprocessable('Your new password must be different from the current one.', [
        { field: 'newPassword', message: 'Choose a password you have not used here before.' },
      ]);
    }

    await prisma.user.update({
      where: { id: user.id },
      data: { passwordHash: await bcrypt.hash(newPassword, SALT_ROUNDS) },
    });

    res.json({ success: true, message: 'Password updated.' });
  } catch (err) {
    next(err);
  }
}

/** GET /api/users/me/stats — dashboard helpers (resume count). */
export async function getStats(req, res, next) {
  try {
    const resumeCount = await prisma.resume.count({ where: { userId: req.user.id } });
    res.json({ success: true, data: { resumeCount } });
  } catch (err) {
    next(err);
  }
}
