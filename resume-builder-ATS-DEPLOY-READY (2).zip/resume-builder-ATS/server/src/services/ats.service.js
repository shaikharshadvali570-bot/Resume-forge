/**
 * ResumeForge — ATS/readiness scoring service (server-side).
 *
 * Heuristic analysis producing an overall 0-100 score plus a per-category
 * breakdown with actionable suggestions. This is an ESTIMATE of ATS
 * readability — every applicant tracking system parses differently, so the
 * API always ships a disclaimer alongside the number.
 *
 * Ported from the original client-side engine (legacy/js/ats.js) to the
 * relational resume shape exposed by the REST API.
 */

export const ATS_CATEGORIES = [
  { id: 'contact', label: 'Contact Information', weight: 15, icon: '📇' },
  { id: 'summary', label: 'Professional Summary', weight: 10, icon: '📝' },
  { id: 'experience', label: 'Experience', weight: 20, icon: '💼' },
  { id: 'education', label: 'Education', weight: 10, icon: '🎓' },
  { id: 'skills', label: 'Skills', weight: 15, icon: '🛠️' },
  { id: 'projects', label: 'Projects', weight: 5, icon: '🚀' },
  { id: 'certs', label: 'Certifications', weight: 5, icon: '📜' },
  { id: 'keywords', label: 'Action Keywords', weight: 10, icon: '🔑' },
  { id: 'length', label: 'Length & Formatting', weight: 10, icon: '📐' },
];

/** Strong action verbs that ATS keyword matching favors. */
const ACTION_KEYWORDS = [
  'led', 'managed', 'developed', 'built', 'designed', 'implemented', 'improved',
  'increased', 'reduced', 'optimized', 'launched', 'created', 'delivered', 'automated',
  'achieved', 'analyzed', 'coordinated', 'migrated', 'architected', 'scaled',
];

/** Common tech/business keywords worth including (suggestion pool). */
const KEYWORD_SUGGESTIONS = [
  'REST API', 'CI/CD', 'cloud', 'SQL', 'data', 'testing', 'agile', 'security',
  'performance', 'leadership', 'collaboration', 'docker', 'machine learning', 'analytics',
];

export const ATS_DISCLAIMER =
  'Estimated ATS/readiness score based on common parsing patterns — not a guarantee of how any particular employer’s ATS will score this resume.';

const countWords = (text) => (text && text.trim() ? text.trim().split(/\s+/).length : 0);

/** Splits a newline-separated description field into bullet strings. */
const bulletsOf = (description) =>
  String(description || '')
    .split(/\r?\n/)
    .map((s) => s.trim())
    .filter(Boolean);

const skillName = (s) => (typeof s === 'string' ? s : s?.name || '');

const validEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(email || ''));

/**
 * Scores a resume payload (API shape — flat personal fields + children arrays).
 * Returns { score, categories, suggestions, missing, wordEstimate, disclaimer }.
 */
export function scoreResume(r = {}) {
  const personal = {
    fullName: r.fullName || '',
    email: r.email || '',
    phone: r.phone || '',
    location: r.location || '',
    linkedin: r.linkedin || '',
    github: r.github || '',
    website: r.website || '',
  };
  const summary = r.summary || '';
  const skills = (r.skills || []).map(skillName).filter(Boolean);
  const education = r.education || [];
  const experience = r.experience || [];
  const projects = r.projects || [];
  const certifications = r.certifications || [];
  const achievements = r.achievements || [];
  const languages = (r.languages || []).map((l) => (typeof l === 'string' ? l : l?.name || '')).filter(Boolean);
  const hobbies = (r.hobbies || []).map(String).filter(Boolean);

  const catScores = {};
  const suggestions = [];

  /* --- Contact (15) --- */
  const contactFields = [
    ['Full name', personal.fullName],
    ['Email', personal.email],
    ['Phone', personal.phone],
    ['Location', personal.location],
    ['LinkedIn', personal.linkedin],
    ['GitHub', personal.github],
  ];
  const filled = contactFields.filter(([, v]) => v && String(v).trim());
  let contactScore = Math.round((filled.length / contactFields.length) * 15);
  if (personal.email && !validEmail(personal.email)) {
    contactScore = Math.max(0, contactScore - 4);
    suggestions.push('Your email address looks invalid — double-check it.');
  }
  catScores.contact = contactScore;
  contactFields.forEach(([label, v]) => {
    if (!v || !String(v).trim()) suggestions.push(`Add your ${label.toLowerCase()} to contact info.`);
  });

  /* --- Summary (10) --- */
  const sumWords = countWords(summary);
  let sumScore = 0;
  if (sumWords >= 30 && sumWords <= 90) sumScore = 10;
  else if (sumWords >= 15) { sumScore = 6; suggestions.push('Expand your summary to 30-90 words for best impact.'); }
  else if (sumWords > 0) { sumScore = 3; suggestions.push('Your summary is very short — aim for 30-90 words.'); }
  else suggestions.push('Write a professional summary — recruiters read it first.');
  catScores.summary = sumScore;

  /* --- Experience (20) --- */
  const expCount = experience.length;
  const expWithBullets = experience.filter((e) => bulletsOf(e.description).length >= 2).length;
  let expScore = 0;
  if (expCount >= 2 && expWithBullets === expCount) expScore = 20;
  else if (expCount >= 1) {
    expScore = expWithBullets ? 12 : 7;
    if (!expWithBullets) suggestions.push('Add 2-4 bullet points describing impact for each experience entry.');
    if (expCount < 2) suggestions.push('Add another experience entry if you have one (internships count).');
  } else suggestions.push('Add at least one work or internship experience with bullet points.');
  catScores.experience = expScore;

  /* --- Education (10) --- */
  const eduCount = education.length;
  catScores.education = eduCount ? 10 : 0;
  if (!eduCount) suggestions.push('Add your education (degree, school, year).');

  /* --- Skills (15) --- */
  const skillCount = skills.length;
  let skillScore = 0;
  if (skillCount >= 8) skillScore = 15;
  else if (skillCount >= 5) { skillScore = 11; suggestions.push('List at least 8 skills for stronger keyword coverage.'); }
  else if (skillCount >= 1) { skillScore = 5; suggestions.push('Add more skills — aim for at least 8 relevant ones.'); }
  else suggestions.push('Add a skills section with your technical and soft skills.');
  catScores.skills = skillScore;

  /* --- Projects (5) --- */
  const projCount = projects.length;
  catScores.projects = projCount ? 5 : 0;
  if (!projCount) suggestions.push('Include a project (personal, academic, or open source) to show hands-on work.');

  /* --- Certifications (5) --- */
  const certCount = certifications.filter((c) => (c.name || '').trim()).length;
  catScores.certs = certCount ? 5 : 0;
  if (!certCount) suggestions.push('Add certifications or online courses if you have them.');

  /* --- Action keywords (10) --- */
  const allText = [
    summary,
    ...experience.flatMap((e) => [e.jobTitle, e.company, ...bulletsOf(e.description)]),
    ...projects.flatMap((p) => [p.title, p.organization, p.technologies, ...bulletsOf(p.description)]),
    ...skills,
  ].join(' ').toLowerCase();
  const found = ACTION_KEYWORDS.filter((k) => allText.includes(k));
  const kwScore = Math.min(10, Math.round((found.length / 6) * 10));
  catScores.keywords = kwScore;
  if (found.length < 4) {
    suggestions.push(`Use more action verbs ("led", "built", "improved") — found ${found.length}, aim for 4+.`);
  }
  if (found.length < 2) {
    const pool = KEYWORD_SUGGESTIONS.filter((k) => !allText.includes(k)).slice(0, 5);
    if (pool.length) suggestions.push(`Consider adding keywords like: ${pool.join(', ')}.`);
  }

  /* --- Length & formatting (10) --- */
  const bulletTotal =
    experience.reduce((n, e) => n + bulletsOf(e.description).length, 0) +
    projects.reduce((n, p) => n + bulletsOf(p.description).length, 0);
  const listTotal = certifications.length + achievements.length;
  const words =
    countWords(
      [summary, ...skills, ...certifications.map((c) => c.name || ''), ...achievements.map((a) => a.title || ''), ...languages, ...hobbies].join(' '),
    ) +
    bulletTotal * 8 +
    listTotal * 6;
  let lenScore = 10;
  if (words < 180) { lenScore = 4; suggestions.push('Your resume looks thin — add more detail to reach a solid one page.'); }
  else if (words > 900) { lenScore = 6; suggestions.push('Your resume may exceed 2 pages — trim older or less relevant content.'); }
  if (expCount && bulletTotal < expCount * 2) {
    lenScore = Math.max(0, lenScore - 3);
    suggestions.push('Add 2-4 bullets per experience entry — ATS parsers favor structured bullets.');
  }
  catScores.length = lenScore;

  const score = Math.min(100, ATS_CATEGORIES.reduce((n, c) => n + (catScores[c.id] || 0), 0));

  const missing = [];
  if (!personal.fullName) missing.push('Name');
  if (!personal.email) missing.push('Email');
  if (!expCount) missing.push('Experience');
  if (!eduCount) missing.push('Education');
  if (!skillCount) missing.push('Skills');

  return {
    score,
    categories: ATS_CATEGORIES.map((c) => ({
      id: c.id,
      label: c.label,
      icon: c.icon,
      weight: c.weight,
      got: catScores[c.id] || 0,
    })),
    suggestions: [...new Set(suggestions)].slice(0, 10),
    missing,
    wordEstimate: words,
    disclaimer: ATS_DISCLAIMER,
  };
}

