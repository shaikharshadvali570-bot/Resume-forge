/**
 * Resume domain service — ownership checks, nested section replacement,
 * and duplication. Every function enforces that the resume belongs to the
 * authenticated user (cross-user access always yields 404 so IDs cannot be
 * enumerated).
 */
import { prisma } from '../lib/prisma.js';
import { ApiError } from '../utils/ApiError.js';

/** Prisma `include` for a resume with all sections in display order. */
/**
 * A section row is "blank" when every field is an empty value — the builder
 * posts each keystroke, so fully empty rows are dropped instead of stored.
 */
const isNotBlankRow = (row) =>
  Object.values(row || {}).some((v) => (typeof v === 'string' ? v.trim() !== '' : Boolean(v)));


export const resumeInclude = {
  education: { orderBy: { order: 'asc' } },
  experience: { orderBy: { order: 'asc' } },
  projects: { orderBy: { order: 'asc' } },
  skills: { orderBy: { order: 'asc' } },
  certifications: { orderBy: { order: 'asc' } },
  achievements: { orderBy: { order: 'asc' } },
  languages: { orderBy: { order: 'asc' } },
};

/**
 * Section relations: `key` = relation name on Resume / API payload field,
 * `model` = Prisma client delegate (model name with lowercase first letter).
 */
const SECTION_RELATIONS = [
  { key: 'education', model: 'education' },
  { key: 'experience', model: 'experience' },
  { key: 'projects', model: 'project' },
  { key: 'skills', model: 'skill' },
  { key: 'certifications', model: 'certification' },
  { key: 'achievements', model: 'achievement' },
  { key: 'languages', model: 'language' },
];

/** Core (non-section) resume columns that a full update may write. */
const CORE_FIELDS = [
  'title', 'template', 'theme',
  'fullName', 'summary', 'email', 'phone', 'location',
  'linkedin', 'github', 'website',
  'sectionOrder', 'hobbies',
];

/**
 * Returns the resume if (and only if) it exists AND belongs to userId.
 * Missing OR foreign resumes both throw 404 — never reveals existence.
 */
export async function getOwnedResume(resumeId, userId) {
  const resume = await prisma.resume.findUnique({ where: { id: resumeId } });
  if (!resume || resume.userId !== userId) {
    throw ApiError.notFound('Resume not found.');
  }
  return resume;
}

/** Fetch a full resume (with sections) enforcing ownership. */
export async function getOwnedResumeFull(resumeId, userId) {
  await getOwnedResume(resumeId, userId);
  const resume = await prisma.resume.findUnique({ where: { id: resumeId }, include: resumeInclude });
  if (!resume) throw ApiError.notFound('Resume not found.');
  const { user, ...rest } = resume; // never leak userId internals beyond need
  return rest;
}

/**
 * Replaces every section of a resume inside one transaction and updates
 * its core fields. Section rows get fresh ids and `order` = array index —
 * the client receives the new rows back in the response.
 */
export async function replaceResume(resumeId, userId, payload) {
  await getOwnedResume(resumeId, userId);

  const core = {};
  for (const key of CORE_FIELDS) {
    if (payload[key] !== undefined) core[key] = payload[key];
  }

  return prisma.$transaction(async (tx) => {
    await tx.resume.update({ where: { id: resumeId }, data: core });

    for (const { key, model } of SECTION_RELATIONS) {
      if (payload[key] === undefined) continue;
      await tx[model].deleteMany({ where: { resumeId } });
      if (payload[key].some(isNotBlankRow)) {
        await tx[model].createMany({
          data: payload[key].filter(isNotBlankRow).map((row, index) => ({ ...row, resumeId, order: index })),
        });
      }
    }

    const updated = await tx.resume.findUnique({ where: { id: resumeId }, include: resumeInclude });
    const { user, ...rest } = updated;
    return rest;
  });
}

/** Creates a new resume for the user (defaults only — open empty draft). */
export async function createResume(userId, { title, template, theme }) {
  return prisma.resume.create({
    data: {
      userId,
      title: title || 'Untitled Resume',
      template: template || 'professional',
      theme: theme || 'blue',
    },
    include: resumeInclude,
  });
}

/** Deep-copies a resume and all of its sections ("Save as a copy"). */
export async function duplicateResume(resumeId, userId) {
  const source = await getOwnedResumeFull(resumeId, userId);

  return prisma.$transaction(async (tx) => {
    const copy = await tx.resume.create({
      data: {
        userId,
        title: `${source.title} Copy`,
        template: source.template,
        theme: source.theme,
        fullName: source.fullName,
        summary: source.summary,
        email: source.email,
        phone: source.phone,
        location: source.location,
        linkedin: source.linkedin,
        github: source.github,
        website: source.website,
        sectionOrder: source.sectionOrder,
        hobbies: source.hobbies,
      },
    });

    for (const { key, model } of SECTION_RELATIONS) {
      const rows = source[key] || [];
      if (rows.length) {
        await tx[model].createMany({
          data: rows.map((row, index) => {
            const { id, resumeId: _rid, ...rest } = row;
            return { ...rest, resumeId: copy.id, order: index };
          }),
        });
      }
    }

    return tx.resume.findUnique({ where: { id: copy.id }, include: resumeInclude });
  });
}

/** Deletes a resume (children cascade). Enforces ownership. */
export async function deleteResume(resumeId, userId) {
  await getOwnedResume(resumeId, userId);
  await prisma.resume.delete({ where: { id: resumeId } });
  return true;
}
