/**
 * Central environment configuration.
 * Values come from server/.env (see .env.example). Throws early in
 * production when required secrets are missing.
 */
import crypto from 'node:crypto';
import 'dotenv/config';

const nodeEnv = process.env.NODE_ENV || 'development';
const isProd = nodeEnv === 'production';
const isTest = nodeEnv === 'test';

let jwtSecret = process.env.JWT_SECRET?.trim();
if (!jwtSecret) {
  if (isProd) {
    throw new Error('JWT_SECRET environment variable is required in production.');
  }
  jwtSecret = crypto.randomBytes(32).toString('hex');
  console.warn(
    '[config] JWT_SECRET is not set — using an ephemeral development secret. ' +
      'Tokens are invalidated whenever the server restarts. Set it in server/.env.',
  );
}

export const config = {
  nodeEnv,
  isProd,
  isTest,
  port: Number(process.env.PORT || 5000),
  clientUrls: (process.env.CLIENT_URL || 'http://localhost:5173')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean),
  jwtSecret,
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '7d',
  rateLimit: {
    disabled: process.env.RATE_LIMIT_DISABLED === 'true' || isTest,
    max: Number(process.env.RATE_LIMIT_MAX || 300),
    authMax: Number(process.env.AUTH_RATE_LIMIT_MAX || 50),
  },
};
