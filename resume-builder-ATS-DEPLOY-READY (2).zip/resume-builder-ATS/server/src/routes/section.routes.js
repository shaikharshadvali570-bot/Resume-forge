import { Router } from 'express';
import { makeSectionHandlers } from '../controllers/section.controller.js';
import { requireAuth } from '../middleware/auth.js';
import { validateBody, validateParams } from '../middleware/validate.js';
import { idParam } from '../validators/schemas.js';
import {
  educationSchema,
  experienceSchema,
  projectSchema,
  skillSchema,
  certificationSchema,
  achievementSchema,
  languageSchema,
} from '../validators/schemas.js';

/**
 * Builds the granular section router:
 *   PUT    /api/<section>/:id
 *   DELETE /api/<section>/:id
 *
 * Creation lives under the parent resume:
 *   POST   /api/resumes/:resumeId/<section>
 */
export function sectionRouter(model, schema) {
  const router = Router();
  const handlers = makeSectionHandlers(model);

  router.use(requireAuth);
  router.put('/:id', validateParams(idParam), validateBody(schema), handlers.update);
  router.delete('/:id', validateParams(idParam), handlers.remove);

  return router;
}

/** All seven section routers keyed by their mount path segment. */
export const sectionRouters = {
  education: sectionRouter('education', educationSchema),
  experience: sectionRouter('experience', experienceSchema),
  projects: sectionRouter('project', projectSchema),
  skills: sectionRouter('skill', skillSchema),
  certifications: sectionRouter('certification', certificationSchema),
  achievements: sectionRouter('achievement', achievementSchema),
  languages: sectionRouter('language', languageSchema),
};
