import { Router } from 'express';
import { updateProfile, changePassword, getStats } from '../controllers/user.controller.js';
import { requireAuth } from '../middleware/auth.js';
import { validateBody } from '../middleware/validate.js';
import { updateProfileSchema, changePasswordSchema } from '../validators/schemas.js';

const router = Router();

router.use(requireAuth);
router.patch('/me', validateBody(updateProfileSchema), updateProfile);
router.patch('/me/password', validateBody(changePasswordSchema), changePassword);
router.get('/me/stats', getStats);

export default router;
