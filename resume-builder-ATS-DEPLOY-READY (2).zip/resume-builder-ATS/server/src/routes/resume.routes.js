import { Router } from 'express';
import {
  listResumes,
  getResume,
  createResumeHandler,
  updateResume,
  deleteResumeHandler,
  duplicateResumeHandler,
  getResumeAts,
} from '../controllers/resume.controller.js';
import { makeSectionHandlers } from '../controllers/section.controller.js';
import { requireAuth } from '../middleware/auth.js';
import { validateBody, validateParams, validateQuery } from '../middleware/validate.js';
import {
  idParam,
  resumeIdParam,
  createResumeSchema,
  educationSchema,
  experienceSchema,
  projectSchema,
  skillSchema,
  certificationSchema,
  achievementSchema,
  languageSchema,
} from '../validators/schemas.js';
import { updateResumeSchema, listResumesQuery } from '../validators/resume.schemas.js';

const router = Router();
router.use(requireAuth); // every resume route needs a signed-in user

/* ---------- Resume CRUD ---------- */
router.get('/', validateQuery(listResumesQuery), listResumes);
router.post('/', validateBody(createResumeSchema), createResumeHandler);
router.get('/:id', validateParams(idParam), getResume);
router.put('/:id', validateParams(idParam), validateBody(updateResumeSchema), updateResume);
router.delete('/:id', validateParams(idParam), deleteResumeHandler);
router.post('/:id/duplicate', validateParams(idParam), duplicateResumeHandler);
router.get('/:id/ats', validateParams(idParam), getResumeAts);

/* ---------- Section creation under a resume ---------- */
const nestedCreate = (model, schema) => [
  validateParams(resumeIdParam),
  validateBody(schema),
  makeSectionHandlers(model).create,
];

router.post('/:resumeId/education', ...nestedCreate('education', educationSchema));
router.post('/:resumeId/experience', ...nestedCreate('experience', experienceSchema));
router.post('/:resumeId/projects', ...nestedCreate('project', projectSchema));
router.post('/:resumeId/skills', ...nestedCreate('skill', skillSchema));
router.post('/:resumeId/certifications', ...nestedCreate('certification', certificationSchema));
router.post('/:resumeId/achievements', ...nestedCreate('achievement', achievementSchema));
router.post('/:resumeId/languages', ...nestedCreate('language', languageSchema));

export default router;
