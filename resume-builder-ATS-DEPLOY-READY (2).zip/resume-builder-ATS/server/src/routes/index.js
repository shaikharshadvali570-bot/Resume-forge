import { Router } from 'express';
import { prisma } from '../lib/prisma.js';
import authRoutes from './auth.routes.js';
import userRoutes from './user.routes.js';
import resumeRoutes from './resume.routes.js';
import atsRoutes from './ats.routes.js';
import { sectionRouters } from './section.routes.js';

const router = Router();

/** GET /api/health — liveness + database reachability. */
router.get('/health', async (_req, res) => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    res.json({ status: 'ok', db: 'up', timestamp: new Date().toISOString() });
  } catch {
    res.status(503).json({ status: 'degraded', db: 'down', timestamp: new Date().toISOString() });
  }
});

router.use('/auth', authRoutes);
router.use('/users', userRoutes);
router.use('/resumes', resumeRoutes);
router.use('/ats', atsRoutes);

/* Granular section endpoints:
   PUT/DELETE /api/<section>/:id  (creation lives under /api/resumes/:resumeId) */
router.use('/education', sectionRouters.education);
router.use('/experience', sectionRouters.experience);
router.use('/projects', sectionRouters.projects);
router.use('/skills', sectionRouters.skills);
router.use('/certifications', sectionRouters.certifications);
router.use('/achievements', sectionRouters.achievements);
router.use('/languages', sectionRouters.languages);

export default router;
