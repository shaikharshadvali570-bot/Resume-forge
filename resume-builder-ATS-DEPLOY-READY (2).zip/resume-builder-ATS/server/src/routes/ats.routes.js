import { Router } from 'express';
import { scoreResume } from '../services/ats.service.js';
import { requireAuth } from '../middleware/auth.js';
import { validateBody } from '../middleware/validate.js';
import { atsScoreSchema } from '../validators/resume.schemas.js';

const router = Router();

/**
 * POST /api/ats/score — stateless scoring of a (draft) resume payload.
 * Lets the live builder compute ATS feedback before/while saving.
 */
router.post('/score', requireAuth, validateBody(atsScoreSchema), (req, res) => {
  res.json({ success: true, data: scoreResume(req.valid.body) });
});

export default router;
