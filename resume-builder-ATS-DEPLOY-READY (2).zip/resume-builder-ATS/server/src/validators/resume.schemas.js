import { z } from 'zod';
import {
  TEMPLATES,
  THEMES,
  SECTION_IDS,
  str,
  urlField,
  educationSchema,
  experienceSchema,
  projectSchema,
  skillSchema,
  certificationSchema,
  achievementSchema,
  languageSchema,
} from './schemas.js';
import {
  looseSkillSchema,
  looseCertificationSchema,
  looseAchievementSchema,
  looseLanguageSchema,
} from './schemas.js';


/* ------------------------------------------------------------------ */
/* Full nested resume payload — used by PUT /api/resumes/:id           */
/* (the auto-save endpoint replaces all sections in one transaction).  */
/* ------------------------------------------------------------------ */

export const updateResumeSchema = z.object({
  title: z.string().trim().min(1, 'Title is required.').max(120),
  template: z.enum(TEMPLATES),
  theme: z.enum(THEMES),
  fullName: str(120).default(''),
  email: str(254).default(''),
  phone: str(40).default(''),
  location: str(140).default(''),
  linkedin: urlField.default(''),
  github: urlField.default(''),
  website: urlField.default(''),
  summary: str(5000).default(''),
  sectionOrder: z.array(z.enum(SECTION_IDS)).max(20).default([]),
  hobbies: z.array(str(80)).max(60).default([]),
  education: z.array(educationSchema).max(30).default([]),
  experience: z.array(experienceSchema).max(40).default([]),
  projects: z.array(projectSchema).max(40).default([]),
  skills: z.array(looseSkillSchema).max(150).default([]),
  certifications: z.array(looseCertificationSchema).max(40).default([]),
  achievements: z.array(looseAchievementSchema).max(40).default([]),
  languages: z.array(looseLanguageSchema).max(30).default([]),
});

/** List query: search / sort / filter. */
export const listResumesQuery = z.object({
  search: z.string().trim().max(100).optional(),
  template: z.enum(TEMPLATES).optional(),
  sort: z.enum(['-updatedAt', 'updatedAt', 'title', '-title']).optional(),
  minAts: z.coerce.number().int().min(0).max(100).optional(),
});

/**
 * ATS scoring payload — intentionally lenient: it must accept partially
 * filled drafts coming from the live builder.
 */
export const atsScoreSchema = z.object({
  fullName: str(120).optional(),
  email: str(254).optional(),
  phone: str(40).optional(),
  location: str(140).optional(),
  linkedin: str(500).optional(),
  github: str(500).optional(),
  website: str(500).optional(),
  summary: str(5000).optional(),
  hobbies: z.array(str(80)).optional(),
  education: z.array(z.any()).optional(),
  experience: z.array(z.any()).optional(),
  projects: z.array(z.any()).optional(),
  skills: z.array(z.any()).optional(),
  certifications: z.array(z.any()).optional(),
  achievements: z.array(z.any()).optional(),
  languages: z.array(z.any()).optional(),
});
