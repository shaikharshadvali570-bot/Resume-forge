import { z } from 'zod';

/* ------------------------------------------------------------------ */
/* Shared constants                                                    */
/* ------------------------------------------------------------------ */

export const TEMPLATES = ['professional', 'modern', 'minimal', 'ats', 'classic'];
export const THEMES = ['blue', 'navy', 'green', 'purple', 'black', 'mono'];
export const SECTION_IDS = [
  'summary',
  'experience',
  'education',
  'projects',
  'skills',
  'certifications',
  'achievements',
  'languages',
  'hobbies',
];

const PW_RULES = [
  { regex: /.{8,}/, message: 'Password must be at least 8 characters.' },
  { regex: /[0-9]/, message: 'Password must contain a number.' },
  { regex: /[A-Z]/, message: 'Password must contain an uppercase letter.' },
];

export function passwordPolicy(v) {
  return PW_RULES.every((r) => r.regex.test(v));
}

export function passwordIssues(v) {
  return PW_RULES.filter((r) => !r.regex.test(v)).map((r) => ({ message: r.message }));
}

const emailField = z.string().trim().toLowerCase().email('Enter a valid email address.').max(254);
const passwordField = z.string().min(8, 'Password must be at least 8 characters.').max(128);
const nameField = z.string().trim().min(2, 'Name must be at least 2 characters.').max(80);

/** Optional URL: empty string or absolute http(s) URL. */
export const urlField = z
  .string()
  .max(500)
  .refine((v) => v === '' || /^https?:\/\/\S+$/i.test(v), {
    message: 'Must be a valid URL starting with http:// or https://',
  });

const optionalEmailField = z
  .string()
  .max(254)
  .refine((v) => v === '' || /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v), {
    message: 'Enter a valid email address.',
  });

export const str = (max) => z.string().max(max);

/* ------------------------------------------------------------------ */
/* Auth                                                                */
/* ------------------------------------------------------------------ */

export const registerSchema = z.object({
  name: nameField,
  email: emailField,
  password: passwordField.refine((v) => /[0-9]/.test(v) && /[A-Z]/.test(v), {
    message: 'Password must include at least one number and one uppercase letter.',
  }),
});

export const loginSchema = z.object({
  email: emailField,
  password: z.string().min(1, 'Password is required.').max(128),
});

export const updateProfileSchema = z
  .object({
    name: nameField.optional(),
    email: emailField.optional(),
    profileImage: z.string().max(2048).nullable().optional(),
  })
  .refine((v) => Object.keys(v).length > 0, { message: 'Provide at least one field to update.' });

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, 'Current password is required.').max(128),
  newPassword: z
    .string()
    .min(8, 'Password must be at least 8 characters.')
    .max(128)
    .refine((v) => /[0-9]/.test(v) && /[A-Z]/.test(v), {
      message: 'Password must include at least one number and one uppercase letter.',
    }),
});

/* ------------------------------------------------------------------ */
/* Params                                                              */
/* ------------------------------------------------------------------ */

export const idParam = z.object({ id: z.string().trim().min(1).max(64) });
export const resumeIdParam = z.object({ resumeId: z.string().trim().min(1).max(64) });

/* ------------------------------------------------------------------ */
/* Resumes                                                             */
/* ------------------------------------------------------------------ */

export const createResumeSchema = z.object({
  title: z.string().trim().min(1).max(120).optional(),
  template: z.enum(TEMPLATES).optional(),
  theme: z.enum(THEMES).optional(),
});

/* ------------------------------------------------------------------ */
/* Section entity inputs (granular CRUD endpoints)                     */
/* ------------------------------------------------------------------ */

export const educationSchema = z.object({
  degree: str(160).default(''),
  university: str(160).default(''),
  location: str(120).default(''),
  startYear: str(40).default(''),
  endYear: str(40).default(''),
  description: str(2000).default(''),
});

export const experienceSchema = z.object({
  jobTitle: str(160).default(''),
  company: str(160).default(''),
  location: str(120).default(''),
  startDate: str(40).default(''),
  endDate: str(40).default(''),
  currentlyWorking: z.boolean().default(false),
  description: str(6000).default(''),
});

export const projectSchema = z.object({
  title: str(160).default(''),
  organization: str(160).default(''),
  technologies: str(400).default(''),
  startDate: str(40).default(''),
  endDate: str(40).default(''),
  description: str(6000).default(''),
  projectUrl: urlField.default(''),
});

export const skillSchema = z.object({
  name: z.string().trim().min(1, 'Skill name is required.').max(80),
  category: str(80).default(''),
  level: str(40).default(''),
});

export const certificationSchema = z.object({
  name: z.string().trim().min(1, 'Certification name is required.').max(200),
  issuingOrganization: str(160).default(''),
  issueDate: str(60).default(''),
  credentialUrl: urlField.default(''),
});

export const achievementSchema = z.object({
  title: z.string().trim().min(1, 'Achievement title is required.').max(200),
  description: str(2000).default(''),
  date: str(60).default(''),
});

export const languageSchema = z.object({
  name: z.string().trim().min(1, 'Language name is required.').max(60),
  proficiency: str(40).default(''),
});


/* ------------------------------------------------------------------ */
/* Lenient row variants for the nested resume PUT                      */
/* ------------------------------------------------------------------ */
/* The builder auto-saves continuously, so a row can legitimately be   */
/* half-typed (e.g. a new certification with no name yet). The nested  */
/* PUT accepts those rows; the granular section endpoints above keep   */
/* the strict schemas (create/update one complete row at a time).      */
export const looseSkillSchema = skillSchema.extend({ name: str(80).default('') });
export const looseCertificationSchema = certificationSchema.extend({ name: str(200).default('') });
export const looseAchievementSchema = achievementSchema.extend({ title: str(200).default('') });
export const looseLanguageSchema = languageSchema.extend({ name: str(60).default('') });

