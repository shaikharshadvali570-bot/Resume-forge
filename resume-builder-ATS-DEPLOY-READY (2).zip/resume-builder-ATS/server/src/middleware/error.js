import { ApiError } from '../utils/ApiError.js';
import { config } from '../config.js';

/** 404 for any unmatched API route. */
export function notFoundHandler(req, _res, next) {
  next(ApiError.notFound(`Route not found: ${req.method} ${req.originalUrl}`));
}

/**
 * Centralized error handler.
 * Response shape is always: { success: false, message, details? }
 */
export function errorHandler(err, _req, res, _next) {
  let status = 500;
  let message = 'Something went wrong. Please try again.';
  let details;

  if (err instanceof ApiError) {
    status = err.status;
    message = err.message;
    details = err.details;
  } else if (err?.type === 'entity.parse.failed') {
    status = 400;
    message = 'Invalid JSON in request body.';
  } else if (err?.code === 'P2025') {
    status = 404;
    message = 'Resource not found.';
  } else if (err?.code === 'P2002') {
    status = 409;
    message = 'That value already exists.';
  } else if (err?.code === 'P2023') {
    status = 400;
    message = 'Invalid identifier format.';
  }

  if (status >= 500 && !config.isTest) {
    console.error('[error]', err);
  }

  res.status(status).json({
    success: false,
    message,
    ...(details ? { details } : {}),
  });
}
