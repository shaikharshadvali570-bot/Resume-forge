import { ApiError } from '../utils/ApiError.js';

function formatIssues(error) {
  return error.issues.map((i) => ({
    field: i.path.join('.') || '(body)',
    message: i.message,
  }));
}

/**
 * Validates req.body against a Zod schema.
 * Puts the parsed (and coerced/stripped) value on `req.valid.body`.
 * Validation failures return HTTP 422 with per-field details.
 */
export function validateBody(schema) {
  return (req, _res, next) => {
    const result = schema.safeParse(req.body ?? {});
    if (!result.success) {
      return next(ApiError.unprocessable('Validation failed.', formatIssues(result.error)));
    }
    req.valid = { ...(req.valid || {}), body: result.data };
    next();
  };
}

/** Validates req.params against a Zod schema (e.g. id paths). */
export function validateParams(schema) {
  return (req, _res, next) => {
    const result = schema.safeParse(req.params ?? {});
    if (!result.success) {
      return next(ApiError.unprocessable('Invalid path parameter.', formatIssues(result.error)));
    }
    req.valid = { ...(req.valid || {}), params: result.data };
    next();
  };
}

/** Validates req.query against a Zod schema. */
export function validateQuery(schema) {
  return (req, _res, next) => {
    const result = schema.safeParse(req.query ?? {});
    if (!result.success) {
      return next(ApiError.unprocessable('Invalid query parameter.', formatIssues(result.error)));
    }
    req.valid = { ...(req.valid || {}), query: result.data };
    next();
  };
}
