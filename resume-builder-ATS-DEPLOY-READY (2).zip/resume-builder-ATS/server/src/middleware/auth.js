import { ApiError } from '../utils/ApiError.js';
import { verifyToken } from '../utils/token.js';
import { prisma } from '../lib/prisma.js';

/**
 * JWT authentication middleware.
 * Expects: Authorization: Bearer <token>
 * On success sets `req.user` (never contains passwordHash).
 */
export async function requireAuth(req, _res, next) {
  try {
    const header = req.headers.authorization || '';
    const [scheme, token] = header.split(' ');
    if (scheme !== 'Bearer' || !token) {
      throw ApiError.unauthorized('Authentication required. Please sign in.');
    }

    let payload;
    try {
      payload = verifyToken(token);
    } catch {
      throw ApiError.unauthorized('Your session has expired or is invalid. Please sign in again.');
    }

    const user = await prisma.user.findUnique({
      where: { id: payload.sub },
      select: { id: true, name: true, email: true, profileImage: true, createdAt: true },
    });
    if (!user) {
      throw ApiError.unauthorized('Your session has expired or is invalid. Please sign in again.');
    }

    req.user = user;
    next();
  } catch (err) {
    next(err);
  }
}
