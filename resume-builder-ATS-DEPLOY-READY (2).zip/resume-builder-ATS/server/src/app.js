import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { config } from './config.js';
import apiRoutes from './routes/index.js';
import { notFoundHandler, errorHandler } from './middleware/error.js';

/** Dev-friendly CORS: allow any localhost/127.0.0.1 origin + configured URLs. */
function corsOrigin(origin, callback) {
  if (!origin) return callback(null, true); // curl / server-to-server
  const allowed =
    config.clientUrls.includes(origin) ||
    (!config.isProd && /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin));
  callback(null, allowed);
}

export function createApp() {
  const app = express();

  app.disable('x-powered-by');
  app.use(helmet());
  app.use(cors({ origin: corsOrigin, methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'] }));
  app.use(express.json({ limit: '1mb' }));

  if (!config.rateLimit.disabled) {
    app.use(
      '/api',
      rateLimit({
        windowMs: 15 * 60 * 1000,
        limit: config.rateLimit.max,
        standardHeaders: 'draft-7',
        legacyHeaders: false,
        message: { success: false, message: 'Too many requests — please slow down and try again shortly.' },
      }),
    );

    const authLimiter = rateLimit({
      windowMs: 15 * 60 * 1000,
      limit: config.rateLimit.authMax,
      standardHeaders: 'draft-7',
      legacyHeaders: false,
      message: { success: false, message: 'Too many authentication attempts — please try again later.' },
    });
    app.use('/api/auth/login', authLimiter);
    app.use('/api/auth/register', authLimiter);
  }

  app.use('/api', apiRoutes);
  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
