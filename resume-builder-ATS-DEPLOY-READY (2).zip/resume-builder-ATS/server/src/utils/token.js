import jwt from 'jsonwebtoken';
import { config } from '../config.js';

/** Signs a short-lived-ish JWT carrying the user id in `sub`. */
export function signToken(userId) {
  return jwt.sign({ sub: userId }, config.jwtSecret, { expiresIn: config.jwtExpiresIn });
}

/** Verifies a JWT and returns its payload. Throws on invalid/expired. */
export function verifyToken(token) {
  return jwt.verify(token, config.jwtSecret);
}
