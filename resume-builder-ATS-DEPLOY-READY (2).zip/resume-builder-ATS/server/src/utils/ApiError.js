/**
 * ApiError — the single error type the centralized error handler knows about.
 * Anything thrown that is NOT an ApiError is treated as an unexpected 500.
 */
export class ApiError extends Error {
  constructor(status, message, details) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.details = details;
  }

  static badRequest(message = 'Bad request.', details) {
    return new ApiError(400, message, details);
  }
  static unauthorized(message = 'Authentication required.') {
    return new ApiError(401, message);
  }
  static forbidden(message = 'You do not have permission to do that.') {
    return new ApiError(403, message);
  }
  static notFound(message = 'Resource not found.') {
    return new ApiError(404, message);
  }
  static conflict(message = 'That value already exists.', details) {
    return new ApiError(409, message, details);
  }
  static unprocessable(message = 'Validation failed.', details) {
    return new ApiError(422, message, details);
  }
  static internal(message = 'Something went wrong. Please try again.') {
    return new ApiError(500, message);
  }
}
