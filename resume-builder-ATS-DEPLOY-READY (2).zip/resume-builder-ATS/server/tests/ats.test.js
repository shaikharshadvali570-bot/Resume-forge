import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { app, registerUser, resumePayload } from './helpers.js';

const auth = (token) => `Bearer ${token}`;

/** A resume crafted to max out every ATS category. */
const strongResume = {
  fullName: 'Morgan Reed',
  email: 'morgan@example.com',
  phone: '555-0199',
  location: 'Seattle, WA',
  linkedin: 'https://linkedin.com/in/morganreed',
  github: 'https://github.com/morganreed',
  website: '',
  summary:
    'Senior platform engineer with eight years of experience designing distributed systems ' +
    'and leading high-performing teams. Delivered measurable improvements in reliability, ' +
    'performance, and developer productivity across multiple product lines and environments.',
  education: [{ degree: 'B.S. Computer Science', university: 'University of Washington' }],
  experience: [
    {
      jobTitle: 'Senior Engineer',
      company: 'Contoso',
      description:
        'Led migration of the billing platform to microservices\n' +
        'Improved deployment frequency by 80% through CI/CD automation\n' +
        'Reduced incident count by 45% with better observability',
    },
    {
      jobTitle: 'Engineer',
      company: 'Fabrikam',
      description:
        'Built internal tooling used by 200+ engineers\n' +
        'Optimized SQL queries cutting p95 latency in half\n' +
        'Managed cross-team delivery of three major releases',
    },
  ],
  projects: [
    { title: 'Telemetry CLI', organization: 'Open Source', technologies: 'Go, Docker', description: 'Created a CLI adopted by 50+ companies' },
  ],
  skills: ['Go', 'Kubernetes', 'SQL', 'Terraform', 'Python', 'Observability', 'Leadership', 'Agile'],
  certifications: [{ name: 'CKA', issuingOrganization: 'CNCF' }],
  achievements: [{ title: 'Speaker at KubeCon' }],
  languages: [{ name: 'English' }],
  hobbies: [],
};

describe('ATS scoring service', () => {
  it('scores an empty resume low and lists missing essentials', async () => {
    const { token } = await registerUser('ats-empty');
    const res = await request(app)
      .post('/api/ats/score')
      .set('Authorization', auth(token))
      .send({});

    expect(res.status).toBe(200);
    const { data } = res.body;
    expect(data.score).toBeLessThan(50);
    expect(data.missing).toContain('Name');
    expect(data.missing).toContain('Experience');
    expect(data.missing).toContain('Education');
    expect(data.suggestions.length).toBeGreaterThan(0);
    expect(data.categories).toHaveLength(9);
    expect(data.disclaimer).toMatch(/estimated/i);
  });

  it('scores a complete resume highly', async () => {
    const { token } = await registerUser('ats-full');
    const res = await request(app)
      .post('/api/ats/score')
      .set('Authorization', auth(token))
      .send(strongResume);

    expect(res.status).toBe(200);
    const { data } = res.body;
    expect(data.score).toBeGreaterThanOrEqual(85);
    expect(data.missing).toEqual([]);
    // Category weights must sum with the score (100 max).
    const weightSum = data.categories.reduce((n, c) => n + c.weight, 0);
    expect(weightSum).toBe(100);
  });

  it('scores a partially filled resume between the extremes', async () => {
    const { token } = await registerUser('ats-partial');
    const res = await request(app)
      .post('/api/ats/score')
      .set('Authorization', auth(token))
      .send(resumePayload());

    expect(res.status).toBe(200);
    expect(res.body.data.score).toBeGreaterThan(40);
    expect(res.body.data.score).toBeLessThan(90);
  });

  it('returns the stored resume score via GET /api/resumes/:id/ats', async () => {
    const { token } = await registerUser('ats-saved');
    const created = await request(app)
      .post('/api/resumes')
      .set('Authorization', auth(token))
      .send({ title: 'Scored' });
    await request(app)
      .put(`/api/resumes/${created.body.data.id}`)
      .set('Authorization', auth(token))
      .send(resumePayload());

    const res = await request(app)
      .get(`/api/resumes/${created.body.data.id}/ats`)
      .set('Authorization', auth(token));

    expect(res.status).toBe(200);
    expect(res.body.data.score).toBeGreaterThan(0);
    expect(res.body.data).toHaveProperty('suggestions');
    expect(res.body.data.disclaimer).toBeTruthy();
  });

  it('exposes an atsScore on each dashboard list item', async () => {
    const { token } = await registerUser('ats-list');
    const created = await request(app)
      .post('/api/resumes')
      .set('Authorization', auth(token))
      .send({ title: 'Card Resume' });
    await request(app)
      .put(`/api/resumes/${created.body.data.id}`)
      .set('Authorization', auth(token))
      .send(resumePayload());

    const res = await request(app)
      .get('/api/resumes')
      .set('Authorization', auth(token));
    expect(res.status).toBe(200);
    expect(res.body.data[0].atsScore).toBeGreaterThan(0);
  });

  it('requires authentication', async () => {
    const res = await request(app).post('/api/ats/score').send({});
    expect(res.status).toBe(401);
  });
});
