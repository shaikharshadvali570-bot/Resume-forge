import { afterAll } from 'vitest';

// Close the Prisma connection pool when each worker finishes, otherwise
// open sockets keep the vitest process alive.
afterAll(async () => {
  const { prisma } = await import('../src/lib/prisma.js');
  await prisma.$disconnect();
});
