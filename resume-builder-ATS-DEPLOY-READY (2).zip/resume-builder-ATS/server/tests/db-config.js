/** Shared constants for the isolated test database. */
export const TEST_PORT = 5549;
export const TEST_DB = 'resumeforge_test';
export const TEST_DATABASE_URL = `postgresql://postgres:postgres@127.0.0.1:${TEST_PORT}/${TEST_DB}`;
