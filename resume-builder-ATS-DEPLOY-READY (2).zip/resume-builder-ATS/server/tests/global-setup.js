/**
 * Vitest global setup: boots an ephemeral embedded PostgreSQL, creates the
 * test database, and pushes the Prisma schema. Torn down after all tests.
 * This makes `npm test` self-contained on any machine — no system
 * PostgreSQL or Docker required.
 */
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import EmbeddedPostgres from 'embedded-postgres';
import { TEST_PORT, TEST_DB, TEST_DATABASE_URL } from './db-config.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const serverRoot = path.resolve(__dirname, '..');
// NOTE: the repo may live inside a cloud-synced folder (OneDrive/Dropbox)
// whose file locks break initdb. Keep ephemeral test data in the OS temp
// dir instead of the project tree.
const dataDir = path.join(os.tmpdir(), `rf-pgtest-data-${TEST_PORT}`);

export default async function globalSetup() {
  process.env.NODE_ENV = 'test';
  process.env.DATABASE_URL = TEST_DATABASE_URL;
  process.env.JWT_SECRET = 'test-secret-not-for-production';
  process.env.RATE_LIMIT_DISABLED = 'true';

  fs.rmSync(dataDir, { recursive: true, force: true });

  const pg = new EmbeddedPostgres({
    databaseDir: dataDir,
    user: 'postgres',
    password: 'postgres',
    port: TEST_PORT,
    persistent: false,
  });

  await pg.initialise();
  await pg.start();
  await pg.createDatabase(TEST_DB);

  const push = spawnSync(
    'npx',
    ['prisma', 'db', 'push', '--skip-generate', '--accept-data-loss', '--force-reset'],
    {
      cwd: serverRoot,
      env: { ...process.env, DATABASE_URL: TEST_DATABASE_URL },
      stdio: 'inherit',
      shell: true,
    },
  );
  if (push.status !== 0) {
    await pg.stop().catch(() => {});
    throw new Error('prisma db push failed — see output above.');
  }

  return async function globalTeardown() {
    await pg.stop();
    fs.rmSync(dataDir, { recursive: true, force: true });
  };
}
