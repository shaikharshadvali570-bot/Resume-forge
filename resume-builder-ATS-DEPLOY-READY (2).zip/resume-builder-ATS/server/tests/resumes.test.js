import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { app, registerUser, resumePayload } from './helpers.js';

const auth = (token) => `Bearer ${token}`;

async function createResume(token, body = {}) {
  const res = await request(app)
    .post('/api/resumes')
    .set('Authorization', auth(token))
    .send(body);
  expect(res.status).toBe(201);
  return res.body.data;
}

describe('resume CRUD', () => {
  it('creates a resume with defaults', async () => {
    const { token } = await registerUser('cr');
    const res = await request(app)
      .post('/api/resumes')
      .set('Authorization', auth(token))
      .send({ title: 'Fresh Resume' });

    expect(res.status).toBe(201);
    expect(res.body.data.title).toBe('Fresh Resume');
    expect(res.body.data.template).toBe('professional');
    expect(res.body.data).toHaveProperty('id');
    expect(res.body.data.experience).toEqual([]);
  });

  it('lists only the signed-in user’s resumes', async () => {
    const a = await registerUser('list-a');
    const b = await registerUser('list-b');
    await createResume(a.token, { title: 'A Resume' });
    await createResume(b.token, { title: 'B Resume' });

    const res = await request(app)
      .get('/api/resumes')
      .set('Authorization', auth(a.token));

    expect(res.status).toBe(200);
    expect(res.body.data).toHaveLength(1);
    expect(res.body.data[0].title).toBe('A Resume');
    expect(res.body.data[0]).toHaveProperty('atsScore');
  });

  it('fetches a single resume with its sections', async () => {
    const { token } = await registerUser('get');
    const created = await createResume(token, { title: 'Get Me' });

    const res = await request(app)
      .get(`/api/resumes/${created.id}`)
      .set('Authorization', auth(token));

    expect(res.status).toBe(200);
    expect(res.body.data.title).toBe('Get Me');
    expect(res.body.data.skills).toEqual([]);
  });

  it('updates a resume with full nested payload (auto-save flow)', async () => {
    const { token } = await registerUser('put');
    const created = await createResume(token);

    const res = await request(app)
      .put(`/api/resumes/${created.id}`)
      .set('Authorization', auth(token))
      .send(resumePayload({ title: 'Updated Title' }));

    expect(res.status).toBe(200);
    expect(res.body.data.title).toBe('Updated Title');
    expect(res.body.data.fullName).toBe('Jamie Doe');
    expect(res.body.data.skills).toHaveLength(2);
    expect(res.body.data.experience).toHaveLength(1);
    expect(res.body.data.experience[0].jobTitle).toBe('Engineer');
    expect(res.body.data.education[0].university).toBe('UT Austin');
    expect(res.body.data.languages[0].name).toBe('English');

    // Re-fetch to confirm persistence in PostgreSQL.
    const reread = await request(app)
      .get(`/api/resumes/${created.id}`)
      .set('Authorization', auth(token));
    expect(reread.body.data.summary).toContain('decade of experience');
    expect(reread.body.data.skills.map((s) => s.name)).toEqual(['JavaScript', 'SQL']);
  });

  it('replaces sections on update (removed rows are gone)', async () => {
    const { token } = await registerUser('replace');
    const created = await createResume(token);
    await request(app)
      .put(`/api/resumes/${created.id}`)
      .set('Authorization', auth(token))
      .send(resumePayload());

    const emptied = await request(app)
      .put(`/api/resumes/${created.id}`)
      .set('Authorization', auth(token))
      .send(resumePayload({ skills: [], experience: [], education: [], languages: [] }));

    expect(emptied.status).toBe(200);
    expect(emptied.body.data.skills).toEqual([]);
    expect(emptied.body.data.experience).toEqual([]);
  });

  it('rejects an invalid template with 422', async () => {
    const { token } = await registerUser('badtpl');
    const created = await createResume(token);

    const res = await request(app)
      .put(`/api/resumes/${created.id}`)
      .set('Authorization', auth(token))
      .send(resumePayload({ template: 'rainbow' }));

    expect(res.status).toBe(422);
    expect(res.body.details.some((d) => d.field === 'template')).toBe(true);
  });

  it('deletes a resume; subsequent fetch returns 404', async () => {
    const { token } = await registerUser('del');
    const created = await createResume(token, { title: 'Doomed' });

    const del = await request(app)
      .delete(`/api/resumes/${created.id}`)
      .set('Authorization', auth(token));
    expect(del.status).toBe(200);

    const after = await request(app)
      .get(`/api/resumes/${created.id}`)
      .set('Authorization', auth(token));
    expect(after.status).toBe(404);
  });

  it('duplicates a resume including all sections', async () => {
    const { token } = await registerUser('dup');
    const created = await createResume(token, { title: 'Original' });
    await request(app)
      .put(`/api/resumes/${created.id}`)
      .set('Authorization', auth(token))
      .send(resumePayload({ title: 'Original' }));

    const res = await request(app)
      .post(`/api/resumes/${created.id}/duplicate`)
      .set('Authorization', auth(token));

    expect(res.status).toBe(201);
    expect(res.body.data.id).not.toBe(created.id);
    expect(res.body.data.title).toBe('Original Copy');
    expect(res.body.data.skills).toHaveLength(2);
    expect(res.body.data.experience).toHaveLength(1);
  });
});

describe('authorization (ownership)', () => {
  it('requires authentication for all resume routes', async () => {
    const list = await request(app).get('/api/resumes');
    expect(list.status).toBe(401);

    const get = await request(app).get('/api/resumes/some-id');
    expect(get.status).toBe(401);

    const post = await request(app).post('/api/resumes').send({});
    expect(post.status).toBe(401);
  });

  it('prevents cross-user access to a resume (GET/PUT/DELETE → 404)', async () => {
    const owner = await registerUser('owner');
    const attacker = await registerUser('attacker');
    const mine = await createResume(owner.token, { title: 'Private' });

    const get = await request(app)
      .get(`/api/resumes/${mine.id}`)
      .set('Authorization', auth(attacker.token));
    expect(get.status).toBe(404);

    const put = await request(app)
      .put(`/api/resumes/${mine.id}`)
      .set('Authorization', auth(attacker.token))
      .send(resumePayload({ title: 'Hijacked' }));
    expect(put.status).toBe(404);

    const del = await request(app)
      .delete(`/api/resumes/${mine.id}`)
      .set('Authorization', auth(attacker.token));
    expect(del.status).toBe(404);

    // Owner still sees the untouched resume.
    const still = await request(app)
      .get(`/api/resumes/${mine.id}`)
      .set('Authorization', auth(owner.token));
    expect(still.status).toBe(200);
    expect(still.body.data.title).toBe('Private');
  });

  it('prevents duplicating another user’s resume', async () => {
    const owner = await registerUser('owner2');
    const attacker = await registerUser('attacker2');
    const mine = await createResume(owner.token);

    const res = await request(app)
      .post(`/api/resumes/${mine.id}/duplicate`)
      .set('Authorization', auth(attacker.token));
    expect(res.status).toBe(404);
  });

  it('protects section rows owned by another user (404)', async () => {
    const owner = await registerUser('sec-owner');
    const attacker = await registerUser('sec-attacker');
    const mine = await createResume(owner.token);

    const skill = await request(app)
      .post(`/api/resumes/${mine.id}/skills`)
      .set('Authorization', auth(owner.token))
      .send({ name: 'Private Skill' });
    expect(skill.status).toBe(201);

    const update = await request(app)
      .put(`/api/skills/${skill.body.data.id}`)
      .set('Authorization', auth(attacker.token))
      .send({ name: 'Stolen' });
    expect(update.status).toBe(404);

    const remove = await request(app)
      .delete(`/api/skills/${skill.body.data.id}`)
      .set('Authorization', auth(attacker.token));
    expect(remove.status).toBe(404);
  });
});

describe('granular section endpoints', () => {
  it('supports create → update → delete for sections under a resume', async () => {
    const { token } = await registerUser('sections');
    const resume = await createResume(token);

    const created = await request(app)
      .post(`/api/resumes/${resume.id}/education`)
      .set('Authorization', auth(token))
      .send({ degree: 'M.S. AI', university: 'Stanford', startYear: '2020', endYear: '2022' });
    expect(created.status).toBe(201);
    expect(created.body.data.degree).toBe('M.S. AI');
    expect(created.body.data.order).toBe(0);

    const updated = await request(app)
      .put(`/api/education/${created.body.data.id}`)
      .set('Authorization', auth(token))
      .send({ degree: 'M.S. Machine Learning' });
    expect(updated.status).toBe(200);
    expect(updated.body.data.degree).toBe('M.S. Machine Learning');

    const removed = await request(app)
      .delete(`/api/education/${created.body.data.id}`)
      .set('Authorization', auth(token));
    expect(removed.status).toBe(200);

    const gone = await request(app)
      .put(`/api/education/${created.body.data.id}`)
      .set('Authorization', auth(token))
      .send({ degree: 'Ghost' });
    expect(gone.status).toBe(404);
  });
});

