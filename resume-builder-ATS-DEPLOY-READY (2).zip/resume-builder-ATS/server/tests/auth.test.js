import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { app, registerUser, uniqueEmail } from './helpers.js';

describe('health', () => {
  it('GET /api/health returns ok with the database reachable', async () => {
    const res = await request(app).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ok');
    expect(res.body.db).toBe('up');
  });
});

describe('authentication', () => {
  it('registers a new user and returns a token without leaking the hash', async () => {
    const email = uniqueEmail('signup');
    const res = await request(app).post('/api/auth/register').send({
      name: 'Ada Lovelace',
      email,
      password: 'SecurePass1',
    });

    expect(res.status).toBe(201);
    expect(res.body.success).toBe(true);
    expect(res.body.data.token).toBeTruthy();
    expect(res.body.data.user.email).toBe(email);
    expect(res.body.data.user).not.toHaveProperty('passwordHash');
    expect(JSON.stringify(res.body)).not.toContain('passwordHash');
  });

  it('rejects a duplicate email with 409', async () => {
    const email = uniqueEmail('dup');
    const first = await request(app).post('/api/auth/register').send({
      name: 'First User', email, password: 'SecurePass1',
    });
    expect(first.status).toBe(201);

    const second = await request(app).post('/api/auth/register').send({
      name: 'Second User', email, password: 'SecurePass1',
    });
    expect(second.status).toBe(409);
    expect(second.body.success).toBe(false);
  });

  it('rejects a weak password at registration with 422', async () => {
    const res = await request(app).post('/api/auth/register').send({
      name: 'Weak Password',
      email: uniqueEmail('weak'),
      password: 'abc', // too short, no number, no uppercase
    });
    expect(res.status).toBe(422);
    expect(res.body.success).toBe(false);
    expect(Array.isArray(res.body.details)).toBe(true);
  });

  it('rejects an invalid email with 422', async () => {
    const res = await request(app).post('/api/auth/register').send({
      name: 'Bad Email', email: 'not-an-email', password: 'SecurePass1',
    });
    expect(res.status).toBe(422);
  });

  it('logs in with correct credentials', async () => {
    const { email, password } = await registerUser('login-ok');
    const res = await request(app).post('/api/auth/login').send({ email, password });

    expect(res.status).toBe(200);
    expect(res.body.data.token).toBeTruthy();
    expect(res.body.data.user.email).toBe(email);
  });

  it('rejects a wrong password with 401', async () => {
    const { email } = await registerUser('login-bad');
    const res = await request(app).post('/api/auth/login').send({
      email,
      password: 'WrongPassword1',
    });
    expect(res.status).toBe(401);
    expect(res.body.message).toMatch(/incorrect email or password/i);
  });

  it('rejects an unknown email with 401 (same message — no enumeration)', async () => {
    const res = await request(app).post('/api/auth/login').send({
      email: uniqueEmail('ghost'),
      password: 'Whatever1',
    });
    expect(res.status).toBe(401);
    expect(res.body.message).toMatch(/incorrect email or password/i);
  });

  it('GET /api/auth/me works with a valid token', async () => {
    const { token, email } = await registerUser('me');
    const res = await request(app)
      .get('/api/auth/me')
      .set('Authorization', `Bearer ${token}`);

    expect(res.status).toBe(200);
    expect(res.body.data.user.email).toBe(email);
    expect(res.body.data.user).not.toHaveProperty('passwordHash');
  });

  it('rejects missing, garbage, and tampered tokens with 401', async () => {
    const noToken = await request(app).get('/api/auth/me');
    expect(noToken.status).toBe(401);

    const garbage = await request(app)
      .get('/api/auth/me')
      .set('Authorization', 'Bearer not.a.jwt');
    expect(garbage.status).toBe(401);

    // Valid structure signed with a different secret → must fail verification.
    const tampered =
      'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1c2VySWQifQ.7pJ0Nf1xQ0m3zK7qZ8sW2vY4bC6dE8gA0iJ2kL4mN6o';
    const forged = await request(app)
      .get('/api/auth/me')
      .set('Authorization', `Bearer ${tampered}`);
    expect(forged.status).toBe(401);
  });

  it('POST /api/auth/logout succeeds for signed-in users', async () => {
    const { token } = await registerUser('logout');
    const res = await request(app)
      .post('/api/auth/logout')
      .set('Authorization', `Bearer ${token}`);
    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
  });
});
