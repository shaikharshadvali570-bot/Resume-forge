import request from 'supertest';
import { createApp } from '../src/app.js';

/** Single app instance for all tests (stateless JWT auth → safe to share). */
export const app = createApp();

let counter = 0;

/** Generates a unique email so tests never collide on the shared DB. */
export function uniqueEmail(prefix = 'user') {
  counter += 1;
  return `${prefix}-${Date.now()}-${counter}@example.com`;
}

/** Registers a fresh user and returns { user, token, email, password }. */
export async function registerUser(prefix = 'user') {
  const email = uniqueEmail(prefix);
  const password = 'Password1!';
  const res = await request(app).post('/api/auth/register').send({
    name: 'Test User',
    email,
    password,
  });
  if (res.status !== 201) {
    throw new Error(`register failed: ${res.status} ${JSON.stringify(res.body)}`);
  }
  return { ...res.body.data, email, password };
}

/** Logs in and returns { user, token }. */
export async function loginUser(email, password) {
  const res = await request(app).post('/api/auth/login').send({ email, password });
  if (res.status !== 200) {
    throw new Error(`login failed: ${res.status} ${JSON.stringify(res.body)}`);
  }
  return res.body.data;
}

/** Minimal valid full-resume payload for PUT /api/resumes/:id. */
export function resumePayload(overrides = {}) {
  return {
    title: 'My Resume',
    template: 'professional',
    theme: 'blue',
    fullName: 'Jamie Doe',
    email: 'jamie@example.com',
    phone: '555-0100',
    location: 'Austin, TX',
    linkedin: 'https://linkedin.com/in/jamie',
    github: '',
    website: '',
    summary: 'Engineer with a decade of experience building reliable systems.',
    sectionOrder: ['summary', 'skills', 'experience'],
    hobbies: ['Reading'],
    education: [
      { degree: 'B.S. CS', university: 'UT Austin', location: 'Austin, TX', startYear: '2012', endYear: '2016', description: '' },
    ],
    experience: [
      {
        jobTitle: 'Engineer', company: 'Acme', location: 'Remote',
        startDate: '2020-01', endDate: '', currentlyWorking: true,
        description: 'Shipped features\nReduced costs by 30%',
      },
    ],
    projects: [],
    skills: [
      { name: 'JavaScript', category: 'Languages', level: '' },
      { name: 'SQL', category: 'Databases', level: '' },
    ],
    certifications: [],
    achievements: [],
    languages: [{ name: 'English', proficiency: 'Native' }],
    ...overrides,
  };
}
