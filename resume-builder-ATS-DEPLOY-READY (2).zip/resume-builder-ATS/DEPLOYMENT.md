# ResumeForge Production Deployment

## Architecture
- Frontend: Vercel (`client/`)
- Backend: Render (`server/`)
- Database: Neon PostgreSQL

## 1. Push to GitHub
Push this repository after confirming no `.env`, database data, `node_modules`, or build output is present.

## 2. Create Neon database
Create a PostgreSQL project and copy the connection string. Keep `DATABASE_URL` private.

## 3. Deploy backend on Render
Use **New → Blueprint** and select the GitHub repository. Render will read `render.yaml`.

Set:
- `DATABASE_URL` = Neon connection string
- `CLIENT_URL` = Vercel URL (update after frontend deployment)

Render runs Prisma migrations before starting the API.

Test:
`https://YOUR-RENDER-DOMAIN/api/health`

## 4. Deploy frontend on Vercel
Import the same GitHub repository.

- Root Directory: `client`
- Framework: Vite
- Environment variable: `VITE_API_URL=https://YOUR-RENDER-DOMAIN/api`

Deploy.

## 5. Finish CORS configuration
Copy the Vercel production URL into Render:

`CLIENT_URL=https://YOUR-VERCEL-DOMAIN`

Redeploy the Render service.

## 6. Production smoke test
Test:
1. `/api/health`
2. Signup
3. Login
4. Create resume
5. Edit/save resume
6. Refresh and verify saved data
7. Logout/login again

Never commit production secrets to GitHub.
