import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';

/**
 * Client unit tests. Pure logic only (resume model, payload building, export
 * helpers) so they run fast in a plain Node environment — no DOM required.
 */
export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'node',
    include: ['src/**/*.test.{js,jsx}'],
  },
});
