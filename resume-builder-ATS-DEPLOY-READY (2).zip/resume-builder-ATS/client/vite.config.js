import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Dev: Vite serves the client on 5173 and proxies /api to the Express
// server on 5000. Prod: set VITE_API_URL to the deployed API base URL
// (e.g. https://resume-forge-api.onrender.com/api) — see README.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:5000',
        changeOrigin: true,
      },
    },
  },
});
