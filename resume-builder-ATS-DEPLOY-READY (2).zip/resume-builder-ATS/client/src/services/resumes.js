/**
 * ResumeForge — typed API wrappers around the REST endpoints.
 * Every function unwraps the `{ success, data }` envelope.
 */
import api from './api.js';

const data = (res) => res.data.data;

export const authApi = {
  register: (payload) => api.post('/auth/register', payload).then(data),
  login: (payload) => api.post('/auth/login', payload).then(data),
  me: () => api.get('/auth/me').then(data),
  logout: () => api.post('/auth/logout').then((res) => res.data),
};

export const resumesApi = {
  list: (params = {}) => api.get('/resumes', { params }).then(data),
  get: (id) => api.get(`/resumes/${id}`).then(data),
  create: (payload = {}) => api.post('/resumes', payload).then(data),
  update: (id, payload) => api.put(`/resumes/${id}`, payload).then(data),
  remove: (id) => api.delete(`/resumes/${id}`).then((res) => res.data),
  duplicate: (id) => api.post(`/resumes/${id}/duplicate`).then(data),
  ats: (id) => api.get(`/resumes/${id}/ats`).then(data),
};

export const atsApi = {
  /** Stateless scoring of a (possibly unsaved) draft payload. */
  score: (payload) => api.post('/ats/score', payload).then(data),
};

export const usersApi = {
  updateProfile: (payload) => api.patch('/users/me', payload).then(data),
  changePassword: (payload) => api.patch('/users/me/password', payload).then((res) => res.data),
  stats: () => api.get('/users/me/stats').then(data),
};
