/**
 * ResumeForge — API client (Axios).
 *
 * Base URL resolution:
 *   - Dev (Vite): relative `/api` → proxied to the Express server (vite.config.js).
 *   - Prod: set VITE_API_URL to the deployed API base URL
 *     (e.g. https://resume-forge-api.onrender.com/api).
 * Auth token is persisted in localStorage (UI preference only — resume data
 * itself always lives in PostgreSQL via the REST API).
 */

import axios from 'axios';

const TOKEN_KEY = 'rf_token';

export function getToken() {
  try {
    return localStorage.getItem(TOKEN_KEY) || '';
  } catch {
    return '';
  }
}

export function setToken(token) {
  try {
    if (token) localStorage.setItem(TOKEN_KEY, token);
    else localStorage.removeItem(TOKEN_KEY);
  } catch {
    /* storage unavailable — token stays in memory only */
  }
}

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '/api',
  timeout: 20000,
  headers: { 'Content-Type': 'application/json' },
});

api.interceptors.request.use((config) => {
  const token = getToken();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (err) => {
    // Expired/invalid token → drop it so the auth guard redirects to login.
    if (err?.response?.status === 401 && getToken()) {
      const url = err?.config?.url || '';
      if (!url.includes('/auth/login') && !url.includes('/auth/register')) {
        setToken('');
        window.dispatchEvent(new CustomEvent('rf:unauthorized'));
      }
    }
    return Promise.reject(err);
  },
);

/** Human-readable message from any API error shape. */
export function apiErrorMessage(err, fallback = 'Something went wrong. Please try again.') {
  const data = err?.response?.data;
  if (data?.details?.length) {
    return data.details.map((d) => d.message || d).join(' ');
  }
  if (data?.message) return data.message;
  if (err?.message) return err.message;
  return fallback;
}

export default api;
