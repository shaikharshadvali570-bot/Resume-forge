/**
 * ResumeForge — shared React hooks.
 */
import { useCallback, useEffect, useRef, useState } from 'react';

/**
 * Debounced auto-save for the resume builder.
 * `save` fires only after `delay` ms without changes and exposes save state
 * for the "Saving… / Saved / Save failed" indicator in the editor toolbar.
 */
export function useAutosave(value, save, delay = 1200) {
  const [state, setState] = useState('idle'); // idle | dirty | saving | saved | error
  const [lastSavedAt, setLastSavedAt] = useState(null);
  const saveRef = useRef(save);
  saveRef.current = save;
  const snapshotRef = useRef(null);
  const timerRef = useRef(null);
  const mountedRef = useRef(false);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  // Skip the very first render (data just loaded) — only save real edits.
  const firstRender = useRef(true);
  const key = JSON.stringify(value);
  useEffect(() => {
    if (firstRender.current) {
      firstRender.current = false;
      snapshotRef.current = key;
      return undefined;
    }
    if (key === snapshotRef.current) return undefined;

    setState('dirty');
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(async () => {
      if (mountedRef.current) setState('saving');
      try {
        await saveRef.current(value);
        snapshotRef.current = key;
        if (mountedRef.current) {
          setState('saved');
          setLastSavedAt(new Date());
        }
      } catch {
        if (mountedRef.current) setState('error');
      }
    }, delay);

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [key, delay]);

  /** Saves immediately (used by the "Save now" button / before navigating). */
  const flush = useCallback(async () => {
    if (timerRef.current) clearTimeout(timerRef.current);
    if (JSON.stringify(value) === snapshotRef.current) return true;
    setState('saving');
    try {
      await saveRef.current(value);
      snapshotRef.current = JSON.stringify(value);
      setState('saved');
      setLastSavedAt(new Date());
      return true;
    } catch (err) {
      setState('error');
      throw err;
    }
  }, [value]);

  return { state, lastSavedAt, flush };
}

/** Applies + persists the dark/light app theme (non-sensitive UI preference). */
export function useAppTheme() {
  const [theme, setTheme] = useState(() => {
    try {
      return localStorage.getItem('rf_app_theme') || 'dark';
    } catch {
      return 'dark';
    }
  });

  useEffect(() => {
    document.documentElement.setAttribute('data-app-theme', theme);
    try {
      localStorage.setItem('rf_app_theme', theme);
    } catch {
      /* storage unavailable — theme still applies for this session */
    }
  }, [theme]);

  const toggle = useCallback(() => {
    setTheme((t) => (t === 'light' ? 'dark' : 'light'));
  }, []);

  return { theme, setTheme, toggle };
}

/** Warns before closing the tab while there are unsaved edits. */
export function useUnsavedChangesWarning(active) {
  useEffect(() => {
    if (!active) return undefined;
    const handler = (event) => {
      event.preventDefault();
      event.returnValue = '';
      return '';
    };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, [active]);
}

/** Reads (and keeps in sync) a small localStorage-backed UI preference. */
export function useLocalPreference(key, initial) {
  const [value, setValue] = useState(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw === null ? initial : JSON.parse(raw);
    } catch {
      return initial;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      /* ignore quota / private-mode errors */
    }
  }, [key, value]);

  return [value, setValue];
}
