/**
 * ResumeForge — account settings (/profile).
 * Profile details, password change and non-sensitive UI preferences.
 */
import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { usersApi } from '../services/resumes.js';
import { apiErrorMessage } from '../services/api.js';
import { useAuth } from '../context/AuthContext.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { useAppTheme, useLocalPreference } from '../hooks/hooks.js';
import Navbar, { Footer } from '../components/Navbar.jsx';
import Particles from '../components/Particles.jsx';
import { Field } from '../components/forms.jsx';
import { CenteredSpinner } from '../components/states.jsx';
import { TEMPLATES, THEMES } from '../utils/resume-model.js';

const emailOk = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(v || ''));

const initials = (name) => (name || '?').trim().charAt(0).toUpperCase();

const memberSince = (iso) => {
  if (!iso) return '—';
  try { return new Date(iso).toLocaleDateString(undefined, { month: 'long', year: 'numeric' }); }
  catch { return '—'; }
};

export default function Profile() {
  const { user, setUser } = useAuth();
  const { toast } = useToast();
  const { theme, setTheme } = useAppTheme();

  const [form, setForm] = useState({ name: '', email: '', profileImage: '' });
  const [formErrors, setFormErrors] = useState({});
  const [pw, setPw] = useState({ currentPassword: '', newPassword: '', confirm: '' });
  const [pwErrors, setPwErrors] = useState({});
  const [busy, setBusy] = useState('');
  const [stats, setStats] = useState(null);
  const [defaults, setDefaults] = useLocalPreference('rf_resume_defaults', {
    template: 'professional',
    theme: 'blue',
  });

  useEffect(() => {
    if (user) {
      setForm({
        name: user.name || '',
        email: user.email || '',
        profileImage: user.profileImage || '',
      });
    }
  }, [user]);

  useEffect(() => {
    let alive = true;
    usersApi.stats()
      .then((data) => { if (alive) setStats(data); })
      .catch(() => { if (alive) setStats(null); });
    return () => { alive = false; };
  }, []);

  const avatarLetter = useMemo(() => initials(form.name || user?.name), [form.name, user?.name]);

  const saveProfile = async (event) => {
    event.preventDefault();
    const errs = {};
    if (form.name.trim().length < 2) errs.name = 'Name must be at least 2 characters.';
    if (!emailOk(form.email)) errs.email = 'Enter a valid email address.';
    if (form.profileImage && !/^https?:\/\/\S+$/i.test(form.profileImage)) {
      errs.profileImage = 'Image URL must start with http:// or https://';
    }
    setFormErrors(errs);
    if (Object.keys(errs).length) return;

    setBusy('profile');
    try {
      const { user: updated } = await usersApi.updateProfile({
        name: form.name.trim(),
        email: form.email.trim().toLowerCase(),
        profileImage: form.profileImage.trim() || null,
      });
      setUser(updated);
      toast.success('Profile updated.');
    } catch (err) {
      toast.error(apiErrorMessage(err, 'Could not update your profile.'));
    } finally {
      setBusy('');
    }
  };

  const savePassword = async (event) => {
    event.preventDefault();
    const errs = {};
    if (!pw.currentPassword) errs.currentPassword = 'Enter your current password.';
    if (pw.newPassword.length < 8) errs.newPassword = 'Password must be at least 8 characters.';
    else if (!/[0-9]/.test(pw.newPassword) || !/[A-Z]/.test(pw.newPassword)) {
      errs.newPassword = 'Include at least one uppercase letter and one number.';
    }
    if (pw.confirm !== pw.newPassword) errs.confirm = 'Passwords do not match.';
    setPwErrors(errs);
    if (Object.keys(errs).length) return;

    setBusy('password');
    try {
      await usersApi.changePassword({
        currentPassword: pw.currentPassword,
        newPassword: pw.newPassword,
      });
      setPw({ currentPassword: '', newPassword: '', confirm: '' });
      toast.success('Password updated.');
    } catch (err) {
      toast.error(apiErrorMessage(err, 'Could not update your password.'));
    } finally {
      setBusy('');
    }
  };

  return (
    <>
      <Particles />
      <Navbar />
      <main className="settings-page">
        <h1>Account Settings</h1>
        <p className="sub">Manage your profile, security and editor preferences. These settings are separate from your resume content.</p>

        <section className="settings-card">
          <h2>Profile</h2>
          <div className="profile-row">
            <div className="avatar" aria-hidden="true">
              {form.profileImage ? <img src={form.profileImage} alt="" /> : avatarLetter}
            </div>
            <div>
              <div className="p-name">{user?.name || '—'}</div>
              <div className="p-email">{user?.email || '—'}</div>
              <div className="account-meta">
                <span>Member since {memberSince(user?.createdAt)}</span>
                <span>
                  {stats ? `${stats.resumeCount} resume${stats.resumeCount === 1 ? '' : 's'}` : '— resumes'}
                </span>
              </div>
            </div>
          </div>

          <form onSubmit={saveProfile} noValidate>
            <Field label="Display name" error={formErrors.name}>
              <input value={form.name} maxLength={80} autoComplete="name" onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
            </Field>
            <Field label="Email" error={formErrors.email} hint="Changing this changes your sign-in address.">
              <input type="email" value={form.email} maxLength={254} autoComplete="email" onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} />
            </Field>
            <Field label="Profile image URL" error={formErrors.profileImage}>
              <input type="url" value={form.profileImage} placeholder="https://…" onChange={(e) => setForm((f) => ({ ...f, profileImage: e.target.value }))} />
            </Field>
            <button type="submit" className="btn primary" disabled={busy === 'profile'}>
              {busy === 'profile' ? 'Saving…' : 'Save profile'}
            </button>
          </form>
        </section>

        <section className="settings-card">
          <h2>Password</h2>
          <form onSubmit={savePassword} noValidate>
            <Field label="Current password" error={pwErrors.currentPassword}>
              <input type="password" autoComplete="current-password" value={pw.currentPassword} onChange={(e) => setPw((p) => ({ ...p, currentPassword: e.target.value }))} />
            </Field>
            <Field label="New password" error={pwErrors.newPassword} hint="8+ characters with a number and an uppercase letter.">
              <input type="password" autoComplete="new-password" value={pw.newPassword} onChange={(e) => setPw((p) => ({ ...p, newPassword: e.target.value }))} />
            </Field>
            <Field label="Confirm new password" error={pwErrors.confirm}>
              <input type="password" autoComplete="new-password" value={pw.confirm} onChange={(e) => setPw((p) => ({ ...p, confirm: e.target.value }))} />
            </Field>
            <button type="submit" className="btn primary" disabled={busy === 'password'}>
              {busy === 'password' ? 'Updating…' : 'Update password'}
            </button>
          </form>
        </section>

        <section className="settings-card">
          <h2>Preferences</h2>
          <Field label="App appearance">
            <div className="picker-row">
              <button type="button" className={`btn${theme === 'dark' ? ' primary' : ''}`} onClick={() => setTheme('dark')}>Dark</button>
              <button type="button" className={`btn${theme === 'light' ? ' primary' : ''}`} onClick={() => setTheme('light')}>Light</button>
            </div>
          </Field>
          <Field label="Default template for new resumes">
            <select
              value={defaults.template}
              onChange={(e) => setDefaults((d) => ({ ...d, template: e.target.value }))}
            >
              {TEMPLATES.map((t) => (<option key={t.id} value={t.id}>{t.name}</option>))}
            </select>
          </Field>
          <Field label="Default theme colour for new resumes">
            <select
              value={defaults.theme}
              onChange={(e) => setDefaults((d) => ({ ...d, theme: e.target.value }))}
            >
              {THEMES.map((t) => (<option key={t.id} value={t.id}>{t.name}</option>))}
            </select>
          </Field>
          <p className="muted small">Preferences are stored locally in your browser — your resume data always lives in your account.</p>
        </section>

        <p className="switch-link"><Link to="/dashboard">← Back to dashboard</Link></p>
      </main>
      <Footer />
    </>
  );
}

