/**
 * ResumeForge — resume builder.
 *
 * Left: accordion editor (personal, summary, experience, education, projects,
 * skills, certifications, achievements, languages, hobbies, design, ATS).
 * Right: live preview of the actual A4 paper that gets exported.
 *
 * Every edit is debounced and auto-saved to PostgreSQL through
 * `PUT /api/resumes/:id` (see hooks/useAutosave).
 */
import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { resumesApi } from '../services/resumes.js';
import { apiErrorMessage } from '../services/api.js';
import { useToast } from '../context/ToastContext.jsx';
import { useAutosave, useUnsavedChangesWarning } from '../hooks/hooks.js';
import { emptyResume, getTemplateMeta, getThemeMeta } from '../utils/resume-model.js';
import { exportResumeDOCX, exportResumePDF, resumeFileStem } from '../utils/export.js';
import Navbar from '../components/Navbar.jsx';
import Particles from '../components/Particles.jsx';
import { Accordion } from '../components/forms.jsx';
import { CenteredSpinner, ErrorPanel } from '../components/states.jsx';
import DesignForm from '../components/edit-design.jsx';
import { PersonalForm, SummaryForm } from '../components/edit-personal.jsx';
import { EducationFields, EntryEditor, ExperienceFields, ProjectFields } from '../components/edit-entries.jsx';
import { AchievementsForm, CertsForm, HobbiesForm, LanguagesForm, SkillsForm } from '../components/edit-misc.jsx';
import AtsPanel from '../components/AtsPanel.jsx';
import ResumePreview from '../components/ResumePreview.jsx';

/** Section arrays replaced wholesale by PUT /api/resumes/:id. */
const SECTION_KEYS = [
  'education', 'experience', 'projects', 'skills',
  'certifications', 'achievements', 'languages',
];

/** Strips client-only metadata so the payload matches the API contract. */
const cleanRow = (row) => {
  const { id, _key, resumeId, order, ...rest } = row || {};
  return rest;
};

/** Local editor state → validated API payload. */
export function toPayload(r = {}) {
  const payload = {
    title: (r.title || '').trim() || 'Untitled Resume',
    template: r.template || 'professional',
    theme: r.theme || 'blue',
    fullName: r.fullName || '',
    email: r.email || '',
    phone: r.phone || '',
    location: r.location || '',
    linkedin: r.linkedin || '',
    github: r.github || '',
    website: r.website || '',
    summary: r.summary || '',
    sectionOrder: Array.isArray(r.sectionOrder) ? r.sectionOrder : [],
    hobbies: (r.hobbies || []).map((h) => String(h)).filter((h) => h.trim()),
  };
  for (const key of SECTION_KEYS) {
    payload[key] = (r[key] || []).map(cleanRow);
  }
  return payload;
}

const STATUS_TEXT = {
  idle: 'All changes saved',
  dirty: 'Unsaved changes…',
  saving: 'Saving…',
  error: '⚠ Save failed — your next edit will retry',
};

/** Route container: loads the resume (ownership enforced by the API). */
export default function Builder() {
  const { id } = useParams();
  const [loading, setLoading] = useState(true);
  const [resume, setResume] = useState(null);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      setResume(await resumesApi.get(id));
    } catch (err) {
      setResume(null);
      setError(apiErrorMessage(err, 'Could not load this resume.'));
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => { load(); }, [load]);

  if (loading) {
    return (
      <>
        <Particles />
        <Navbar showUser={false} />
        <main className="builder-loading"><CenteredSpinner label="Loading your resume…" /></main>
      </>
    );
  }

  if (error || !resume) {
    return (
      <>
        <Particles />
        <Navbar showUser={false} />
        <main>
          <ErrorPanel
            title="Resume unavailable"
            message={error || 'This resume does not exist, or it belongs to another account.'}
            onRetry={load}
            retryText="Try again"
          />
          <p className="switch-link"><Link to="/dashboard">← Back to dashboard</Link></p>
        </main>
      </>
    );
  }

  // key → fresh editor state whenever a different resume is opened.
  return <BuilderEditor key={resume.id} initialResume={resume} />;
}

/** The editor itself (auto-save + live preview + exports). */
function BuilderEditor({ initialResume }) {
  const id = initialResume.id;
  const navigate = useNavigate();
  const { toast } = useToast();
  const [resume, setResume] = useState(() => ({ ...emptyResume(), ...initialResume }));
  const [zoom, setZoom] = useState(1);
  const [pane, setPane] = useState('editor');
  const [exporting, setExporting] = useState('');
  const [atsScore, setAtsScore] = useState(null);

  const patch = useCallback((partial) => setResume((prev) => ({ ...prev, ...partial })), []);

  const save = useCallback(async (value) => {
    await resumesApi.update(id, toPayload(value));
  }, [id]);

  const { state: saveState, lastSavedAt, flush } = useAutosave(resume, save, 1200);
  useUnsavedChangesWarning(saveState === 'dirty' || saveState === 'saving');

  useEffect(() => {
    document.title = `${resume.title || 'Untitled Resume'} — ResumeForge`;
  }, [resume.title]);

  /** Exports always flush pending edits first, so the file matches the DB. */
  const flushQuietly = async () => { try { await flush(); } catch { /* status pill reports it */ } };

  const stem = () => resumeFileStem(resume.title, resume.fullName);

  const downloadPDF = async () => {
    setExporting('pdf');
    await flushQuietly();
    try {
      await exportResumePDF(document.getElementById('resume'), `${stem()}.pdf`);
      toast.success('PDF downloaded.');
    } catch (err) {
      toast.error(apiErrorMessage(err, 'PDF export failed.'));
    } finally {
      setExporting('');
    }
  };

  const downloadDOCX = async () => {
    setExporting('docx');
    await flushQuietly();
    try {
      await exportResumeDOCX(toPayload(resume), resume.sectionOrder, `${stem()}.docx`);
      toast.success('DOCX downloaded.');
    } catch (err) {
      toast.error(apiErrorMessage(err, 'DOCX export failed.'));
    } finally {
      setExporting('');
    }
  };

  const saveNow = async () => {
    try {
      await flush();
      toast.success('Resume saved.');
    } catch (err) {
      toast.error(apiErrorMessage(err, 'Could not save your resume.'));
    }
  };

  const setZoomBy = (delta) => setZoom((z) => Math.min(1.4, Math.max(0.6, Number((z + delta).toFixed(2)))));

  const templateMeta = getTemplateMeta(resume.template);
  const themeMeta = getThemeMeta(resume.theme);
  const filledCount = ['fullName', 'email', 'phone', 'location', 'linkedin', 'github', 'website']
    .filter((k) => (resume[k] || '').trim()).length;

  const toolbar = (
    <>
      <Link className="btn" to={`/resumes/${id}/preview`}>👁 Preview</Link>
      <button type="button" className="btn" disabled={exporting === 'docx'} onClick={downloadDOCX}>
        {exporting === 'docx' ? '…' : '📝 DOCX'}
      </button>
      <button type="button" className="btn primary" disabled={exporting === 'pdf'} onClick={downloadPDF}>
        {exporting === 'pdf' ? '…' : '📄 PDF'}
      </button>
    </>
  );

  return (
    <>
      <Particles />
      <Navbar actions={toolbar} showUser={false} />

      <div className="editor-toolbar no-print">
        <button type="button" className="btn sm" onClick={() => navigate('/dashboard')}>← Dashboard</button>
        <span className={`save-status ${saveState}`} aria-live="polite">{STATUS_TEXT[saveState] || ''}</span>
        {saveState === 'saved' && lastSavedAt ? (
          <span className="save-time">at {lastSavedAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
        ) : null}
        {atsScore === null ? null : (
          <span className={`ats-badge ${atsScore >= 75 ? 'ats-high' : atsScore >= 50 ? 'ats-mid' : 'ats-low'}`}>ATS {atsScore}</span>
        )}
        <button type="button" className="btn sm" onClick={saveNow}>💾 Save now</button>
      </div>

      <div className={`builder-wrap mode-${pane}`}>
        <div className="editor-col">
          <div className="editor-head">
            <input
              className="title-input"
              value={resume.title}
              maxLength={120}
              aria-label="Resume title"
              onChange={(e) => patch({ title: e.target.value })}
              placeholder="Untitled Resume"
            />
          </div>

          <Accordion id="design" icon="🎨" title="Design" defaultOpen meta={`${templateMeta.name} · ${themeMeta.name}`}>
            <DesignForm resume={resume} onChange={(next) => setResume(next)} />
          </Accordion>

          <PersonalForm resume={resume} onChange={(next) => setResume(next)} meta={`${filledCount}/7 fields`} />
          <SummaryForm resume={resume} onChange={(next) => setResume(next)} />

          <EntryEditor
            sectionId="experience" icon="💼" title="Experience"
            entries={resume.experience}
            onChange={(list) => patch({ experience: list })}
            renderFields={(entry, onPatch) => <ExperienceFields entry={entry} patch={onPatch} />}
          />
          <EntryEditor
            sectionId="education" icon="🎓" title="Education"
            entries={resume.education}
            onChange={(list) => patch({ education: list })}
            renderFields={(entry, onPatch) => <EducationFields entry={entry} patch={onPatch} />}
          />
          <EntryEditor
            sectionId="projects" icon="🚀" title="Projects"
            entries={resume.projects}
            onChange={(list) => patch({ projects: list })}
            renderFields={(entry, onPatch) => <ProjectFields entry={entry} patch={onPatch} />}
          />

          <SkillsForm resume={resume} onChange={(next) => setResume(next)} />
          <CertsForm resume={resume} onChange={(next) => setResume(next)} />
          <AchievementsForm resume={resume} onChange={(next) => setResume(next)} />
          <LanguagesForm resume={resume} onChange={(next) => setResume(next)} />
          <HobbiesForm resume={resume} onChange={(next) => setResume(next)} />

          <Accordion id="ats" icon="📊" title="ATS Score" meta="Live estimate">
            <AtsPanel draft={resume} open onResult={(result) => setAtsScore(result.score)} />
          </Accordion>

          <button type="button" className="btn primary block save-now" onClick={saveNow}>💾 Save now</button>
        </div>

        <div className="preview-col">
          <div className="zoom-ctl no-print">
            <button type="button" className="btn" onClick={() => setZoomBy(-0.1)} aria-label="Zoom out">−</button>
            <button type="button" className="btn" onClick={() => setZoom(1)} aria-label="Reset zoom">{Math.round(zoom * 100)}%</button>
            <button type="button" className="btn" onClick={() => setZoomBy(0.1)} aria-label="Zoom in">+</button>
          </div>
          <div className="resume-scale" style={{ transform: `scale(${zoom})` }}>
            <ResumePreview resume={resume} />
          </div>
        </div>
      </div>

      <nav className="mobile-tabs no-print" aria-label="Editor or preview">
        <button type="button" className={pane === 'editor' ? 'active' : ''} onClick={() => setPane('editor')}>Editor</button>
        <button type="button" className={pane === 'preview' ? 'active' : ''} onClick={() => setPane('preview')}>Live preview</button>
      </nav>
    </>
  );

}
