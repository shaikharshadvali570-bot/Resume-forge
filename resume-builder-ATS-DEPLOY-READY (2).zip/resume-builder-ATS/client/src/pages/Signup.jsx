import { useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { apiErrorMessage } from '../services/api.js';
import Particles from '../components/Particles.jsx';
import Navbar from '../components/Navbar.jsx';

const emailOk = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v);

function strength(v) {
  let s = 0;
  if (v.length >= 8) s += 1;
  if (/[A-Z]/.test(v)) s += 1;
  if (/[0-9]/.test(v)) s += 1;
  if (/[^A-Za-z0-9]/.test(v)) s += 1;
  if (v.length >= 12) s += 1;
  const labels = ['Too weak', 'Weak', 'Fair', 'Good', 'Strong', 'Very strong'];
  return { score: s, label: labels[s], width: `${(s / 5) * 100}%` };
}

/** Sign-up page with password-strength meter + confirm field. */
export default function Signup() {
  const { register, authActionLoading } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '' });
  const [errors, setErrors] = useState({});
  const meter = useMemo(() => strength(form.password), [form.password]);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    const errs = {};
    if (form.name.trim().length < 2) errs.name = 'Name must be at least 2 characters.';
    if (!emailOk(form.email)) errs.email = 'Enter a valid email address.';
    if (form.password.length < 8) errs.password = 'Password must be at least 8 characters.';
    else if (!/[A-Z]/.test(form.password) || !/[0-9]/.test(form.password)) errs.password = 'Include at least one uppercase letter and one number.';
    if (form.confirm !== form.password) errs.confirm = 'Passwords do not match.';
    setErrors(errs);
    if (Object.keys(errs).length) return;
    try {
      await register({ name: form.name.trim(), email: form.email.trim(), password: form.password });
      toast.success('Account created — welcome!');
      navigate('/dashboard', { replace: true });
    } catch (err) {
      toast.error(apiErrorMessage(err, 'Sign-up failed.'));
    }
  };

  return (
    <>
      <Particles />
      <Navbar links="public" />
      <main className="auth-page">
        <form className="auth-card" onSubmit={submit} noValidate>
          <h1>Create your account</h1>
          <p className="sub">Free forever for your first resumes. No credit card.</p>
          <label className="field"><span>Full name</span>
            <input value={form.name} onChange={set('name')} placeholder="Ada Lovelace" autoComplete="name" />
            {errors.name ? <em className="field-error">{errors.name}</em> : null}
          </label>
          <label className="field"><span>Email</span>
            <input type="email" value={form.email} onChange={set('email')} placeholder="you@example.com" autoComplete="email" />
            {errors.email ? <em className="field-error">{errors.email}</em> : null}
          </label>
          <label className="field"><span>Password</span>
            <input type="password" value={form.password} onChange={set('password')} placeholder="8+ chars, number + uppercase" autoComplete="new-password" />
            {form.password ? (<><div className="strength-wrap"><div className="strength-bar" style={{ width: meter.width }} /></div><div className="strength-txt">{meter.label}</div></>) : null}
            {errors.password ? <em className="field-error">{errors.password}</em> : null}
          </label>
          <label className="field"><span>Confirm password</span>
            <input type="password" value={form.confirm} onChange={set('confirm')} placeholder="Repeat password" autoComplete="new-password" />
            {errors.confirm ? <em className="field-error">{errors.confirm}</em> : null}
          </label>
          <button type="submit" className="btn primary block" disabled={authActionLoading}>
            {authActionLoading ? 'Creating…' : 'Create account'}
          </button>
          <div className="auth-foot"><span>Have an account?</span><Link to="/login">Sign in</Link></div>
        </form>
      </main>
    </>
  );
}
