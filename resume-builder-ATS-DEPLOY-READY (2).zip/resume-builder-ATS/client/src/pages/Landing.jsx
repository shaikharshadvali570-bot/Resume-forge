/**
 * ResumeForge — public landing page.
 * Structure mirrors the original static landing (legacy/index.html) so the
 * shared stylesheet (styles/landing.css) applies unchanged.
 */
import { Link } from 'react-router-dom';
import Navbar, { Footer } from '../components/Navbar.jsx';
import Particles from '../components/Particles.jsx';
import { TEMPLATES } from '../utils/resume-model.js';

const FEATURES = [
  ['⚡', 'Real-time preview', 'Watch your resume update live as you type, then switch templates and colours without losing a word.'],
  ['🎯', 'ATS score estimate', 'A nine-category readiness score with concrete, prioritised suggestions to improve it.'],
  ['🎨', 'Five templates', 'Professional, Modern, Minimal, Classic and a plain ATS-Friendly layout.'],
  ['📄', 'PDF & DOCX export', 'Clean A4 PDFs and editable Word files, named after your resume.'],
  ['💾', 'Auto-save to your account', 'Debounced saves with a live status indicator — your data lives in PostgreSQL, not a browser cache.'],
  ['🔒', 'Private by default', 'JWT authentication and per-user ownership checks: you can only ever open your own resumes.'],
];

const STEPS = [
  ['Create your account', 'Sign up with an email and password — hashed with bcrypt before it ever touches the database.'],
  ['Build and score', 'Fill in the sections you need. The estimated ATS score updates as you edit.'],
  ['Export and apply', 'Download a PDF or DOCX, or open the full-page preview and print it.'],
];

export default function Landing() {
  return (
    <>
      <Particles />
      <Navbar links="public" />

      <main className="landing">
        <section className="hero">
          <div className="hero-copy">
            <p className="hero-eyebrow">ATS-friendly resume builder</p>
            <h1>Build a resume that <em>gets interviews</em></h1>
            <p className="hero-sub">
              Create, score and export professional resumes saved to your private account —
              live preview, five templates, and instant PDF &amp; DOCX export.
            </p>
            <div className="hero-cta">
              <Link className="btn primary lg" to="/signup">Build my resume →</Link>
              <Link className="btn lg" to="/login">I already have an account</Link>
            </div>
            <div className="hero-proof">
              <div className="proof-item"><strong>{TEMPLATES.length}</strong><span>Pro templates</span></div>
              <div className="proof-item"><strong>ATS</strong><span>Readiness score</span></div>
              <div className="proof-item"><strong>PDF·DOCX</strong><span>Export formats</span></div>
              <div className="proof-item"><strong>100%</strong><span>Free</span></div>
            </div>
          </div>
          <div className="hero-visual" aria-hidden="true">
            <div className="mini-resume">
              <h2>Alex Morgan</h2>
              <div className="mr-contact">alex@email.com · (555) 010-2030 · San Francisco</div>
              <h3>Summary</h3>
              <div className="mr-line" /><div className="mr-line w80" /><div className="mr-line w60" />
              <h3>Experience</h3>
              <div className="mr-line w80" /><div className="mr-line" /><div className="mr-line w60" />
              <h3>Skills</h3>
              <div className="mr-chips">
                <span className="mr-chip">React</span><span className="mr-chip">Node.js</span>
                <span className="mr-chip">SQL</span><span className="mr-chip">AWS</span>
                <span className="mr-chip">Docker</span>
              </div>
            </div>
          </div>
        </section>

        <section className="features" id="features">
          <h2>Everything you need to land the interview</h2>
          <p className="feat-sub">A complete resume toolkit — no design skills required.</p>
          <div className="feat-grid">
            {FEATURES.map(([icon, title, text]) => (
              <article className="feat-card" key={title}>
                <div className="feat-icon" aria-hidden="true">{icon}</div>
                <h3>{title}</h3>
                <p>{text}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="features" id="templates">
          <h2>Five templates, one ATS-friendly structure</h2>
          <p className="feat-sub">Switch anytime — your content never moves.</p>
          <div className="feat-grid">
            {TEMPLATES.map((t) => (
              <article className="feat-card" key={t.id}>
                <h3>{t.name}</h3>
                <p>{t.desc}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="features" id="how">
          <h2>How it works</h2>
          <p className="feat-sub">From blank page to application-ready in three steps.</p>
          <div className="feat-grid">
            {STEPS.map(([title, text], i) => (
              <article className="feat-card" key={title}>
                <div className="feat-icon" aria-hidden="true">{i + 1}</div>
                <h3>{title}</h3>
                <p>{text}</p>
              </article>
            ))}
          </div>
          <p className="switch-link"><Link to="/signup">Create your free account →</Link></p>
        </section>
      </main>

      <Footer />
    </>
  );
}
