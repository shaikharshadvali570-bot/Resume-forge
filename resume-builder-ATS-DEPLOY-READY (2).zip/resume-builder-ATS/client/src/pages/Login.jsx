import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { apiErrorMessage } from '../services/api.js';
import Particles from '../components/Particles.jsx';
import Navbar from '../components/Navbar.jsx';

const emailOk = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v);

/** Sign-in page. */
export default function Login() {
  const { login, authActionLoading } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({});

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    const errs = {};
    if (!emailOk(form.email)) errs.email = 'Enter a valid email address.';
    if (!form.password) errs.password = 'Password is required.';
    setErrors(errs);
    if (Object.keys(errs).length) return;
    try {
      await login({ email: form.email.trim(), password: form.password });
      toast.success('Welcome back!');
      navigate(location.state?.from || '/dashboard', { replace: true });
    } catch (err) {
      toast.error(apiErrorMessage(err, 'Sign-in failed.'));
    }
  };

  return (
    <>
      <Particles />
      <Navbar links="public" />
      <main className="auth-page">
        <form className="auth-card" onSubmit={submit} noValidate>
          <h1>Welcome back</h1>
          <p className="sub">Sign in to continue building resumes.</p>
          <label className="field"><span>Email</span>
            <input type="email" autoComplete="email" value={form.email} onChange={set('email')} placeholder="you@example.com" />
            {errors.email ? <em className="field-error">{errors.email}</em> : null}
          </label>
          <label className="field"><span>Password</span>
            <input type="password" autoComplete="current-password" value={form.password} onChange={set('password')} placeholder="••••••••" />
            {errors.password ? <em className="field-error">{errors.password}</em> : null}
          </label>
          <button type="submit" className="btn primary block" disabled={authActionLoading}>
            {authActionLoading ? 'Signing in…' : 'Sign in'}
          </button>
          <div className="auth-foot"><span>No account yet?</span><Link to="/signup">Create one</Link></div>
        </form>
      </main>
    </>
  );
}
