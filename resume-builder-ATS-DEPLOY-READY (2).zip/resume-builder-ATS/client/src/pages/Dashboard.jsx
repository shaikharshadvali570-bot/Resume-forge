/**
 * ResumeForge — authenticated dashboard (/dashboard).
 * Lists the signed-in user's resumes with search, sorting, template / ATS
 * filters, and create · open · preview · duplicate · delete actions.
 */
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { resumesApi } from '../services/resumes.js';
import { apiErrorMessage } from '../services/api.js';
import { useAuth } from '../context/AuthContext.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { useLocalPreference } from '../hooks/hooks.js';
import Navbar, { Footer } from '../components/Navbar.jsx';
import Particles from '../components/Particles.jsx';
import ConfirmDialog from '../components/ConfirmDialog.jsx';
import { EmptyResumes, ErrorPanel, SkeletonCards } from '../components/states.jsx';
import { TEMPLATES, getTemplateMeta } from '../utils/resume-model.js';

const fmtDate = (iso) => {
  if (!iso) return '—';
  try { return new Date(iso).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }); }
  catch { return '—'; }
};

const scoreClass = (s) => (s >= 75 ? 'ats-high' : s >= 50 ? 'ats-mid' : 'ats-low');

export default function Dashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [defaults] = useLocalPreference('rf_resume_defaults', { template: 'professional', theme: 'blue' });

  const [resumes, setResumes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [search, setSearch] = useState('');
  const [tplFilter, setTplFilter] = useState('all');
  const [atsFilter, setAtsFilter] = useState('all');
  const [sort, setSort] = useState('-updatedAt');
  const [pendingDelete, setPendingDelete] = useState(null);
  const [busyId, setBusyId] = useState('');
  const [creating, setCreating] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setLoadError('');
    try {
      setResumes(await resumesApi.list());
    } catch (err) {
      setLoadError(apiErrorMessage(err, 'Could not load your resumes.'));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const stats = useMemo(() => {
    const scores = resumes.map((r) => r.atsScore ?? 0);
    const avg = scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : 0;
    const best = scores.length ? Math.max(...scores) : 0;
    const latest = resumes
      .map((r) => r.updatedAt)
      .filter(Boolean)
      .sort()
      .pop();
    return { total: resumes.length, avg, best, latest };
  }, [resumes]);

  const visible = useMemo(() => {
    let rows = [...resumes];
    if (tplFilter !== 'all') rows = rows.filter((r) => r.template === tplFilter);
    if (atsFilter !== 'all') rows = rows.filter((r) => (r.atsScore ?? 0) >= Number(atsFilter));
    const q = search.trim().toLowerCase();
    if (q) {
      rows = rows.filter(
        (r) => (r.title || '').toLowerCase().includes(q) || (r.fullName || '').toLowerCase().includes(q),
      );
    }
    rows.sort((a, b) => {
      if (sort === 'title') return (a.title || '').localeCompare(b.title || '');
      if (sort === '-title') return (b.title || '').localeCompare(a.title || '');
      if (sort === 'ats') return (b.atsScore ?? 0) - (a.atsScore ?? 0);
      if (sort === 'updatedAt') return new Date(a.updatedAt) - new Date(b.updatedAt);
      return new Date(b.updatedAt) - new Date(a.updatedAt);
    });
    return rows;
  }, [resumes, search, tplFilter, atsFilter, sort]);

  const create = async () => {
    setCreating(true);
    try {
      const created = await resumesApi.create({
        title: `Resume ${resumes.length + 1}`,
        template: defaults.template,
        theme: defaults.theme,
      });
      toast.success('Resume created — opening the builder…');
      navigate(`/builder/${created.id}`);
    } catch (err) {
      toast.error(apiErrorMessage(err, 'Could not create a resume.'));
    } finally {
      setCreating(false);
    }
  };

  const duplicate = async (id) => {
    setBusyId(id);
    try {
      await resumesApi.duplicate(id);
      toast.success('Resume duplicated.');
      await load();
    } catch (err) {
      toast.error(apiErrorMessage(err, 'Could not duplicate this resume.'));
    } finally {
      setBusyId('');
    }
  };

  const confirmDelete = async () => {
    const target = pendingDelete;
    setPendingDelete(null);
    if (!target) return;
    try {
      await resumesApi.remove(target.id);
      setResumes((rows) => rows.filter((r) => r.id !== target.id));
      toast.success('Resume deleted.');
    } catch (err) {
      toast.error(apiErrorMessage(err, 'Could not delete this resume.'));
    }
  };

  const firstName = user?.name ? user.name.split(' ')[0] : '';

  return (
    <>
      <Particles />
      <Navbar />

      <header className="hero">
        <p className="hero-eyebrow">Dashboard</p>
        <h1>Welcome back{firstName ? `, ${firstName}` : ''} <em>— let&apos;s build.</em></h1>
        <p>
          {resumes.length
            ? `You have ${resumes.length} resume${resumes.length === 1 ? '' : 's'}. Pick one up or start something new.`
            : 'Create your first resume to unlock live preview, ATS scoring and PDF/DOCX export.'}
        </p>
      </header>

      <main className="main">
        <div className="stats">
          <div className="stat"><div className="stat-num">{stats.total}</div><div className="stat-label">Resumes</div></div>
          <div className="stat"><div className="stat-num">{stats.avg}</div><div className="stat-label">Average ATS score</div></div>
          <div className="stat"><div className="stat-num">{stats.best}</div><div className="stat-label">Best ATS score</div></div>
          <div className="stat"><div className="stat-num">{fmtDate(stats.latest)}</div><div className="stat-label">Last updated</div></div>
        </div>

        <div className="dash-head">
          <div className="dash-filters">
            <input
              className="input search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search resumes…"
              aria-label="Search resumes"
            />
            <select value={tplFilter} onChange={(e) => setTplFilter(e.target.value)} aria-label="Filter by template">
              <option value="all">All templates</option>
              {TEMPLATES.map((t) => (<option key={t.id} value={t.id}>{t.name}</option>))}
            </select>
            <select value={atsFilter} onChange={(e) => setAtsFilter(e.target.value)} aria-label="Filter by ATS score">
              <option value="all">Any ATS score</option>
              <option value="75">ATS 75+</option>
              <option value="50">ATS 50+</option>
              <option value="25">ATS 25+</option>
            </select>
            <select value={sort} onChange={(e) => setSort(e.target.value)} aria-label="Sort resumes">
              <option value="-updatedAt">Recently updated</option>
              <option value="updatedAt">Oldest first</option>
              <option value="title">Title A–Z</option>
              <option value="-title">Title Z–A</option>
              <option value="ats">Highest ATS score</option>
            </select>
          </div>
          <button type="button" className="btn primary" onClick={create} disabled={creating}>
            {creating ? 'Creating…' : '+ New resume'}
          </button>
        </div>

        {loading ? (
          <div className="resume-grid"><SkeletonCards count={3} /></div>
        ) : loadError ? (
          <ErrorPanel title="Could not load your resumes" message={loadError} onRetry={load} />
        ) : resumes.length === 0 ? (
          <EmptyResumes onCreate={create} />
        ) : visible.length === 0 ? (
          <div className="empty-state">
            <div className="es-icon" aria-hidden="true">🔍</div>
            <h3>No resumes match those filters</h3>
            <p>Try a different search term, template or ATS threshold.</p>
            <button
              type="button"
              className="btn"
              onClick={() => { setSearch(''); setTplFilter('all'); setAtsFilter('all'); }}
            >
              Clear filters
            </button>
          </div>
        ) : (
          <div className="resume-grid">
            {visible.map((r) => (
              <article className="resume-card" key={r.id} onClick={() => navigate(`/builder/${r.id}`)}>
                <div className="rc-thumb" aria-hidden="true" />
                <div className="rc-name">{r.title || 'Untitled Resume'}</div>
                <div className="rc-meta">
                  <span>🎨 {getTemplateMeta(r.template).name}</span>
                  <span>Updated {fmtDate(r.updatedAt)}</span>
                  {typeof r.atsScore === 'number' ? (
                    <span className={`ats-badge ${scoreClass(r.atsScore)}`}>ATS {r.atsScore}</span>
                  ) : null}
                </div>
                <div className="rc-actions" onClick={(e) => e.stopPropagation()}>
                  <Link className="btn primary" to={`/builder/${r.id}`}>Edit</Link>
                  <Link className="btn" to={`/resumes/${r.id}/preview`}>Preview</Link>
                  <button type="button" className="btn" disabled={busyId === r.id} onClick={() => duplicate(r.id)}>
                    {busyId === r.id ? '…' : 'Duplicate'}
                  </button>
                  <button type="button" className="btn danger" onClick={() => setPendingDelete(r)}>Delete</button>
                </div>
              </article>
            ))}
          </div>
        )}
      </main>

      <Footer />

      <ConfirmDialog
        open={Boolean(pendingDelete)}
        title="Delete this resume?"
        message={`“${pendingDelete?.title || 'Untitled Resume'}” will be permanently deleted along with all of its sections. This action cannot be undone.`}
        confirmText="Delete resume"
        onCancel={() => setPendingDelete(null)}
        onConfirm={confirmDelete}
      />
    </>
  );
}

