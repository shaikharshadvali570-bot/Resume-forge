/**
 * ResumeForge — dedicated full-page preview (/resumes/:id/preview).
 * Print, PDF and DOCX export, plus template / theme switching that persists
 * straight back to the database.
 */
import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { resumesApi } from '../services/resumes.js';
import { apiErrorMessage } from '../services/api.js';
import { useToast } from '../context/ToastContext.jsx';
import { exportResumeDOCX, exportResumePDF, resumeFileStem } from '../utils/export.js';
import { TEMPLATES, THEMES, getTemplateMeta, getThemeMeta } from '../utils/resume-model.js';
import Navbar, { Footer } from '../components/Navbar.jsx';
import Particles from '../components/Particles.jsx';
import ResumePreview from '../components/ResumePreview.jsx';
import { CenteredSpinner, ErrorPanel } from '../components/states.jsx';

export default function Preview() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [resume, setResume] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [template, setTemplate] = useState('professional');
  const [theme, setTheme] = useState('blue');
  const [busy, setBusy] = useState('');
  const [atsScore, setAtsScore] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const data = await resumesApi.get(id);
      setResume(data);
      setTemplate(data.template || 'professional');
      setTheme(data.theme || 'blue');
      resumesApi.ats(id).then((r) => setAtsScore(r.score)).catch(() => setAtsScore(null));
    } catch (err) {
      setError(apiErrorMessage(err, 'Could not load this resume.'));
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => { load(); }, [load]);

  /** Design changes are saved immediately (owner-only via the API). */
  const persist = async (patch) => {
    setBusy('design');
    try {
      await resumesApi.update(id, { ...resume, ...patch });
      setResume((prev) => ({ ...prev, ...patch }));
    } catch (err) {
      toast.error(apiErrorMessage(err, 'Could not save that design change.'));
      setTemplate(resume.template || 'professional');
      setTheme(resume.theme || 'blue');
    } finally {
      setBusy('');
    }
  };

  const changeTemplate = (value) => { setTemplate(value); persist({ template: value }); };
  const changeTheme = (value) => { setTheme(value); persist({ theme: value }); };

  const stem = () => resumeFileStem(resume?.title, resume?.fullName);

  const downloadPDF = async () => {
    setBusy('pdf');
    try {
      await exportResumePDF(document.getElementById('resume'), `${stem()}.pdf`);
      toast.success('PDF downloaded.');
    } catch (err) {
      toast.error(apiErrorMessage(err, 'PDF export failed.'));
    } finally {
      setBusy('');
    }
  };

  const downloadDOCX = async () => {
    setBusy('docx');
    try {
      await exportResumeDOCX(resume, resume.sectionOrder, `${stem()}.docx`);
      toast.success('DOCX downloaded.');
    } catch (err) {
      toast.error(apiErrorMessage(err, 'DOCX export failed.'));
    } finally {
      setBusy('');
    }
  };

  if (loading) {
    return (
      <>
        <Particles />
        <Navbar showUser={false} />
        <main className="preview-loading"><CenteredSpinner label="Loading preview…" /></main>
      </>
    );
  }

  if (error || !resume) {
    return (
      <>
        <Particles />
        <Navbar showUser={false} />
        <main>
          <ErrorPanel
            title="Preview unavailable"
            message={error || 'This resume does not exist, or it belongs to another account.'}
            onRetry={load}
          />
          <p className="switch-link"><Link to="/dashboard">← Back to dashboard</Link></p>
        </main>
      </>
    );
  }

  return (
    <>
      <Particles />
      <Navbar showUser={false} />

      <main className="preview-page">
        <div className="preview-toolbar no-print">
          <button type="button" className="btn" onClick={() => navigate(`/builder/${id}`)}>← Editor</button>
          <strong className="preview-title">{resume.title || 'Untitled Resume'}</strong>
          {atsScore === null ? null : (
            <span className={`ats-badge ${atsScore >= 75 ? 'ats-high' : atsScore >= 50 ? 'ats-mid' : 'ats-low'}`}>
              ATS {atsScore}
            </span>
          )}
          <span className="preview-spacer" />

          <label className="inline-field">
            <span>Template</span>
            <select value={template} disabled={busy === 'design'} onChange={(e) => changeTemplate(e.target.value)}>
              {TEMPLATES.map((t) => (<option key={t.id} value={t.id}>{t.name}</option>))}
            </select>
          </label>
          <label className="inline-field">
            <span>Theme</span>
            <select value={theme} disabled={busy === 'design'} onChange={(e) => changeTheme(e.target.value)}>
              {THEMES.map((t) => (<option key={t.id} value={t.id}>{t.name}</option>))}
            </select>
          </label>

          <button type="button" className="btn" onClick={() => window.print()}>🖨 Print</button>
          <button type="button" className="btn" disabled={busy === 'docx'} onClick={downloadDOCX}>
            {busy === 'docx' ? '…' : '📝 DOCX'}
          </button>
          <button type="button" className="btn primary" disabled={busy === 'pdf'} onClick={downloadPDF}>
            {busy === 'pdf' ? '…' : '📄 PDF'}
          </button>
        </div>

        <div className="preview-stage">
          <ResumePreview resume={resume} template={template} theme={theme} />
        </div>

        <p className="muted small preview-meta">
          {getTemplateMeta(template).name} · {getThemeMeta(theme).name} ·{' '}
          {resume.sectionOrder?.length || 0} sections ·{' '}
          <Link to="/dashboard">Back to dashboard</Link>
        </p>
      </main>

      <Footer />
    </>
  );
}

