import { describe, expect, it } from 'vitest';
import { toPayload } from './Builder.jsx';
import { emptyResume } from '../utils/resume-model.js';

/**
 * The auto-save payload builder: local editor state → validated API body.
 * Keeping this pure means the debounced PUT can never post client-only fields.
 */
describe('builder toPayload', () => {
  it('produces the exact shape PUT /api/resumes/:id expects', () => {
    const payload = toPayload(emptyResume({ title: 'My Resume' }));
    expect(Object.keys(payload).sort()).toEqual([
      'achievements', 'certifications', 'education', 'email', 'experience', 'fullName',
      'github', 'hobbies', 'languages', 'linkedin', 'location', 'phone', 'projects',
      'sectionOrder', 'skills', 'summary', 'template', 'theme', 'title', 'website',
    ]);
    expect(payload.title).toBe('My Resume');
  });

  it('strips client-only metadata from section rows', () => {
    const payload = toPayload(emptyResume({
      education: [{ id: 'edu_1', resumeId: 'r1', order: 3, _key: 'local-1', degree: 'B.S. CS' }],
      skills: [{ id: 'sk_1', name: 'React', order: 0 }],
    }));
    expect(payload.education[0]).toEqual({
      degree: 'B.S. CS', university: undefined, location: undefined,
      startYear: undefined, endYear: undefined, description: undefined,
    });
    expect(payload.education[0].id).toBeUndefined();
    expect(payload.skills[0]).toEqual({ name: 'React', category: undefined, level: undefined });
  });

  it('never sends an empty title (the API requires 1+ characters)', () => {
    expect(toPayload(emptyResume({ title: '   ' })).title).toBe('Untitled Resume');
    expect(toPayload({}).title).toBe('Untitled Resume');
  });

  it('normalises hobbies and guarantees every section array exists', () => {
    const payload = toPayload({ title: 'T', hobbies: ['Chess', '', '  '] });
    expect(payload.hobbies).toEqual(['Chess']);
    for (const key of ['education', 'experience', 'projects', 'skills', 'certifications', 'achievements', 'languages']) {
      expect(payload[key]).toEqual([]);
    }
  });

  it('accepts half-typed rows while the user is still editing', () => {
    const payload = toPayload(emptyResume({ certifications: [{ name: '' }] }));
    expect(payload.certifications).toHaveLength(1);
    expect(payload.certifications[0].name).toBe('');
  });
});
