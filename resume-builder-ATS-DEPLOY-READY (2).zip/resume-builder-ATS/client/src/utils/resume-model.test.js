import { describe, expect, it } from 'vitest';
import {
  DEFAULT_SECTION_ORDER,
  TEMPLATES,
  THEMES,
  emptyResume,
  getTemplateMeta,
  getThemeMeta,
  parseCommaList,
  parseLineList,
  sectionSingularLabel,
  toViewModel,
} from './resume-model.js';

describe('resume model constants', () => {
  it('exposes the five templates and six themes used by the API', () => {
    expect(TEMPLATES.map((t) => t.id)).toEqual(['professional', 'modern', 'minimal', 'ats', 'classic']);
    expect(THEMES.map((t) => t.id)).toEqual(['blue', 'navy', 'green', 'purple', 'black', 'mono']);
  });

  it('falls back to the first template/theme for unknown ids', () => {
    expect(getTemplateMeta('nope').id).toBe('professional');
    expect(getThemeMeta('nope').id).toBe('blue');
    expect(getThemeMeta('green').color).toMatch(/^#/);
  });
});

describe('emptyResume', () => {
  it('matches the PUT /api/resumes/:id payload contract', () => {
    const draft = emptyResume();
    expect(draft.title).toBe('Untitled Resume');
    expect(draft.template).toBe('professional');
    expect(draft.theme).toBe('blue');
    expect(draft.sectionOrder).toEqual(DEFAULT_SECTION_ORDER);
    for (const key of ['education', 'experience', 'projects', 'skills', 'certifications', 'achievements', 'languages', 'hobbies']) {
      expect(Array.isArray(draft[key])).toBe(true);
      expect(draft[key]).toHaveLength(0);
    }
  });

  it('applies overrides', () => {
    expect(emptyResume({ title: 'Custom' }).title).toBe('Custom');
  });
});

describe('toViewModel', () => {
  const apiResume = {
    fullName: 'Jamie Doe',
    email: 'jamie@example.com',
    summary: 'Engineer with a decade of experience.',
    skills: [{ name: 'JavaScript' }, { name: '' }, { name: 'SQL' }],
    education: [{ degree: 'B.S. CS', university: 'UT Austin', startYear: '2012', endYear: '2016' }],
    experience: [{
      jobTitle: 'Engineer', company: 'Acme', currentlyWorking: true,
      description: 'Shipped features\nReduced costs by 30%',
    }],
    projects: [{ title: 'CLI', organization: 'OSS', technologies: 'Go', description: 'Built a CLI' }],
    certifications: [{ name: 'AWS SAA', issuingOrganization: 'AWS', issueDate: '2024' }, { name: '' }],
    achievements: [{ title: 'Hackathon' }],
    languages: [{ name: 'English', proficiency: 'Native' }, { name: '' }],
    hobbies: ['Chess'],
  };
  const vm = toViewModel(apiResume);

  it('maps personal fields and bullets', () => {
    expect(vm.personal.fullName).toBe('Jamie Doe');
    expect(vm.experience[0].bullets).toEqual(['Shipped features', 'Reduced costs by 30%']);
    expect(vm.experience[0].period).toBe('Present');
  });

  it('drops blank skills / certifications / languages from draft rows', () => {
    expect(vm.skills).toEqual(['JavaScript', 'SQL']);
    expect(vm.certifications).toEqual(['AWS SAA — AWS — 2024']);
    expect(vm.languages).toEqual(['English (Native)']);
  });

  it('builds education and project summaries', () => {
    expect(vm.education[0].school).toBe('UT Austin');
    expect(vm.education[0].year).toBe('2012 - 2016');
    expect(vm.projects[0].org).toBe('OSS · Go');
  });

  it('never throws on an empty resume', () => {
    const empty = toViewModel();
    expect(empty.personal.fullName).toBe('');
    expect(empty.skills).toEqual([]);
  });
});

describe('text parsers', () => {
  it('parses comma separated skill lists', () => {
    expect(parseCommaList('React, Node.js , ,SQL')).toEqual(['React', 'Node.js', 'SQL']);
  });
  it('parses newline separated bullets', () => {
    expect(parseLineList('a\n\n b \n')).toEqual(['a', 'b']);
  });
  it('labels section buttons', () => {
    expect(sectionSingularLabel('certifications')).toBe('Certification');
    expect(sectionSingularLabel('unknown')).toBe('Entry');
  });
});
