/**
 * ResumeForge — resume data model helpers for the React client.
 *
 * The REST API returns a flat resume with relational section arrays:
 *   { fullName, email, …, summary, sectionOrder, hobbies,
 *     education: [{ degree, university, … }], experience: [{ jobTitle, … }] … }
 *
 * Renderers and exporters consume a compact *view model* instead
 * (personal{}, skills: string[], bullets arrays…). `toViewModel()` bridges
 * the two so templates stay simple and independent from API details.
 */

export const TEMPLATES = [
  { id: 'professional', name: 'Professional', desc: 'Classic serif headings' },
  { id: 'modern', name: 'Modern', desc: 'Sidebar with skill chips' },
  { id: 'minimal', name: 'Minimal', desc: 'Clean single column' },
  { id: 'ats', name: 'ATS-Friendly', desc: 'Plain formatting, parses perfectly' },
  { id: 'classic', name: 'Classic', desc: 'Traditional serif single column' },
];

export const THEMES = [
  { id: 'blue', name: 'Blue', color: '#2563eb' },
  { id: 'navy', name: 'Navy', color: '#1e3a5f' },
  { id: 'green', name: 'Green', color: '#059669' },
  { id: 'purple', name: 'Purple', color: '#7c3aed' },
  { id: 'black', name: 'Black', color: '#111111' },
  { id: 'mono', name: 'Mono', color: '#4b5563' },
];

export const SECTIONS = [
  { id: 'summary', label: 'Professional Summary' },
  { id: 'experience', label: 'Experience', dynamic: true },
  { id: 'education', label: 'Education', dynamic: true },
  { id: 'projects', label: 'Projects', dynamic: true },
  { id: 'skills', label: 'Skills' },
  { id: 'certifications', label: 'Certifications' },
  { id: 'achievements', label: 'Achievements' },
  { id: 'languages', label: 'Languages' },
  { id: 'hobbies', label: 'Hobbies' },
];

export const DEFAULT_SECTION_ORDER = [
  'summary', 'skills', 'experience', 'projects', 'education',
  'certifications', 'achievements', 'languages', 'hobbies',
];

export const getTemplateMeta = (id) => TEMPLATES.find((t) => t.id === id) || TEMPLATES[0];
export const getThemeMeta = (id) => THEMES.find((t) => t.id === id) || THEMES[0];

/** Fresh, empty resume exactly as the API expects on PUT (auto-save). */
export function emptyResume(overrides = {}) {
  return {
    title: 'Untitled Resume',
    template: 'professional',
    theme: 'blue',
    fullName: '',
    email: '',
    phone: '',
    location: '',
    linkedin: '',
    github: '',
    website: '',
    summary: '',
    sectionOrder: [...DEFAULT_SECTION_ORDER],
    hobbies: [],
    education: [],
    experience: [],
    projects: [],
    skills: [],
    certifications: [],
    achievements: [],
    languages: [],
    ...overrides,
  };
}

const lines = (v) =>
  String(v || '')
    .split(/\r?\n/)
    .map((s) => s.trim())
    .filter(Boolean);

const yearRange = (start, end) => [start, end].filter(Boolean).join(' - ');

/** Maps the API resume → view model consumed by renderers/exporters. */
export function toViewModel(r = {}) {
  return {
    personal: {
      fullName: r.fullName || '',
      email: r.email || '',
      phone: r.phone || '',
      location: r.location || '',
      linkedin: r.linkedin || '',
      github: r.github || '',
      website: r.website || '',
    },
    summary: r.summary || '',
    skills: (r.skills || []).map((s) => s.name).filter(Boolean),
    education: (r.education || []).map((e) => ({
      degree: e.degree || '',
      school: e.university || '',
      year: yearRange(e.startYear, e.endYear),
      location: e.location || '',
      description: e.description || '',
    })),
    experience: (r.experience || []).map((e) => ({
      title: e.jobTitle || '',
      company: e.company || '',
      location: e.location || '',
      period: e.currentlyWorking
        ? `${yearRange(e.startDate, 'Present')}`
        : yearRange(e.startDate, e.endDate),
      bullets: lines(e.description),
    })),
    projects: (r.projects || []).map((p) => ({
      title: p.title || '',
      org: [p.organization, p.technologies].filter(Boolean).join(' · '),
      url: p.projectUrl || '',
      period: yearRange(p.startDate, p.endDate),
      bullets: lines(p.description),
    })),
    certifications: (r.certifications || [])
      .map((c) => [c.name, c.issuingOrganization, c.issueDate].filter(Boolean).join(' — '))
      .filter(Boolean),
    achievements: (r.achievements || [])
      .map((a) => [a.title, a.description, a.date].filter(Boolean).join(' — '))
      .filter(Boolean),
    languages: (r.languages || [])
      .map((l) => (l.proficiency ? `${l.name} (${l.proficiency})` : l.name))
      .filter(Boolean),
    hobbies: (r.hobbies || []).map(String).filter(Boolean),
  };
}

/** Parses comma-separated text into a clean array. */
export const parseCommaList = (text) =>
  String(text || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);

/** Parses newline-separated text into a clean array. */
export const parseLineList = (text) =>
  String(text || '')
    .split(/\r?\n/)
    .map((s) => s.trim())
    .filter(Boolean);

/** Human-readable singular label for section entry buttons. */
export function sectionSingularLabel(id) {
  const map = {
    experience: 'Position', education: 'Degree', projects: 'Project',
    certifications: 'Certification', achievements: 'Achievement',
    languages: 'Language', hobbies: 'Hobby', skills: 'Skill', summary: 'Summary',
  };
  return map[id] || 'Entry';
}
