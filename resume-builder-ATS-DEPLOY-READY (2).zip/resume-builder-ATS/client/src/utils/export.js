import { toViewModel } from '../utils/resume-model.js';

/** Sanitizes a resume title into a file-friendly `John_Doe_Resume` stem. */
export function resumeFileStem(title, fullName) {
  const base = (title || fullName || 'resume').trim() || 'resume';
  return `${base.replace(/[^\w\- ]+/g, '').trim().replace(/\s+/g, '_').slice(0, 60) || 'resume'}_Resume`;
}

function cloneToA4(resumeEl) {
  const holder = document.createElement('div');
  holder.id = 'rf-export-holder';
  holder.style.cssText = 'position:fixed;left:-10000px;top:0;background:#fff;';
  const clone = resumeEl.cloneNode(true);
  clone.style.width = '210mm';
  clone.style.minHeight = '297mm';
  clone.style.margin = '0';
  clone.style.boxShadow = 'none';
  clone.style.borderRadius = '0';
  holder.appendChild(clone);
  document.body.appendChild(holder);
  return holder;
}

/** Renders the A4 preview node to PDF via html2pdf.js (lazy import). */
export async function exportResumePDF(resumeEl, filename = 'resume.pdf') {
  if (!resumeEl) throw new Error('Resume preview not found.');
  const { default: html2pdf } = await import('html2pdf.js');
  const holder = cloneToA4(resumeEl);
  try {
    await html2pdf().set({
      margin: [8, 10, 10, 10],
      filename,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true, backgroundColor: '#ffffff', letterRendering: true },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait', compress: true },
      pagebreak: { mode: ['avoid-all', 'css', 'legacy'] },
    }).from(holder.firstChild).save();
  } finally {
    holder.remove();
  }
}

/** Builds Word-compatible HTML for the DOCX exporter. */
export function buildDOCXHtml(resume, order) {
  const vm = toViewModel(resume || {});
  const p = vm.personal;
  const esc = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const contact = [p.email, p.phone, p.location, p.linkedin, p.github].filter(Boolean).map(esc).join(' | ');
  const sec = (label, inner) => (inner ? `<h2 style="font-size:12pt;border-bottom:1px solid #999;padding-bottom:2pt;margin:14pt 0 6pt 0;text-transform:uppercase;">${esc(label)}</h2>${inner}` : '');
  const ul = (items) => (items.length ? `<ul style="margin:4pt 0 8pt 18pt;">${items.map((i) => `<li style="font-size:10pt;">${esc(i)}</li>`).join('')}</ul>` : '');
  const para = (t) => `<p style="font-size:10pt;margin:0 0 6pt 0;">${esc(t)}</p>`;
  const byId = {
    summary: () => sec('Professional Summary', vm.summary ? para(vm.summary) : ''),
    experience: () => sec('Experience', vm.experience.map((e) => `<p style="font-size:10.5pt;"><strong>${esc(e.title)}</strong>${e.company ? ` — ${esc(e.company)}` : ''}</p>${ul(e.bullets)}`).join('')),
    projects: () => sec('Projects', vm.projects.map((e) => `<p style="font-size:10.5pt;"><strong>${esc(e.title)}</strong>${e.org ? ` — ${esc(e.org)}` : ''}</p>${ul(e.bullets)}`).join('')),
    education: () => sec('Education', vm.education.map((e) => `<p style="font-size:10.5pt;"><strong>${esc(e.degree)}</strong>${e.school ? ` — ${esc(e.school)}` : ''}${e.year ? ` (${esc(e.year)})` : ''}</p>`).join('')),
    skills: () => sec('Skills', para(vm.skills.join(', '))),
    certifications: () => sec('Certifications', ul(vm.certifications)),
    achievements: () => sec('Achievements', ul(vm.achievements)),
    languages: () => sec('Languages', para(vm.languages.join(', '))),
    hobbies: () => sec('Hobbies', para(vm.hobbies.join(', '))),
  };
  const body = (order || []).map((id) => (byId[id] ? byId[id]() : '')).join('');
  return `<!DOCTYPE html><html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="utf-8"><title>Resume</title></head><body><h1 style="text-align:center;">${esc(p.fullName) || 'Your Name'}</h1><p style="text-align:center;">${contact}</p>${body}</body></html>`;
}

/** Packages the DOCX HTML via the html-docx-js UMD global (lazy script). */
export async function exportResumeDOCX(resume, order, filename = 'resume.docx') {
  await ensureHtmlDocx();
  const html = buildDOCXHtml(resume, order);
  const blob = window.htmlDocx.asBlob(html);
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

let docxPromise = null;
function ensureHtmlDocx() {
  if (window.htmlDocx?.asBlob) return Promise.resolve();
  if (!docxPromise) {
    docxPromise = new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = 'https://cdn.jsdelivr.net/npm/html-docx-js@0.3.1/dist/html-docx.js';
      s.onload = () => (window.htmlDocx?.asBlob ? resolve() : reject(new Error('DOCX library failed to load.')));
      s.onerror = () => reject(new Error('DOCX library failed to load. Check your connection.'));
      document.head.appendChild(s);
    });
  }
  return docxPromise;
}
