import { describe, expect, it } from 'vitest';
import { buildDOCXHtml, resumeFileStem } from './export.js';

describe('resumeFileStem', () => {
  it('builds John_Doe_Resume style file names', () => {
    expect(resumeFileStem('Alex Morgan Resume', 'Alex Morgan')).toBe('Alex_Morgan_Resume_Resume');
  });

  it('strips characters that are unsafe in file names', () => {
    expect(resumeFileStem('CV: 2026 / Final?')).toBe('CV_2026_Final_Resume');
  });

  it('falls back to a generic stem for empty titles', () => {
    expect(resumeFileStem('', '')).toBe('resume_Resume');
  });
});

describe('buildDOCXHtml', () => {
  const resume = {
    fullName: 'Jamie <Doe>',
    email: 'jamie@example.com',
    phone: '555-0100',
    summary: 'Engineer with a decade of experience.',
    skills: [{ name: 'JavaScript' }, { name: 'SQL' }],
    experience: [{ jobTitle: 'Engineer', company: 'Acme', description: 'Shipped features' }],
    education: [{ degree: 'B.S. CS', university: 'UT Austin', startYear: '2012', endYear: '2016' }],
    projects: [],
    certifications: [],
    achievements: [],
    languages: [],
    hobbies: [],
  };

  it('produces a Word-compatible HTML document', () => {
    const html = buildDOCXHtml(resume, ['summary', 'experience', 'education', 'skills']);
    expect(html).toContain('xmlns:w="urn:schemas-microsoft-com:office:word"');
    expect(html).toContain('Professional Summary');
    expect(html).toContain('Experience');
    expect(html).toContain('Education');
    expect(html).toContain('JavaScript, SQL');
  });

  it('escapes user content (no raw HTML injection)', () => {
    const html = buildDOCXHtml(resume, ['summary']);
    expect(html).toContain('Jamie &lt;Doe&gt;');
    expect(html).not.toContain('Jamie <Doe>');
  });

  it('respects the section order and omits sections that are not listed', () => {
    const html = buildDOCXHtml(resume, ['skills', 'summary']);
    expect(html.indexOf('Skills')).toBeLessThan(html.indexOf('Professional Summary'));
    expect(html).not.toContain('Education');
  });

  it('handles an empty resume without throwing', () => {
    expect(buildDOCXHtml({}, [])).toContain('Your Name');
  });
});
