/**
 * ResumeForge — authentication context.
 * Owns the current user, JWT lifecycle, and auth-aware navigation helpers.
 */
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { authApi } from '../services/resumes.js';
import { getToken, setToken } from '../services/api.js';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true); // initial session check
  const [authActionLoading, setAuthActionLoading] = useState(false);

  const hydrate = useCallback(async () => {
    if (!getToken()) {
      setUser(null);
      setLoading(false);
      return null;
    }
    try {
      const { user: me } = await authApi.me();
      setUser(me);
      return me;
    } catch {
      setToken('');
      setUser(null);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    hydrate();
    const onUnauthorized = () => setUser(null);
    window.addEventListener('rf:unauthorized', onUnauthorized);
    return () => window.removeEventListener('rf:unauthorized', onUnauthorized);
  }, [hydrate]);

  const register = useCallback(async (payload) => {
    setAuthActionLoading(true);
    try {
      const { user: u, token } = await authApi.register(payload);
      setToken(token);
      setUser(u);
      return u;
    } finally {
      setAuthActionLoading(false);
    }
  }, []);

  const login = useCallback(async (payload) => {
    setAuthActionLoading(true);
    try {
      const { user: u, token } = await authApi.login(payload);
      setToken(token);
      setUser(u);
      return u;
    } finally {
      setAuthActionLoading(false);
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      await authApi.logout();
    } catch {
      /* token may already be invalid — still sign out locally */
    }
    setToken('');
    setUser(null);
  }, []);

  const value = useMemo(
    () => ({
      user,
      setUser,
      loading,
      authActionLoading,
      isAuthenticated: Boolean(user),
      register,
      login,
      logout,
      refresh: hydrate,
    }),
    [user, loading, authActionLoading, register, login, logout, hydrate],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// eslint-disable-next-line react-refresh/only-export-components
export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within <AuthProvider>.');
  return ctx;
}
