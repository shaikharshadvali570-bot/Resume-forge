/**
 * ResumeForge — toast notification context (replaces ad-hoc alert() usage).
 */
import { createContext, useCallback, useContext, useMemo, useRef, useState } from 'react';

const ToastContext = createContext(null);
let toastSeq = 0;

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const timers = useRef(new Map());

  const dismiss = useCallback((id) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
    const timer = timers.current.get(id);
    if (timer) {
      clearTimeout(timer);
      timers.current.delete(id);
    }
  }, []);

  const push = useCallback(
    (message, type = 'info', duration = 3200) => {
      const id = `toast-${Date.now()}-${toastSeq++}`;
      setToasts((prev) => [...prev.slice(-3), { id, message, type }]);
      timers.current.set(id, setTimeout(() => dismiss(id), duration));
      return id;
    },
    [dismiss],
  );

  const toast = useMemo(
    () => ({
      info: (m, d) => push(m, 'info', d),
      success: (m, d) => push(m, 'success', d),
      error: (m, d) => push(m, 'error', d),
      warning: (m, d) => push(m, 'warning', d),
    }),
    [push],
  );

  const value = useMemo(() => ({ toasts, push, toast, dismiss }), [toasts, push, toast, dismiss]);

  return (
    <ToastContext.Provider value={value}>
      {children}
      <div id="toasts" aria-live="polite" aria-atomic="false">
        {toasts.map((t) => (
          <div key={t.id} className={`toast ${t.type}`} role="status">
            <span>{t.message}</span>
            <button type="button" className="toast-close" onClick={() => dismiss(t.id)} aria-label="Dismiss">
              ×
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

// eslint-disable-next-line react-refresh/only-export-components
export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within <ToastProvider>.');
  return ctx;
}
