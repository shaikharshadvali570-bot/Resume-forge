import { useEffect, useState } from 'react';
import { Accordion, Field, Row, TextArea, TextInput } from '../components/forms.jsx';
import { parseCommaList, parseLineList } from '../utils/resume-model.js';

/** Renders the [{ name }] skill rows back into the comma-separated text. */
const skillsToText = (skills) => (skills || []).map((s) => s.name).join(', ');

/**
 * Decides which text the skills box should show.
 *
 * Keeps the user's raw text when it already represents the same skills, so
 * a trailing comma ("React, ") survives; otherwise adopts the incoming text,
 * which is how external changes (initial load, reload) reach the input.
 */
export const resolveSkillText = (current, joined) =>
  parseCommaList(current).join(', ') === joined ? current : joined;

/**
 * Skills editor — comma-separated text mapped to [{ name }] payloads.
 *
 * The raw text is held locally instead of being derived straight from the
 * skills array: deriving it would make typing a trailing comma impossible,
 * because `parseCommaList('React, ')` drops the empty segment and the input
 * value would snap back to 'React', eating the comma the user just typed.
 */
export function SkillsForm({ resume, onChange }) {
  const joined = skillsToText(resume.skills);
  const [text, setText] = useState(joined);

  useEffect(() => {
    setText((current) => resolveSkillText(current, joined));
  }, [joined]);

  const handleChange = (e) => {
    const next = e.target.value;
    setText(next);
    onChange({ ...resume, skills: parseCommaList(next).map((name) => ({ name })) });
  };

  return (
    <Accordion id="skills" icon="🛠️" title="Skills" meta={`${(resume.skills || []).length} skills`}>
      <Field label="Skills — comma separated (aim for 8+)">
        <TextArea rows={2} value={text} onChange={handleChange} placeholder="JavaScript, React, SQL, …" />
      </Field>
    </Accordion>
  );
}

/** Certifications editor. */
export function CertsForm({ resume, onChange }) {
  const list = resume.certifications || [];
  const patch = (i, p) => onChange({ ...resume, certifications: list.map((c, j) => (j === i ? { ...c, ...p } : c)) });
  return (
    <Accordion id="certifications" icon="📜" title="Certifications" meta={`${list.length}`}>
      {list.map((c, i) => (
        <div className="entry-block" key={c.id || i}>
          <div className="entry-head"><span className="e-num">CERTIFICATION {i + 1}</span>
            <button type="button" onClick={() => onChange({ ...resume, certifications: list.filter((_, j) => j !== i) })}>Remove</button></div>
          <Row>
            <Field label="Name"><TextInput value={c.name || ''} onChange={(e) => patch(i, { name: e.target.value })} placeholder="AWS Solutions Architect" /></Field>
            <Field label="Issuer"><TextInput value={c.issuingOrganization || ''} onChange={(e) => patch(i, { issuingOrganization: e.target.value })} placeholder="Amazon" /></Field>
          </Row>
          <Row>
            <Field label="Issue date"><TextInput value={c.issueDate || ''} onChange={(e) => patch(i, { issueDate: e.target.value })} placeholder="2024" /></Field>
            <Field label="Credential URL"><TextInput value={c.credentialUrl || ''} onChange={(e) => patch(i, { credentialUrl: e.target.value })} placeholder="https://…" /></Field>
          </Row>
        </div>
      ))}
      <button type="button" className="btn-add" onClick={() => onChange({ ...resume, certifications: [...list, {}] })}>+ Add Certification</button>
    </Accordion>
  );
}

/** Achievements editor. */
export function AchievementsForm({ resume, onChange }) {
  const list = resume.achievements || [];
  const patch = (i, p) => onChange({ ...resume, achievements: list.map((a, j) => (j === i ? { ...a, ...p } : a)) });
  return (
    <Accordion id="achievements" icon="🏆" title="Achievements" meta={`${list.length}`}>
      {list.map((a, i) => (
        <div className="entry-block" key={a.id || i}>
          <div className="entry-head"><span className="e-num">ACHIEVEMENT {i + 1}</span>
            <button type="button" onClick={() => onChange({ ...resume, achievements: list.filter((_, j) => j !== i) })}>Remove</button></div>
          <Row>
            <Field label="Title"><TextInput value={a.title || ''} onChange={(e) => patch(i, { title: e.target.value })} /></Field>
            <Field label="Date"><TextInput value={a.date || ''} onChange={(e) => patch(i, { date: e.target.value })} /></Field>
          </Row>
          <Field label="Description"><TextArea rows={2} value={a.description || ''} onChange={(e) => patch(i, { description: e.target.value })} /></Field>
        </div>
      ))}
      <button type="button" className="btn-add" onClick={() => onChange({ ...resume, achievements: [...list, {}] })}>+ Add Achievement</button>
    </Accordion>
  );
}

/** Languages + hobbies editors. */
export function LanguagesForm({ resume, onChange }) {
  const list = resume.languages || [];
  const patch = (i, p) => onChange({ ...resume, languages: list.map((l, j) => (j === i ? { ...l, ...p } : l)) });
  return (
    <Accordion id="languages" icon="🌍" title="Languages" meta={`${list.length}`}>
      {list.map((l, i) => (
        <div className="entry-block" key={l.id || i}>
          <div className="entry-head"><span className="e-num">LANGUAGE {i + 1}</span>
            <button type="button" onClick={() => onChange({ ...resume, languages: list.filter((_, j) => j !== i) })}>Remove</button></div>
          <Row>
            <Field label="Language"><TextInput value={l.name || ''} onChange={(e) => patch(i, { name: e.target.value })} placeholder="Spanish" /></Field>
            <Field label="Proficiency"><TextInput value={l.proficiency || ''} onChange={(e) => patch(i, { proficiency: e.target.value })} placeholder="Fluent" /></Field>
          </Row>
        </div>
      ))}
      <button type="button" className="btn-add" onClick={() => onChange({ ...resume, languages: [...list, {}] })}>+ Add Language</button>
    </Accordion>
  );
}

export function HobbiesForm({ resume, onChange }) {
  return (
    <Accordion id="hobbies" icon="🎯" title="Hobbies" meta={`${(resume.hobbies || []).length}`}>
      <Field label="Hobbies — comma separated">
        <TextInput value={(resume.hobbies || []).join(', ')} onChange={(e) => onChange({ ...resume, hobbies: parseCommaList(e.target.value) })} placeholder="Photography, Chess" />
      </Field>
      <Field label="Or one per line (kept in sync)">
        <TextArea rows={2} value={(resume.hobbies || []).join('\n')} onChange={(e) => onChange({ ...resume, hobbies: parseLineList(e.target.value) })} />
      </Field>
    </Accordion>
  );
}
