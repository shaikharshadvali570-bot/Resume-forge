import { Accordion, Field, Row, TextArea, TextInput } from '../components/forms.jsx';

/** Personal-info + summary editor sections. */
export function PersonalForm({ resume, onChange, meta }) {
  const set = (k) => (e) => onChange({ ...resume, [k]: e.target.value });
  return (
    <Accordion
      id="personal"
      icon="👤"
      title="Personal Information"
      defaultOpen
      meta={meta || resume.fullName || 'Add name'}
    >
      <Row>
        <Field label="Full name"><TextInput value={resume.fullName || ''} onChange={set('fullName')} placeholder="Ada Lovelace" /></Field>
        <Field label="Email"><TextInput type="email" value={resume.email || ''} onChange={set('email')} placeholder="you@example.com" /></Field>
      </Row>
      <Row>
        <Field label="Phone"><TextInput value={resume.phone || ''} onChange={set('phone')} placeholder="+1 555 0100" /></Field>
        <Field label="Location"><TextInput value={resume.location || ''} onChange={set('location')} placeholder="City, Country" /></Field>
      </Row>
      <Row>
        <Field label="LinkedIn URL"><TextInput value={resume.linkedin || ''} onChange={set('linkedin')} placeholder="https://linkedin.com/in/…" /></Field>
        <Field label="GitHub URL"><TextInput value={resume.github || ''} onChange={set('github')} placeholder="https://github.com/…" /></Field>
      </Row>
      <Field label="Portfolio / website"><TextInput value={resume.website || ''} onChange={set('website')} placeholder="https://…" /></Field>
    </Accordion>
  );
}

export function SummaryForm({ resume, onChange }) {
  const words = (resume.summary || '').trim() ? (resume.summary || '').trim().split(/\s+/).length : 0;
  return (
    <Accordion id="summary" icon="📝" title="Professional Summary" meta={`${words} words`}>
      <Field label="Summary (aim for 30–90 words)">
        <TextArea rows={4} value={resume.summary || ''} onChange={(e) => onChange({ ...resume, summary: e.target.value })} placeholder="Senior engineer with 5+ years…" />
      </Field>
    </Accordion>
  );
}
