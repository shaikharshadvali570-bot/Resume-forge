/**
 * ResumeForge — design controls for the builder:
 * template picker, theme (accent colour) picker and section ordering.
 */
import { SECTIONS, TEMPLATES, THEMES, DEFAULT_SECTION_ORDER } from '../utils/resume-model.js';

export function DesignForm({ resume, onChange }) {
  const template = resume.template || 'professional';
  const theme = resume.theme || 'blue';
  const order = Array.isArray(resume.sectionOrder) && resume.sectionOrder.length
    ? resume.sectionOrder
    : [...DEFAULT_SECTION_ORDER];

  const setOrder = (next) => onChange({ ...resume, sectionOrder: next });
  const move = (index, delta) => {
    const target = index + delta;
    if (target < 0 || target >= order.length) return;
    const next = [...order];
    [next[index], next[target]] = [next[target], next[index]];
    setOrder(next);
  };
  const removeSection = (id) => setOrder(order.filter((s) => s !== id));
  const addSection = (id) => setOrder([...order, id]);

  const hidden = SECTIONS.filter((s) => !order.includes(s.id));
  const labelOf = (id) => SECTIONS.find((s) => s.id === id)?.label || id;

  return (
    <>
      <div className="field">
        <label>Template</label>
        <div className="tpl-select">
          {TEMPLATES.map((t) => (
            <div
              key={t.id}
              className={`tpl-card${t.id === template ? ' active' : ''}`}
              role="button"
              tabIndex={0}
              aria-pressed={t.id === template}
              onClick={() => onChange({ ...resume, template: t.id })}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  onChange({ ...resume, template: t.id });
                }
              }}
            >
              <div className="t-name">{t.name}</div>
              <div className="t-desc">{t.desc}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="field">
        <label>Theme colour</label>
        <div className="picker-row">
          {THEMES.map((t) => (
            <button
              key={t.id}
              type="button"
              className={`theme-dot${t.id === theme ? ' active' : ''}`}
              style={{ background: t.color }}
              title={t.name}
              aria-label={`${t.name} theme`}
              aria-pressed={t.id === theme}
              onClick={() => onChange({ ...resume, theme: t.id })}
            />
          ))}
        </div>
      </div>

      <div className="field">
        <label>Section order <span className="optional">(top to bottom)</span></label>
        <div className="order-list">
          {order.map((id, i) => (
            <div className="order-row" key={id}>
              <span className="o-label">{labelOf(id)}</span>
              <span className="o-actions">
                <button type="button" onClick={() => move(i, -1)} disabled={i === 0} aria-label={`Move ${labelOf(id)} up`}>↑</button>
                <button type="button" onClick={() => move(i, 1)} disabled={i === order.length - 1} aria-label={`Move ${labelOf(id)} down`}>↓</button>
                <button type="button" className="o-remove" onClick={() => removeSection(id)} aria-label={`Remove ${labelOf(id)}`}>✕</button>
              </span>
            </div>
          ))}
        </div>
        {hidden.length ? (
          <div className="order-add">
            {hidden.map((s) => (
              <button key={s.id} type="button" className="btn sm" onClick={() => addSection(s.id)}>
                + {s.label}
              </button>
            ))}
          </div>
        ) : null}
      </div>
    </>
  );
}

export default DesignForm;
