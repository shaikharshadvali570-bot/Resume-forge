/**
 * ResumeForge — application chrome: top navigation + footer.
 *
 * Uses the shared design-system classes from styles/app.css
 * (.nav, .nav-logo, .wordmark, .nav-dot, .nav-actions, .nav-user, .icon-btn)
 * so the React app keeps the original ResumeForge look.
 */
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { useToast } from '../context/ToastContext.jsx';
import { useAppTheme } from '../hooks/hooks.js';

/**
 * @param {object} props
 * @param {'app'|'public'} [props.links]     middle links to show
 * @param {React.ReactNode} [props.actions]  extra toolbar buttons (builder)
 * @param {boolean} [props.showUser]         show "Signed in as …"
 */
export default function Navbar({ links = 'app', actions = null, showUser = true }) {
  const { user, isAuthenticated, logout } = useAuth();
  const { theme, toggle } = useAppTheme();
  const { toast } = useToast();
  const navigate = useNavigate();

  const onLogout = async () => {
    await logout();
    toast.success('Signed out.');
    navigate('/login', { replace: true });
  };

  return (
    <header className="nav">
      <Link className="nav-logo wordmark" to={isAuthenticated ? '/dashboard' : '/'}>
        <span className="nav-dot" aria-hidden="true" />
        Resume<span>Forge</span>
      </Link>

      <nav className="nav-actions" aria-label="Primary">
        {links === 'public' && !isAuthenticated ? (
          <>
            <a className="nav-link" href="#features">Features</a>
            <a className="nav-link" href="#templates">Templates</a>
            <a className="nav-link" href="#how">How it works</a>
          </>
        ) : null}

        {links === 'app' && isAuthenticated ? (
          <>
            <NavLink className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`} to="/dashboard">
              Dashboard
            </NavLink>
            <NavLink className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`} to="/profile">
              Profile
            </NavLink>
          </>
        ) : null}

        <button
          type="button"
          className="icon-btn"
          onClick={toggle}
          aria-label={theme === 'light' ? 'Switch to dark theme' : 'Switch to light theme'}
          title="Toggle light / dark mode"
        >
          {theme === 'light' ? '🌙' : '☀️'}
        </button>

        {actions}

        {isAuthenticated ? (
          <>
            {showUser ? (
              <span className="nav-user">
                Signed in as <strong>{user?.name || user?.email}</strong>
              </span>
            ) : null}
            <button type="button" className="btn danger" onClick={onLogout}>Sign Out</button>
          </>
        ) : (
          <>
            <Link className="btn" to="/login">Sign in</Link>
            <Link className="btn primary" to="/signup">Get started</Link>
          </>
        )}
      </nav>
    </header>
  );
}

/** Shared footer (public + authenticated pages). */
export function Footer() {
  return (
    <footer className="landing-footer">
      <p>© {new Date().getFullYear()} ResumeForge · Built by Harshadvali Shaik · MIT License</p>
      <p className="footer-note">
        Estimated ATS guidance only — not a guarantee of any employer&apos;s ATS result.
      </p>
    </footer>
  );
}
