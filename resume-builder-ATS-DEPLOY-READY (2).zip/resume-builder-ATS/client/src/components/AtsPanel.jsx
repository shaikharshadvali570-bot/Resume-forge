import { useEffect, useRef, useState } from 'react';
import { atsApi } from '../services/resumes.js';

/**
 * ATS panel — debounced server-side scoring of the current draft.
 * The score is always labelled an *estimate* of ATS readability, never a
 * guarantee of how a specific employer's ATS will parse the resume.
 *
 * @param {object}   props
 * @param {object}   props.draft   resume payload (API shape) to score
 * @param {boolean}  props.open    render + score only while open
 * @param {Function} [props.onResult] called with each fresh result
 */
export default function AtsPanel({ draft, open, delay = 700, onResult }) {
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [failed, setFailed] = useState(false);
  const key = JSON.stringify(draft || {});
  const onResultRef = useRef(onResult);
  onResultRef.current = onResult;

  useEffect(() => {
    if (!open) return undefined;
    setLoading(true);
    const timer = setTimeout(async () => {
      try {
        const data = await atsApi.score(JSON.parse(key) || {});
        setResult(data);
        setFailed(false);
        onResultRef.current?.(data);
      } catch {
        setFailed(true);
      } finally {
        setLoading(false);
      }
    }, delay);
    return () => clearTimeout(timer);
  }, [open, key, delay]);

  if (!open) return null;

  const score = result?.score ?? 0;
  const verdict = score >= 75 ? 'Strong' : score >= 50 ? 'Good progress' : 'Needs work';

  return (
    <div className="ats-panel open" aria-live="polite">
      <div className="ats-overall">
        <div className="ats-ring" style={{ '--p': score }}>
          <span>{loading && !result ? '…' : score}</span>
        </div>
        <div className="ats-verdict">
          {verdict}
          <small>Estimated ATS/readiness score — guidance only, not a guarantee.</small>
        </div>
      </div>

      {failed ? (
        <p className="ats-note">Could not reach the scoring service. Your edits are still saved.</p>
      ) : null}

      {result?.categories?.map((c) => (
        <div className="ats-cat" key={c.id}>
          <span className="c-label">{c.icon} {c.label}</span>
          <span className="c-bar">
            <span className="c-fill" style={{ width: `${Math.round((c.got / c.weight) * 100)}%` }} />
          </span>
          <span className="c-num">{c.got}/{c.weight}</span>
        </div>
      ))}

      {result?.missing?.length ? (
        <p className="ats-missing">
          Missing essentials: {result.missing.map((m) => <span className="badge" key={m}>{m}</span>)}
        </p>
      ) : null}

      {result?.suggestions?.length ? (
        <div className="ats-sugg">
          <div className="ats-sugg-title">Suggestions</div>
          <ul>{result.suggestions.map((s, i) => (<li key={i}>{s}</li>))}</ul>
        </div>
      ) : null}

      <p className="ats-note">
        {result?.disclaimer || 'Every ATS parses differently — treat this as a checklist, not a verdict.'}
      </p>
    </div>
  );
}
