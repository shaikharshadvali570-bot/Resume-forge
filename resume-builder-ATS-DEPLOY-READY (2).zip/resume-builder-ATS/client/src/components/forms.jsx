import { useState } from 'react';

/** Collapsible editor section (accordion). */
export function Accordion({ id, icon, title, meta, defaultOpen, children }) {
  const [open, setOpen] = useState(Boolean(defaultOpen));
  return (
    <div className={`acc${open ? ' open' : ''}`}>
      <button type="button" className="acc-head" onClick={() => setOpen((o) => !o)} aria-expanded={open} aria-controls={`acc-${id}`}>
        <span className="a-title"><span className="dot" aria-hidden="true" />{icon ? `${icon} ` : ''}{title}</span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          {meta ? <span className="a-meta">{meta}</span> : null}
          <span className="chev" aria-hidden="true">▾</span>
        </span>
      </button>
      <div className="acc-body" id={`acc-${id}`}>{open ? children : null}</div>
    </div>
  );
}

/** Labeled input/textarea building blocks for the editor forms. */
export function Field({ label, error, children }) {
  return (
    <label className="field"><span>{label}</span>{children}
      {error ? <em className="field-error">{error}</em> : null}
    </label>
  );
}

export function TextInput(props) {
  return <input {...props} />;
}

export function TextArea({ rows = 3, ...props }) {
  return <textarea rows={rows} {...props} />;
}

export function Row({ children }) {
  return <div className="form-row">{children}</div>;
}
