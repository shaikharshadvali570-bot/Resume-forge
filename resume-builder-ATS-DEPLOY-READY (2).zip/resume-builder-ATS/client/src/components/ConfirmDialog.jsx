import { useEffect, useState } from 'react';

/** Accessible delete-confirmation dialog (replaces native confirm()). */
export default function ConfirmDialog({ open, title, message, confirmText = 'Delete', onConfirm, onCancel }) {
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (!open) setBusy(false);
  }, [open ]);
  if (!open) return null;
  const ok = async () => { setBusy(true); try { await onConfirm(); } finally { setBusy(false); } };
  return (
    <div className="dialog-backdrop" onClick={onCancel} role="presentation">
      <div className="dialog" role="dialog" aria-modal="true" aria-labelledby="dlg-title" onClick={(e) => e.stopPropagation()}>
        <h3 id="dlg-title">{title}</h3>
        <p>{message}</p>
        <div className="dialog-actions">
          <button type="button" className="btn" onClick={onCancel} disabled={busy}>Cancel</button>
          <button type="button" className="btn danger solid" onClick={ok} disabled={busy}>
            {busy ? 'Working…' : confirmText}
          </button>
        </div>
      </div>
    </div>
  );
}
