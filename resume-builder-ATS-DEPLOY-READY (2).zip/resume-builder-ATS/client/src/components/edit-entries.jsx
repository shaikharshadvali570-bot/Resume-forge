import { Accordion, Field, Row, TextArea, TextInput } from '../components/forms.jsx';
import { sectionSingularLabel } from '../utils/resume-model.js';

const uid = () => `n-${Date.now()}-${Math.floor(Math.random() * 1e6)}`;

/** Generic dynamic entry list (education/experience/projects). */
export function EntryEditor({ sectionId, icon, title, entries, onChange, renderFields }) {
  const list = entries || [];
  const add = () => onChange([...list, { _key: uid() }]);
  const remove = (i) => onChange(list.filter((_, j) => j !== i));
  const move = (i, dir) => {
    const j = i + dir;
    if (j < 0 || j >= list.length) return;
    const next = [...list];
    [next[i], next[j]] = [next[j], next[i]];
    onChange(next);
  };
  const patch = (i, p) => onChange(list.map((e, j) => (j === i ? { ...e, ...p } : e)));
  return (
    <Accordion id={sectionId} icon={icon} title={title} meta={`${list.length} ${list.length === 1 ? 'entry' : 'entries'}`}>
      {list.map((entry, i) => (
        <div className="entry-block" key={entry.id || entry._key || i}>
          <div className="entry-head">
            <span className="e-num">{sectionSingularLabel(sectionId).toUpperCase()} {i + 1}</span>
            <span style={{ display: 'flex', gap: 6 }}>
              <button type="button" onClick={() => move(i, -1)} disabled={i === 0} aria-label="Move up">↑</button>
              <button type="button" onClick={() => move(i, 1)} disabled={i === list.length - 1} aria-label="Move down">↓</button>
              <button type="button" onClick={() => remove(i)}>Remove</button>
            </span>
          </div>
          {renderFields(entry, (p) => patch(i, p))}
        </div>
      ))}
      <button type="button" className="btn-add" onClick={add}>+ Add {sectionSingularLabel(sectionId)}</button>
    </Accordion>
  );
}

export function ExperienceFields({ entry, patch }) {
  return (
    <>
      <Row>
        <Field label="Job title"><TextInput value={entry.jobTitle || ''} onChange={(e) => patch({ jobTitle: e.target.value })} placeholder="Senior Engineer" /></Field>
        <Field label="Company"><TextInput value={entry.company || ''} onChange={(e) => patch({ company: e.target.value })} placeholder="Acme Inc." /></Field>
      </Row>
      <Row>
        <Field label="Location"><TextInput value={entry.location || ''} onChange={(e) => patch({ location: e.target.value })} placeholder="Remote" /></Field>
        <Field label="Start"><TextInput value={entry.startDate || ''} onChange={(e) => patch({ startDate: e.target.value })} placeholder="Jan 2021" /></Field>
        <Field label="End"><TextInput value={entry.endDate || ''} onChange={(e) => patch({ endDate: e.target.value })} placeholder="Present" disabled={entry.currentlyWorking} /></Field>
      </Row>
      <label className="check"><input type="checkbox" checked={Boolean(entry.currentlyWorking)} onChange={(e) => patch({ currentlyWorking: e.target.checked })} /> I currently work here</label>
      <Field label="Achievements — one bullet per line"><TextArea rows={4} value={entry.description || ''} onChange={(e) => patch({ description: e.target.value })} placeholder={'Led migration to microservices\nImproved deploys by 80%'} /></Field>
    </>
  );
}

export function EducationFields({ entry, patch }) {
  return (
    <>
      <Row>
        <Field label="Degree"><TextInput value={entry.degree || ''} onChange={(e) => patch({ degree: e.target.value })} placeholder="B.S. Computer Science" /></Field>
        <Field label="University"><TextInput value={entry.university || ''} onChange={(e) => patch({ university: e.target.value })} placeholder="State University" /></Field>
      </Row>
      <Row>
        <Field label="Location"><TextInput value={entry.location || ''} onChange={(e) => patch({ location: e.target.value })} /></Field>
        <Field label="Start year"><TextInput value={entry.startYear || ''} onChange={(e) => patch({ startYear: e.target.value })} placeholder="2018" /></Field>
        <Field label="End year"><TextInput value={entry.endYear || ''} onChange={(e) => patch({ endYear: e.target.value })} placeholder="2022" /></Field>
      </Row>
      <Field label="Notes"><TextArea rows={2} value={entry.description || ''} onChange={(e) => patch({ description: e.target.value })} /></Field>
    </>
  );
}

export function ProjectFields({ entry, patch }) {
  return (
    <>
      <Row>
        <Field label="Title"><TextInput value={entry.title || ''} onChange={(e) => patch({ title: e.target.value })} placeholder="Telemetry CLI" /></Field>
        <Field label="Organization"><TextInput value={entry.organization || ''} onChange={(e) => patch({ organization: e.target.value })} placeholder="Open source" /></Field>
      </Row>
      <Row>
        <Field label="Technologies"><TextInput value={entry.technologies || ''} onChange={(e) => patch({ technologies: e.target.value })} placeholder="Go, Docker" /></Field>
        <Field label="Project URL"><TextInput value={entry.projectUrl || ''} onChange={(e) => patch({ projectUrl: e.target.value })} placeholder="https://…" /></Field>
      </Row>
      <Field label="Details — one bullet per line"><TextArea rows={3} value={entry.description || ''} onChange={(e) => patch({ description: e.target.value })} /></Field>
    </>
  );
}
