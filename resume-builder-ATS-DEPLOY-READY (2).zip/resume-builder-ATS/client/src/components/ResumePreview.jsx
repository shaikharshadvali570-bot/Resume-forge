/**
 * ResumeForge — the 5 ATS-friendly template renderers + the preview "paper".
 *
 * Ported from legacy/js/resume-render.js. React escapes user content by
 * default, so no manual escapeHtml pass is needed.
 *
 * The paper element carries `data-template` + `data-theme` attributes and the
 * `--resume-accent` custom property — exactly what styles/builder.css targets.
 */
import { DEFAULT_SECTION_ORDER, getThemeMeta, toViewModel } from '../utils/resume-model.js';

const Bullets = ({ items }) => {
  if (!items?.length) return null;
  return (<ul>{items.map((b, i) => (<li key={i}>{b}</li>))}</ul>);
};

const Section = ({ label, children }) => {
  if (!children) return null;
  return (<section className="rs"><h3>{label}</h3>{children}</section>);
};

const ContactLine = ({ personal, sep = ' | ' }) => {
  const parts = [personal.email, personal.phone, personal.location].filter(Boolean);
  const links = [
    personal.linkedin ? { label: 'LinkedIn', href: personal.linkedin } : null,
    personal.github ? { label: 'GitHub', href: personal.github } : null,
    personal.website ? { label: 'Portfolio', href: personal.website } : null,
  ].filter(Boolean);
  if (!parts.length && !links.length) return null;
  return (
    <p className="contact">
      {parts.join(sep)}
      {parts.length > 0 && links.length > 0 ? sep : ''}
      {links.map((l, i) => (
        <span key={l.label}>
          {i > 0 ? sep : ''}
          <a href={l.href} target="_blank" rel="noopener noreferrer">{l.label}</a>
        </span>
      ))}
    </p>
  );
};

const EntryList = ({ entries }) => {
  if (!entries?.length) return null;
  return (
    <>
      {entries.map((e, i) => {
        const org = e.company || e.org;
        if (!e.title && !org && !(e.bullets || []).length) return null;
        return (
          <div className="ent" key={i}>
            <div className="ent-head">
              {e.title}
              {org ? <span className="ent-org"> {org}</span> : null}
              {e.period ? <span className="ent-period"> · {e.period}</span> : null}
            </div>
            {e.location ? <div className="ent-loc">{e.location}</div> : null}
            <Bullets items={e.bullets} />
          </div>
        );
      })}
    </>
  );
};

const EducationList = ({ entries }) => {
  if (!entries?.length) return null;
  return (
    <>
      {entries.map((e, i) => {
        const bits = [e.degree, e.school, e.year ? `(${e.year})` : ''].filter(Boolean);
        if (!bits.length && !e.description) return null;
        return (
          <div className="ent" key={i}>
            {bits.length ? <div className="ent-head">{bits.join(' — ')}</div> : null}
            {e.location ? <div className="ent-period">{e.location}</div> : null}
            {e.description ? <p className="sum">{e.description}</p> : null}
          </div>
        );
      })}
    </>
  );
};

const SimpleList = ({ items, chips = false }) => {
  if (!items?.length) return null;
  if (chips) {
    return (
      <div className="chips">
        {items.map((s, i) => (<span className="chip" key={i}>{s}</span>))}
      </div>
    );
  }
  return (<ul>{items.map((s, i) => (<li key={i}>{s}</li>))}</ul>);
};

const InlineList = ({ items }) => {
  if (!items?.length) return null;
  return <p className="sum">{items.join(', ')}</p>;
};

const LABELS = {
  summary: 'Professional Summary',
  experience: 'Experience',
  education: 'Education',
  projects: 'Projects',
  skills: 'Skills',
  certifications: 'Certifications',
  achievements: 'Achievements',
  languages: 'Languages',
  hobbies: 'Hobbies',
};

const has = (arr) => Array.isArray(arr) && arr.length > 0;

function sectionFor(id, vm, skillsAsChips) {
  switch (id) {
    case 'summary':
      return vm.summary
        ? <Section key={id} label={LABELS.summary}><p className="sum">{vm.summary}</p></Section>
        : null;
    case 'experience':
      return has(vm.experience)
        ? <Section key={id} label={LABELS.experience}><EntryList entries={vm.experience} /></Section>
        : null;
    case 'education':
      return has(vm.education)
        ? <Section key={id} label={LABELS.education}><EducationList entries={vm.education} /></Section>
        : null;
    case 'projects':
      return has(vm.projects)
        ? <Section key={id} label={LABELS.projects}><EntryList entries={vm.projects} /></Section>
        : null;
    case 'skills':
      return has(vm.skills)
        ? <Section key={id} label={LABELS.skills}><SimpleList items={vm.skills} chips={skillsAsChips} /></Section>
        : null;
    case 'certifications':
      return has(vm.certifications)
        ? <Section key={id} label={LABELS.certifications}><SimpleList items={vm.certifications} /></Section>
        : null;
    case 'achievements':
      return has(vm.achievements)
        ? <Section key={id} label={LABELS.achievements}><SimpleList items={vm.achievements} /></Section>
        : null;
    case 'languages':
      return has(vm.languages)
        ? <Section key={id} label={LABELS.languages}><InlineList items={vm.languages} /></Section>
        : null;
    case 'hobbies':
      return has(vm.hobbies)
        ? <Section key={id} label={LABELS.hobbies}><InlineList items={vm.hobbies} /></Section>
        : null;
    default:
      return null;
  }
}

function oneColumnSections(order, vm, skillsAsChips = true) {
  return order.map((id) => sectionFor(id, vm, skillsAsChips));
}

/** Sections that live in the Modern template's sidebar. */
const SIDE_IDS = ['skills', 'languages', 'hobbies', 'certifications'];

export const Professional = ({ vm, order }) => (
  <>
    <header className="rs-head center">
      <h1>{vm.personal.fullName || 'Your Name'}</h1>
      <ContactLine personal={vm.personal} />
    </header>
    {oneColumnSections(order, vm)}
  </>
);

export const Minimal = ({ vm, order }) => (
  <>
    <header className="rs-head minimal-head">
      <h1>{vm.personal.fullName || 'Your Name'}</h1>
      <ContactLine personal={vm.personal} sep=" · " />
    </header>
    {oneColumnSections(order, vm, false)}
  </>
);

export const AtsFriendly = ({ vm, order }) => {
  const lines = [
    vm.personal.email,
    vm.personal.phone,
    vm.personal.location,
    vm.personal.linkedin,
    vm.personal.github,
  ].filter(Boolean);
  return (
    <>
      <header className="rs-head center ats-head">
        <h1>{vm.personal.fullName || 'Your Name'}</h1>
        {lines.length ? <p className="contact">{lines.join(' | ')}</p> : null}
      </header>
      {oneColumnSections(order, vm, false)}
    </>
  );
};

export const Classic = ({ vm, order }) => (
  <>
    <header className="rs-head classic-head">
      <h1>{vm.personal.fullName || 'Your Name'}</h1>
      <ContactLine personal={vm.personal} sep=" · " />
    </header>
    {oneColumnSections(order, vm, false)}
  </>
);

export const Modern = ({ vm, order }) => {
  const mainOrder = order.filter((id) => !SIDE_IDS.includes(id));
  const sideOrder = order.filter((id) => SIDE_IDS.includes(id));
  return (
    <>
      <header className="rs-head modern-head">
        <h1>{vm.personal.fullName || 'Your Name'}</h1>
        <ContactLine personal={vm.personal} />
      </header>
      <div className="modern-body">
        <div className="modern-main">{mainOrder.map((id) => sectionFor(id, vm, id === 'skills'))}</div>
        <aside className="modern-side">{sideOrder.map((id) => sectionFor(id, vm, id === 'skills'))}</aside>
      </div>
    </>
  );
};

export const RENDERERS = {
  professional: Professional,
  modern: Modern,
  minimal: Minimal,
  ats: AtsFriendly,
  classic: Classic,
};

/** Renders just the resume body (shared by preview + export paths). */
export function renderResume(vm, templateId, order) {
  const safe = Array.isArray(order) && order.length ? order : DEFAULT_SECTION_ORDER;
  const Renderer = RENDERERS[templateId] || Professional;
  return <Renderer vm={vm} order={safe} />;
}

/**
 * The preview paper. `template` / `theme` may be passed explicitly so the
 * builder can show unsaved design changes before they reach the database.
 */
export function ResumePreview({ resume, template, theme, className = '', id = 'resume' }) {
  const vm = toViewModel(resume || {});
  const tpl = template || resume?.template || 'professional';
  const thm = theme || resume?.theme || 'blue';
  const order = resume?.sectionOrder?.length ? resume.sectionOrder : DEFAULT_SECTION_ORDER;
  return (
    <div
      id={id}
      className={`resume ${className}`.trim()}
      data-template={tpl}
      data-theme={thm}
      style={{ '--resume-accent': getThemeMeta(thm).color }}
    >
      {renderResume(vm, tpl, order)}
    </div>
  );
}

export default ResumePreview;

