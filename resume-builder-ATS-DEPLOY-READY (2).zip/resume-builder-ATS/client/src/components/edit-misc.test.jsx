import { describe, expect, it } from 'vitest';
import { parseCommaList } from '../utils/resume-model.js';
import { resolveSkillText } from './edit-misc.jsx';

/**
 * Regression: the skills box used to derive its value from the skills array, so
 * a comma typed at the end was immediately stripped (parseCommaList drops the
 * empty tail segment) and the box snapped back, making it impossible to start
 * a new skill.
 */
describe('skills box comma entry', () => {
  it('keeps a trailing comma so the next skill can be typed', () => {
    expect(resolveSkillText('React,', 'React')).toBe('React,');
    expect(resolveSkillText('React, ', 'React')).toBe('React, ');
  });

  it('keeps a comma while the following skill is being typed', () => {
    // Every keystroke reaches the parent, so `joined` already tracks the
    // partial skill: the raw text must be kept as-is.
    const partial = 'React, Ja';
    expect(resolveSkillText(partial, parseCommaList(partial).join(', '))).toBe(partial);
  });

  it('never loses a character across a full typed string', () => {
    // Simulates the builder loop: every keystroke re-derives `joined` from the
    // parsed array, and the box must render exactly what was typed.
    const keystrokes = 'React, Node.js, ';
    let text = '';
    for (const char of keystrokes) {
      text += char;
      const joined = parseCommaList(text).join(', ');
      expect(resolveSkillText(text, joined)).toBe(text);
    }
    expect(text).toBe('React, Node.js, ');
  });

  it('adopts skills changed outside the box (load, reload, template switch)', () => {
    expect(resolveSkillText('React, Node', 'Python, SQL, AWS')).toBe('Python, SQL, AWS');
    expect(resolveSkillText('', 'Python, SQL')).toBe('Python, SQL');
  });

  it('still maps typed text to the [{ name }] payload shape', () => {
    const typed = 'React, Node.js, ';
    expect(parseCommaList(typed).map((name) => ({ name }))).toEqual([
      { name: 'React' },
      { name: 'Node.js' },
    ]);
  });
});