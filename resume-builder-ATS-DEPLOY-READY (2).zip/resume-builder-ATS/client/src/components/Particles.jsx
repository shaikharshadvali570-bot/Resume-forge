import { useEffect, useRef } from 'react';
import { useAppTheme } from '../hooks/hooks.js';

/** Full-screen gold particle canvas (legacy particle design, as a component). */
export default function Particles({ density = 55 } = {}) {
  const ref = useRef(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return undefined;
    const ctx = canvas.getContext('2d');
    let W = 0; let H = 0;
    const pts = [];
    const resize = () => { W = canvas.width = window.innerWidth; H = canvas.height = window.innerHeight; };
    resize();
    window.addEventListener('resize', resize);
    class P {
      constructor() { this.reset(true); }
      reset() {
        this.x = Math.random() * W; this.y = Math.random() * H;
        this.r = Math.random() * 1.4 + 0.3;
        this.vx = (Math.random() - 0.5) * 0.15; this.vy = (Math.random() - 0.5) * 0.15;
        this.a = Math.random() * 0.2 + 0.04;
      }
      step() {
        this.x += this.vx; this.y += this.vy;
        if (this.x < 0 || this.x > W) this.vx *= -1;
        if (this.y < 0 || this.y > H) this.vy *= -1;
      }
      draw() {
        ctx.beginPath(); ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(212,168,67,${this.a})`; ctx.fill();
      }
    }
    for (let i = 0; i < density; i++) pts.push(new P());
    let raf = 0;
    const light = () => document.documentElement.getAttribute('data-app-theme') === 'light';
    const frame = () => {
      raf = requestAnimationFrame(frame);
      ctx.fillStyle = light() ? '#f4f2ec' : '#0b0b12'; ctx.fillRect(0, 0, W, H);
      const g = ctx.createRadialGradient(W * 0.3, H * 0.1, 0, W * 0.3, H * 0.1, W * 0.55);
      g.addColorStop(0, 'rgba(212,168,67,0.045)'); g.addColorStop(1, 'transparent');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      pts.forEach((p) => { p.step(); p.draw(); });
    };
    raf = requestAnimationFrame(frame);
    return () => { cancelAnimationFrame(raf); window.removeEventListener('resize', resize); };
  }, [density]);
  return <canvas id="bg" ref={ref} aria-hidden="true" />;
}

/** Applies the persisted dark/light theme to <html>. */
export function ThemeGate({ children }) {
  useAppTheme();
  return children;
}
