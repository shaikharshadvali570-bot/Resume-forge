/** Loading skeletons, spinners, empty + error states shared by the pages. */

export function SkeletonCards({ count = 3 }) {
  return (
    <>
      {Array.from({ length: count }).map((_, i) => (
        <div className="skeleton" key={i} aria-hidden="true" />
      ))}
    </>
  );
}

export function EmptyResumes({ onCreate }) {
  return (
    <div className="empty-state" role="status">
      <div className="es-icon" aria-hidden="true">📄</div>
      <h3>No resumes yet</h3>
      <p>
        Create your first resume — it takes less than a minute to start, and every change
        auto-saves to your account.
      </p>
      <button type="button" className="btn primary" onClick={onCreate}>+ Create resume</button>
    </div>
  );
}

export function CenteredSpinner({ label = 'Loading…' }) {
  return (
    <div className="centered-loading" role="status" aria-live="polite">
      <span className="spinner lg" aria-hidden="true" />
      <p className="muted">{label}</p>
    </div>
  );
}

export function ErrorPanel({ title = 'Something went wrong', message, onRetry, retryText = 'Try again' }) {
  return (
    <div className="error-panel" role="alert">
      <h2>{title}</h2>
      <p>{message}</p>
      {onRetry ? (
        <button type="button" className="btn primary" onClick={onRetry}>{retryText}</button>
      ) : null}
    </div>
  );
}
